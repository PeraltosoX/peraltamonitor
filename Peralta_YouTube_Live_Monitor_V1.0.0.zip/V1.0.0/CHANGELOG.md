# Histórico de versões

## V1.0.0 — 2026-09-23

- Painel privado com login, proteção CSRF e interface para servidores, canais, associações, modelos e logs.
- Instalação Discord via OAuth2 iniciada no painel e vinculada ao Discord User ID autorizado.
- Servidores adicionados por convite externo permanecem sem autorização; ativação exige verificação no painel.
- Worker YouTube com WebSub e recuperação por playlist/vídeos; linha de base, persistência dos IDs e entregas por servidor.
- Cinco espaços iniciais de API keys, novas entradas ilimitadas, cifragem em repouso, medição por chave e uso sequencial com espera/failover em erro ou cota.
- Notificação única para live programada detectada, live já iniciada ou vídeo/Short novo.
- Implantação Docker Compose com porta local 8081 e dados separados do Auto Server.
