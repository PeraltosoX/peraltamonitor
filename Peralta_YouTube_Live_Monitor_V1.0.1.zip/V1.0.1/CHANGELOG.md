# Histórico de versões

## V1.0.1 — 2026-09-23

- Recupera para o Discord as lives ainda agendadas e vídeos novos vistos na última hora quando uma associação ou servidor é ativado, e ao iniciar o worker após a atualização. Não repete entregas existentes.
- Busca lives agendadas pelo canal com `search.list` sob limite local diário de 100 chamadas, respeitando o intervalo automático por quantidade de canais; botão de verificação manual no painel.
- Corrige o tópico WebSub para `/feeds/videos.xml` e mantém o monitoramento por playlist e `videos.list`.
- Aceita 30 segundos como mínimo da recuperação da playlist; o valor inicial continua 300 segundos.
- Migração preserva o banco e os segredos de V1.0.0; acrescenta a coluna da última busca e a tabela de uso de buscas. Mantenha backup antes de atualizar.

## V1.0.0 — 2026-09-23

- Painel privado com login, proteção CSRF e interface para servidores, canais, associações, modelos e logs.
- Instalação Discord via OAuth2 iniciada no painel e vinculada ao Discord User ID autorizado.
- Servidores adicionados por convite externo permanecem sem autorização; ativação exige verificação no painel.
- Worker YouTube com WebSub e recuperação por playlist/vídeos; linha de base, persistência dos IDs e entregas por servidor.
- Cinco espaços iniciais de API keys, novas entradas ilimitadas, cifragem em repouso, medição por chave e uso sequencial com espera/failover em erro ou cota.
- Notificação única para live programada detectada, live já iniciada ou vídeo/Short novo.
- Implantação Docker Compose com porta local 8081 e dados separados do Auto Server.
