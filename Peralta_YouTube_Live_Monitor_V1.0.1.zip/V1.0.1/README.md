# Peralta YouTube Live Monitor — V1.0.1

Painel privado para monitorar canais públicos do YouTube e avisar seus servidores Discord. O painel fica em **https://peraltamonitor.peraltaultrachat.shop**. A aplicação usa Docker Compose e SQLite próprio, sem compartilhar banco, container ou porta com o Auto Server (`peraltapainel.shop`, porta 8080). Compatível com uma VPS Ubuntu 24.04 LTS; use outra versão estável com Docker Compose v2.

## Como funciona

1. Você cadastra um `Channel ID` (começa com `UC`). O monitor consulta `channels.list` para obter a playlist de uploads, guarda os IDs já existentes e não envia avisos antigos.
2. O worker assina o feed WebSub, consulta periodicamente `playlistItems.list` + `videos.list` e faz buscas controladas de lives agendadas com `search.list`. Um mesmo canal do YouTube é consultado uma vez para todos os seus servidores.
3. Vídeo normal e Short usam a mesma opção. Uma live pública detectada como **agendada** gera aviso ao ser encontrada; uma live descoberta já ao vivo também gera aviso. A mudança posterior para “ao vivo” não gera outro aviso. O banco guarda `video_id` e uma entrega por servidor para evitar repetição.
4. O botão **Adicionar ao servidor** cria um link OAuth2 de uso único, associado à sessão do painel. O retorno confere o **Discord User ID** da conta que aprovou a instalação. O servidor só fica ativo depois de você escolher o canal e salvar. Entradas fora desse fluxo não ganham autorização.
5. A aba **APIs do YouTube** inicia com cinco espaços e aceita mais chaves. A chave escolhida para começar é usada primeiro; em erro ou cota esgotada, o monitor tenta a próxima chave ativa pela ordem numérica, uma vez por operação. A chave com falha entra em espera e o painel mostra a situação. O monitor não fica alternando a cada consulta se a atual continua funcionando.

**Limite real de detecção:** YouTube não garante que toda live agendada apareça imediatamente nos resultados de busca, playlist ou push público. O aviso sai assim que uma das fontes usadas mostrar a live; “instantâneo no momento do agendamento” não é garantido. A busca de lives agendadas tem limite local global de 100 chamadas por dia: até 80 automáticas (com intervalo adaptado à quantidade de canais e pelo menos 15 minutos entre buscas por canal) e até 20 reservadas para verificações manuais. Falhas na troca de chave podem consumir esse orçamento. No modelo de cotas de 2026, o Google também limita `search.list` a 100 chamadas por dia num grupo próprio; cada chamada consome 100 unidades da cota principal. `playlistItems.list` e `videos.list` custam uma unidade por chamada. Com 300 segundos, duas chamadas por canal a cada ciclo somam cerca de 576 unidades por canal em 24 horas, sem contar push, busca e cadastro; com 30 segundos, cerca de 5.760 por canal. Ajuste intervalo e quantidade de canais conforme a cota do seu projeto Google. A contagem local por chave é uma estimativa no dia do Pacífico; várias chaves no **mesmo projeto Google compartilham a cota do projeto**, e a medição oficial permanece na Google Cloud. Use credenciais e projetos conforme as regras do YouTube.

## Atualizar sua instalação V1.0.0

Depois de enviar `Peralta_YouTube_Live_Monitor_V1.0.1.zip` para a raiz da branch `main` do seu repositório, execute na VPS:

```bash
cd /opt/peralta-live-monitor/releases/V1.0.0
docker compose exec -T web python -m scripts.backup /data/backup/monitor-$(date +%Y%m%d-%H%M%S).sqlite3
curl -fL -o /tmp/Peralta_YouTube_Live_Monitor_V1.0.1.zip \
  https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.0.1.zip
unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.0.1.zip -d /opt/peralta-live-monitor/releases
cd /opt/peralta-live-monitor/releases/V1.0.1
docker compose up -d --build
docker compose ps
curl -fsS https://peraltamonitor.peraltaultrachat.shop/health
docker compose logs --tail=80 web worker bot
```

O retorno de `/health` deve mostrar `1.0.1`. O banco antigo recebe a nova coluna e a tabela de buscas sem apagar vídeos ou avisos. A recuperação de lives ainda agendadas entra automaticamente na fila para associações ativas. O `.env`, a pasta `/data` e o Caddy existentes continuam nos mesmos caminhos. Depois, use **Canais YouTube → Verificar lives agendadas agora** e confira **Atividade e logs**; se mostrar zero entregas, verifique se o servidor está ativo, se o canal de avisos foi escolhido, se existe uma associação ativa e se a opção de aviso de lives está ligada. Uma entrega enviada anteriormente não é duplicada.

## Credenciais necessárias

| Nome em `.env` | Onde obter | Função |
| --- | --- | --- |
| `DISCORD_APPLICATION_ID` | Discord Developer Portal → General Information | Identifica o aplicativo e monta o convite; o `client_id` de um link existente só serve se for deste bot. |
| `DISCORD_BOT_TOKEN` | Discord Developer Portal → Bot | Faz o bot conectar e enviar mensagens. Nunca publique. |
| `DISCORD_CLIENT_SECRET` | Discord Developer Portal → OAuth2 | Troca o código de autorização no servidor. Nunca publique. |
| `DISCORD_OWNER_USER_ID` | Discord → Modo Desenvolvedor → copiar **seu** ID de usuário | Só sua conta pode autorizar instalações no painel; é diferente do Application ID. |
| `YOUTUBE_API_KEY` | Google Cloud → habilitar YouTube Data API v3 → Credentials | Chave inicial opcional. Você também pode cadastrar e testar cinco ou mais chaves diretamente na aba APIs do painel. Restrinja as chaves à YouTube Data API v3. |
| `ADMIN_PASSWORD_HASH` | Gerado na instalação com `python -m app.security` | Senha de acesso ao painel, armazenada apenas como hash. |
| `APP_SECRET`, `WEB_SUB_SECRET` | `openssl rand -hex 32` (dois valores diferentes) | Sessão/CSRF e assinatura do push do YouTube. |

No **Discord Developer Portal**, configure o aplicativo do seu bot assim:

- **Bot → Public Bot: desligado.** Dessa forma, só o proprietário do aplicativo poderá adicioná-lo; se o aplicativo estiver sob uma equipe, confira quem é considerado proprietário no Discord.
- **Bot → Require OAuth2 Code Grant: ligado.** O bot só entra após a autorização completa, que devolve o servidor ao callback.
- **OAuth2 → Redirects:** `https://peraltamonitor.peraltaultrachat.shop/auth/discord/callback` (exato, sem barra adicional).
- **Installation:** habilite instalação em servidor (Guild Install); permissões `150528` equivalem a visualizar o canal, enviar mensagens, embutir links e mencionar `@everyone`. Você ainda escolhe no painel se `@everyone` será usado. Não é necessário Message Content Intent, token de usuário nem dar permissão Administrador.
- Use o **botão do painel** para instalar. O link simples `scope=bot` que você mostrou não confirma seu Discord User ID para o painel.

## Instalação no Ubuntu — comandos por etapa

Primeiro, envie o ZIP `Peralta_YouTube_Live_Monitor_V1.0.1.zip` para a **raiz da branch `main`** de `https://github.com/PeraltosoX/peraltamonitor`. O download abaixo funcionará **após você publicar esse arquivo**. Você também pode publicá-lo como asset de uma release `v1.0.1` ou enviar o código fonte; os outros caminhos estão descritos abaixo.

### 1. Dependências e diretórios

```bash
sudo apt update
sudo apt install -y ca-certificates curl unzip openssl
docker compose version
sudo install -d -m 750 /opt/peralta-live-monitor/releases /opt/peralta-live-monitor/data
sudo chown -R "$(id -un):$(id -gn)" /opt/peralta-live-monitor
```

Sua VPS já tem Docker em uso pelo Auto Server, então não reinstale o Docker Engine. Se `docker compose version` falhar, instale apenas o [plugin Docker Compose v2 conforme o repositório Docker da sua versão Ubuntu](https://docs.docker.com/compose/install/linux/) e repita o comando de verificação.

### 2. Baixar a release pelo seu GitHub

```bash
curl -fL -o /tmp/Peralta_YouTube_Live_Monitor_V1.0.1.zip \
  https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.0.1.zip
unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.0.1.zip -d /opt/peralta-live-monitor/releases
cd /opt/peralta-live-monitor/releases/V1.0.1
```

Se você criar a release `v1.0.1` com esse asset, troque só a URL por `https://github.com/PeraltosoX/peraltamonitor/releases/download/v1.0.1/Peralta_YouTube_Live_Monitor_V1.0.1.zip`. Se o repositório for privado, `curl` sem autenticação retornará erro; autentique o GitHub CLI **na sua VPS** e use `gh release download v1.0.1 -R PeraltosoX/peraltamonitor -p 'Peralta_YouTube_Live_Monitor_V1.0.1.zip' -D /tmp` após criar a release, ou baixe os arquivos autenticado.

### 3. Preencher os segredos

```bash
cp .env.example ../../.env
chmod 600 ../../.env
openssl rand -hex 32
openssl rand -hex 32
docker compose build
docker compose run --rm --no-deps web python -m app.security
nano ../../.env
```

Cole no `.env` os dois segredos gerados (um em `APP_SECRET`, outro em `WEB_SUB_SECRET`), o hash impresso após escolher uma senha de pelo menos 12 caracteres e as credenciais Discord. Substitua também `YOUTUBE_API_KEY` por sua chave inicial, **ou deixe o campo vazio** e cadastre as chaves na aba APIs após o primeiro login. **Não coloque `.env` no GitHub.** O exemplo contém placeholders e não deve ser usado sem substituir todos os demais. Preserve `APP_SECRET` em futuras versões: ele protege tanto as sessões quanto as chaves cifradas no banco.

### 4. Iniciar e verificar localmente

```bash
docker compose up -d --build
docker compose ps
curl -fsS http://127.0.0.1:8081/health
docker compose logs --tail=80 web worker bot
```

O serviço deve responder `{"status":"ok","version":"1.0.1"}`. A porta do painel fica vinculada **somente a 127.0.0.1:8081**. O Auto Server continua na 8080.

### 5. Acrescentar o domínio no Caddy existente

Seu bloco atual deve continuar exatamente assim:

```caddyfile
peraltapainel.shop {
    reverse_proxy 127.0.0.1:8080
}
```

Faça um backup e **acrescente uma única vez** o segundo bloco:

```bash
sudo cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak.$(date +%Y%m%d%H%M%S)
sudo tee -a /etc/caddy/Caddyfile >/dev/null <<'CADDY'

peraltamonitor.peraltaultrachat.shop {
    reverse_proxy 127.0.0.1:8081
}
CADDY
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
curl -fsS https://peraltamonitor.peraltaultrachat.shop/health
```

Se a validação falhar, corrija o Caddyfile antes do `reload`. O domínio já apontado para a VPS receberá HTTPS automaticamente pelo Caddy quando DNS e portas 80/443 estiverem funcionais.

### 6. Configurar o primeiro aviso

1. Entre no painel com `ADMIN_USERNAME` e sua senha.
2. Clique **Adicionar ao servidor**, faça login na conta Discord cujo **User ID** está no `.env` e escolha o servidor. Na volta, aguarde o bot conectar.
3. Em **Discord e servidores**, escolha um canal de texto, salve com **Servidor ativo**, e envie um teste.
4. Em **APIs do YouTube**, configure pelo menos uma chave (se não configurou `YOUTUBE_API_KEY`), teste-a, ative-a e marque **Usar primeiro**. Configure as demais com ordem de reserva 2, 3, 4 etc.; falhas HTTP 403/429 esperam até o próximo dia da cota no horário do Pacífico, e erros de rede aguardam dois minutos. Cada operação tenta cada chave disponível no máximo uma vez.
5. Em **Canais YouTube**, informe o Channel ID começando com `UC`. Os vídeos já encontrados entram como linha de base e não geram spam.
6. Em **Associações**, vincule o servidor ao canal. Lives ainda agendadas já detectadas entram na fila, e novas publicações passam a ser monitoradas. Em **Canais YouTube**, use o botão de verificação manual para conferir lives agendadas.

## Instalação por git

Depois que você colocar o código desta versão na raiz do seu repositório e criar a tag `v1.0.1`, o download pode ser feito com:

```bash
git clone https://github.com/PeraltosoX/peraltamonitor.git /opt/peralta-live-monitor/releases/V1.0.1
cd /opt/peralta-live-monitor/releases/V1.0.1
git checkout v1.0.1
```

Continue na etapa 3. **Não execute esses comandos antes de publicar os arquivos e a tag.** O ZIP da release acima é o fluxo principal e tem pasta `V1.0.1` pronta.

## Manutenção e atualizações

O banco e o `.env` ficam fora das pastas versionadas, em `/opt/peralta-live-monitor/data` e `/opt/peralta-live-monitor/.env`. Para um backup consistente:

```bash
cd /opt/peralta-live-monitor/releases/V1.0.1
docker compose exec -T web python -m scripts.backup /data/backup/monitor-$(date +%Y%m%d-%H%M%S).sqlite3
```

Guarde também uma cópia segura do `.env` fora do GitHub. Para uma versão posterior, baixe um **arquivo com novo nome e nova versão**, extraia a pasta da nova versão em `releases`, leia o `CHANGELOG.md`, faça backup e execute `docker compose up -d --build` dentro dessa pasta. O `name` do Compose é fixo para atualizar os mesmos serviços sem mexer no Auto Server. Verifique o `/health` e os logs. A reversão para uma versão anterior exige compatibilidade do esquema de banco; confira as notas de migração da versão nova antes de atualizar.

## Diagnóstico rápido

```bash
cd /opt/peralta-live-monitor/releases/V1.0.1
docker compose ps
docker compose logs --tail=100 web worker bot
sudo journalctl -u caddy -n 80 --no-pager
sudo docker ps --format 'table {{.Names}}\t{{.Ports}}'
```

Se o Discord não deixar instalar, confirme `Public Bot`, `Require OAuth2 Code Grant`, Redirect URI exata, instalação em servidor e se o **Discord User ID** é da conta usada. Se o YouTube responder 403, confira se a Data API v3 está habilitada e a cota no Google Cloud. Em qualquer falha, não exponha tokens ou `.env` nos logs enviados a terceiros.

## Referências de API

- [Discord OAuth2 e instalação de bots](https://docs.discord.com/developers/topics/oauth2)
- [YouTube Data API — cotas](https://developers.google.com/youtube/v3/determine_quota_cost)
- [YouTube `playlistItems.list`](https://developers.google.com/youtube/v3/docs/playlistItems/list) e [`videos.list`](https://developers.google.com/youtube/v3/docs/videos/list)
