import asyncio
import math
import time

from . import db, youtube, api_keys
from .config import APP_DOMAIN, WEB_SUB_CALLBACK, WEB_SUB_SECRET, require


async def process_push_queue():
    pending = db.rows("SELECT video_id,channel_id FROM pending_video_ids ORDER BY received_at LIMIT 50")
    if not pending:
        return
    details = await youtube.video_details([p["video_id"] for p in pending])
    by_channel = {}
    for item in details:
        cid = item.get("snippet", {}).get("channelId")
        if cid:
            by_channel.setdefault(cid, []).append(item)
    for cid, items in by_channel.items():
        count, queued = youtube.store_videos(cid, items)
        if count:
            db.log("worker", "info", f"Push {cid}: {count} vídeo(s) novo(s), {queued} entrega(s)")
    # A missing/private ID is retried by the periodic playlist scan, avoiding
    # repeated API calls every worker iteration for a private video.
    with db.transaction() as con:
        con.executemany("DELETE FROM pending_video_ids WHERE video_id=?",
                        [(p["video_id"],) for p in pending])


async def poll_channel(channel):
    cid = channel["channel_id"]
    try:
        ids = await youtube.latest_video_ids(channel["uploads_id"])
        details = await youtube.video_details(ids)
        count, queued = youtube.store_videos(cid, details)
        db.write("UPDATE youtube_channels SET last_poll=?,last_error='' WHERE channel_id=?", (db.ts(), cid))
        if count:
            db.log("worker", "info", f"{cid}: {count} vídeo(s) novo(s), {queued} entrega(s)")
    except Exception as exc:
        # YouTubeError messages contain no request URL, token or API key.
        reason = str(exc) if isinstance(exc, youtube.YouTubeError) else type(exc).__name__
        db.write("UPDATE youtube_channels SET last_poll=?,last_error=? WHERE channel_id=?",
                 (db.ts(), reason[:250], cid))
        db.log("worker", "error", f"{cid}: {reason}")


async def main():
    require("APP_DOMAIN", "APP_SECRET")
    db.init_db()
    for guild in db.rows("SELECT guild_id FROM guilds WHERE active=1 AND present=1 AND owner_verified=1"):
        queued = youtube.queue_recent_for_guild(guild["guild_id"])
        if queued:
            db.log("worker", "info", f"Recuperação para servidor {guild['guild_id']}: {queued} entrega(s)")
    last_push_subscription = 0
    last_prune = 0
    last_api_warning = 0
    last_push_error = 0
    while True:
        db.heartbeat("worker", "Monitorando")
        try:
            await process_push_queue()
        except Exception as exc:
            reason = str(exc) if isinstance(exc, youtube.YouTubeError) else type(exc).__name__
            if time.time() - last_push_error > 300:
                db.log("worker", "error", f"Fila push: {reason}")
                last_push_error = time.time()
        try:
            interval = max(30, min(86400, int(db.setting("playlist_interval", "300"))))
        except ValueError:
            interval = 300
        for channel in db.rows("SELECT * FROM youtube_channels WHERE active=1 ORDER BY last_poll IS NOT NULL,last_poll"):
            if channel["last_poll"] and db.ts() - channel["last_poll"] < interval:
                continue
            try:
                available = api_keys.candidates()
            except RuntimeError as exc:
                if time.time() - last_api_warning > 300:
                    db.log("worker", "warning", str(exc))
                    last_api_warning = time.time()
                break
            if not available:
                if time.time() - last_api_warning > 300:
                    db.log("worker", "warning", "Nenhuma chave API disponível; aguardando cota ou correção")
                    last_api_warning = time.time()
                break
            await poll_channel(channel)
            await asyncio.sleep(0.15)
        active_count = db.one("SELECT COUNT(*) AS n FROM youtube_channels WHERE active=1")["n"]
        # Up to 75 regular search calls/day; leave five for failover attempts
        # and twenty for manual checks within the daily local limit of 100.
        search_interval = max(900, math.ceil(86400 * active_count / 75)) if active_count else 900
        if db.search_calls() < 80:
            for channel in db.rows("SELECT * FROM youtube_channels WHERE active=1 "
                                   "ORDER BY last_upcoming_search IS NOT NULL,last_upcoming_search"):
                if channel["last_upcoming_search"] and db.ts() - channel["last_upcoming_search"] < search_interval:
                    continue
                try:
                    result = await youtube.check_upcoming(channel["channel_id"])
                    if result["new"] or result["queued"]:
                        db.log("worker", "info", f"Lives agendadas {channel['channel_id']}: "
                               f"{result['new']} vídeo(s) novo(s), {result['queued']} entrega(s)")
                except Exception as exc:
                    reason = str(exc) if isinstance(exc, youtube.YouTubeError) else type(exc).__name__
                    db.log("worker", "warning", f"Busca de lives {channel['channel_id']}: {reason}")
                    db.write("UPDATE youtube_channels SET last_upcoming_search=? WHERE channel_id=?",
                             (db.ts(), channel["channel_id"]))
                await asyncio.sleep(0.15)
                if db.search_calls() >= 80:
                    break
        if WEB_SUB_SECRET and time.time() - last_push_subscription > 12 * 3600:
            for channel in db.rows("SELECT channel_id FROM youtube_channels WHERE active=1"):
                try:
                    await youtube.subscribe_push(channel["channel_id"], WEB_SUB_CALLBACK, WEB_SUB_SECRET)
                except youtube.YouTubeError as exc:
                    db.log("worker", "warning", f"Push {channel['channel_id']}: {exc}")
            last_push_subscription = time.time()
        if time.time() - last_prune > 86400:
            db.prune()
            last_prune = time.time()
        await asyncio.sleep(10)


if __name__ == "__main__":
    asyncio.run(main())
