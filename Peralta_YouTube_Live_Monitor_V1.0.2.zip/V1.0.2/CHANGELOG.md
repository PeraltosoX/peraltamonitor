# Histórico de versões

## V1.0.2 — 2026-09-23

- Nova regra de início: ao associar um canal YouTube ao servidor Discord, publicações existentes ficam registradas sem aviso; somente as criadas depois são notificadas.
- Ignora vídeos e lives antigos que aparecerem tardiamente na API, comparando a data de publicação com o início da associação.
- Remove a recuperação retroativa da V1.0.1. Na migração, associações ativas recebem um novo marco de início e entregas antigas ainda pendentes são marcadas como ignoradas, sem apagar os registros.
- Corrige o tipo apresentado no Discord para distinguir LIVE AGENDADA, LIVE AO VIVO e NOVO VÍDEO.
- Mantém as configurações, o banco de dados, a busca controlada de agendamentos e o intervalo mínimo de 30 segundos para a playlist.

## V1.0.1 — 2026-09-23

- Recupera para o Discord as lives ainda agendadas e vídeos novos vistos na última hora quando uma associação ou servidor é ativado, e ao iniciar o worker após a atualização. Não repete entregas existentes.
- Busca lives agendadas pelo canal com `search.list` sob limite local diário de 100 chamadas, respeitando o intervalo automático por quantidade de canais; botão de verificação manual no painel.
- Corrige o tópico WebSub para `/feeds/videos.xml` e mantém o monitoramento por playlist e `videos.list`.
- Aceita 30 segundos como mínimo da recuperação da playlist; o valor inicial continua 300 segundos.
- Migração preserva o banco e os segredos de V1.0.0; acrescenta a coluna da última busca e a tabela de uso de buscas. Mantenha backup antes de atualizar.

## V1.0.0 — 2026-09-23

- Painel privado com login, proteção CSRF e interface para servidores, canais, associações, modelos e logs.
- Instalação Discord via OAuth2 iniciada no painel e vinculada ao Discord User ID autorizado.
- Servidores adicionados por convite externo permanecem sem autorização; ativação exige verificação no painel.
- Worker YouTube com WebSub e recuperação por playlist/vídeos; linha de base, persistência dos IDs e entregas por servidor.
- Cinco espaços iniciais de API keys, novas entradas ilimitadas, cifragem em repouso, medição por chave e uso sequencial com espera/failover em erro ou cota.
- Notificação única para live programada detectada, live já iniciada ou vídeo/Short novo.
- Implantação Docker Compose com porta local 8081 e dados separados do Auto Server.
