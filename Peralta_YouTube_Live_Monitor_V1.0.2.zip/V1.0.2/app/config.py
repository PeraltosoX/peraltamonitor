import os
import re
from pathlib import Path

DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
DB_PATH = DATA_DIR / "monitor.sqlite3"
APP_DOMAIN = os.getenv("APP_DOMAIN", "").strip().lower()
DISCORD_APPLICATION_ID = os.getenv("DISCORD_APPLICATION_ID", "").strip()
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "").strip()
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "").strip()
DISCORD_OWNER_USER_ID = os.getenv("DISCORD_OWNER_USER_ID", "").strip()
DISCORD_REDIRECT_URI = f"https://{APP_DOMAIN}/auth/discord/callback" if APP_DOMAIN else ""
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY", "").strip()
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "peralta.admin").strip()
ADMIN_PASSWORD_HASH = os.getenv("ADMIN_PASSWORD_HASH", "").strip()
APP_SECRET = os.getenv("APP_SECRET", "").strip()
WEB_SUB_SECRET = os.getenv("WEB_SUB_SECRET", "").strip()
WEB_SUB_CALLBACK = f"https://{APP_DOMAIN}/websub" if APP_DOMAIN else ""


def require(*names):
    missing = [name for name in names if not globals()[name] or globals()[name].startswith("COLE_AQUI_")]
    if missing:
        raise RuntimeError("Configuração ausente: " + ", ".join(missing))
    for name in ("DISCORD_APPLICATION_ID", "DISCORD_OWNER_USER_ID"):
        if name in names and not re.fullmatch(r"[0-9]{16,22}", globals()[name]):
            raise RuntimeError(f"{name} deve ser um ID numérico do Discord")
    if "APP_DOMAIN" in names and not re.fullmatch(r"[a-z0-9.-]+", APP_DOMAIN):
        raise RuntimeError("APP_DOMAIN deve conter apenas o nome do domínio")
    if "APP_SECRET" in names and len(APP_SECRET) < 32:
        raise RuntimeError("APP_SECRET deve ter pelo menos 32 caracteres")
