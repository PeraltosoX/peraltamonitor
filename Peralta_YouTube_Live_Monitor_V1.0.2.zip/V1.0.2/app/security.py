import base64
import hashlib
import hmac
import json
import secrets
import time
from getpass import getpass

from .config import ADMIN_PASSWORD_HASH, APP_SECRET


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt:16384:8:1:{salt.hex()}:{digest.hex()}"


def verify_password(password):
    try:
        algorithm, n, r, p, salt, expected = ADMIN_PASSWORD_HASH.split(":")
        if algorithm != "scrypt":
            return False
        got = hashlib.scrypt(password.encode("utf-8"), salt=bytes.fromhex(salt),
                             n=int(n), r=int(r), p=int(p))
        return hmac.compare_digest(got, bytes.fromhex(expected))
    except (ValueError, TypeError):
        return False


def sign_session():
    payload = {"sid": secrets.token_urlsafe(16), "exp": int(time.time()) + 8 * 3600}
    data = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).rstrip(b"=")
    sig = hmac.new(APP_SECRET.encode(), data, hashlib.sha256).hexdigest()
    return data.decode() + "." + sig


def read_session(token):
    try:
        data, sig = token.rsplit(".", 1)
        expect = hmac.new(APP_SECRET.encode(), data.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expect, sig):
            return None
        raw = base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))
        payload = json.loads(raw)
        return payload if payload["exp"] > time.time() else None
    except (ValueError, KeyError, TypeError):
        return None


def csrf_token(payload):
    return hmac.new(APP_SECRET.encode(), ("csrf:" + payload["sid"]).encode(), hashlib.sha256).hexdigest()


if __name__ == "__main__":
    password = getpass("Nova senha do painel (mínimo 12 caracteres): ")
    repeated = getpass("Repita a senha: ")
    if len(password) < 12 or password != repeated:
        raise SystemExit("Senha curta ou confirmação diferente")
    print(hash_password(password))
