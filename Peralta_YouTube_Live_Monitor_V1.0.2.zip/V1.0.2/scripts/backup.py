"""Backup consistente do SQLite em execução: python -m scripts.backup DESTINO.sqlite3"""
import sqlite3
import sys
from pathlib import Path

from app.config import DB_PATH


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python -m scripts.backup /data/backup/monitor-AAAAMMDD.sqlite3")
    target = Path(sys.argv[1]).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target == DB_PATH.resolve():
        raise SystemExit("Destino deve ser diferente do banco em uso")
    with sqlite3.connect(DB_PATH) as source, sqlite3.connect(target) as backup:
        source.backup(backup)
    print(f"Backup: {target}")


if __name__ == "__main__":
    main()
