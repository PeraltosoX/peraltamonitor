"use strict";

const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const state = {csrf:"", view:"dashboard", guilds:[], channels:[], templates:[], subscriptions:[], apiKeys:[]};
const date = (stamp) => stamp ? new Date(stamp * 1000).toLocaleString("pt-BR") : "—";

function toast(message, error=false) {
  const node = $("#toast"); node.textContent = message; node.className = `toast${error ? " error-toast" : ""}`;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.add("hidden"), 5300);
}
async function api(path, method="GET", data) {
  const options = {method, credentials:"same-origin", headers:{}};
  if (method !== "GET") options.headers["X-CSRF-Token"] = state.csrf;
  if (data !== undefined) {options.headers["Content-Type"] = "application/json"; options.body = JSON.stringify(data);}
  const response = await fetch(path, options);
  let result = null;
  try {result = await response.json();} catch (_) {throw Error(`Resposta inesperada: HTTP ${response.status}`);}
  if (!response.ok) {
    if (response.status === 401) showLogin();
    throw Error(typeof result.detail === "string" ? result.detail : `HTTP ${response.status}`);
  }
  return result;
}
function showLogin() {$("#login").classList.remove("hidden"); $("#app").classList.add("hidden");}
function showApp(session) {
  state.csrf = session.csrf; $("#user-name").textContent = session.username;
  $("#side-version").textContent = `V${session.version}`;
  $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");
  if (new URL(location.href).searchParams.has("installed")) {
    history.replaceState({}, "", "/"); toast("Instalação autorizada. Configure e ative o servidor abaixo."); navigate("discord");
  } else refresh();
}
function navigate(view) {
  state.view = view;
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el.id === view));
  document.querySelectorAll("#nav button").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  const names = {dashboard:"Visão geral",discord:"Discord e servidores",youtube:"Canais YouTube",subscriptions:"Associações",templates:"Mensagem e embed",apis:"APIs do YouTube",activity:"Atividade e logs",settings:"Configurações"};
  $("#page-name").textContent = names[view];
  $("#page-sub").textContent = view === "dashboard" ? "Seus servidores e publicações em um só lugar" : "Peralta YouTube Live Monitor";
  refresh();
}
async function refresh() {
  try {
    if (state.view === "dashboard") return renderDashboard(await api("/api/dashboard"));
    if (state.view === "discord") return await loadDiscord();
    if (state.view === "youtube") return await loadYouTube();
    if (state.view === "subscriptions") return await loadSubscriptions();
    if (state.view === "templates") return await loadTemplates();
    if (state.view === "apis") return await loadApiKeys();
    if (state.view === "activity") return renderActivity(await api("/api/activity"));
    if (state.view === "settings") return renderSettings(await api("/api/settings"));
  } catch (error) {toast(error.message, true);}
}
function renderDashboard(data) {
  const stats = [["Servidores ativos",data.authorized_guilds],["Canais YouTube",data.youtube_channels],["Associações",data.subscriptions],["Avisos enviados",data.deliveries]];
  $("#stats").innerHTML = stats.map(([label,value]) => `<div class="stat"><strong>${value}</strong><span>${label}</span></div>`).join("");
  $("#services").innerHTML = ["web","worker","bot"].map(name => {
    const item = data.heartbeats.find(h => h.service === name);
    const online = item && Date.now()/1000 - item.at < 90;
    return `<div class="row log"><span class="pill ${online ? "good" : "bad"}">${online ? "Ativo" : "Sem sinal"}</span><strong>${name}</strong><small>${escapeHTML(item?.detail || "Ainda não iniciou")}</small></div>`;
  }).join("") + `<p class="muted">Consultas estimadas hoje: ${data.quota_estimate}. Pendências: ${data.pending}. Recuperação: ${data.interval}s.</p>`;
  $("#recent").innerHTML = data.recent.length ? data.recent.map(l => `<div class="log"><small>${date(l.at)} · ${escapeHTML(l.service)}</small>${escapeHTML(l.message)}</div>`).join("") : `<div class="empty">Nenhuma atividade ainda.</div>`;
}
async function loadDiscord() {
  const [info, guilds, templates] = await Promise.all([api("/api/discord"),api("/api/guilds"),api("/api/templates")]);
  state.guilds = guilds; state.templates = templates;
  $("#discord-summary").textContent = `Application ID: ${info.application_id} · Seu Discord User ID: ${info.owner_user_id} · Token: ${info.token_configured ? "configurado" : "ausente"}`;
  $("#guild-list").innerHTML = guilds.length ? guilds.map(g => {
    const channelOptions = g.channels.map(c => `<option value="${escapeHTML(c.channel_id)}" ${g.target_channel_id === c.channel_id ? "selected" : ""}>#${escapeHTML(c.name)} ${!c.can_send ? "(sem envio)" : !c.can_embed ? "(sem permissão para prévia)" : ""}</option>`).join("");
    const templateOptions = templates.map(t => `<option value="${t.id}" ${g.template_id === t.id ? "selected" : ""}>${escapeHTML(t.name)}</option>`).join("");
    return `<article class="item" data-guild="${escapeHTML(g.guild_id)}"><div class="item-head"><div><h2>${escapeHTML(g.name)}</h2><small class="mono">${escapeHTML(g.guild_id)}</small></div><span class="pill ${g.active && g.present ? "good" : g.owner_verified ? "warn" : "bad"}">${g.active && g.present ? "Autorizado" : g.owner_verified ? "Aguardando ativação" : "Bloqueado"}</span></div><p>${g.present ? "Bot presente" : "Bot ausente"} · ${g.owner_verified ? "ID do proprietário verificado" : "Instalação não verificada no painel"}</p><div class="grid-form"><label>Canal de avisos<select name="target"><option value="">Selecione o canal</option>${channelOptions}</select></label><label>Modelo<select name="template">${templateOptions}</select></label><label class="check"><input type="checkbox" name="active" ${g.active ? "checked" : ""} ${!g.owner_verified || !g.present ? "disabled" : ""}> Servidor ativo</label><label class="check"><input type="checkbox" name="uploads" ${g.notify_uploads ? "checked" : ""}> Avisar vídeos e Shorts</label><label class="check"><input type="checkbox" name="scheduled" ${g.notify_scheduled ? "checked" : ""}> Avisar lives agendadas / ao vivo</label><label class="check"><input type="checkbox" name="everyone" ${g.mention_everyone ? "checked" : ""}> Permitir @everyone</label></div><div class="actions"><button class="primary" data-guild-save>Salvar servidor</button><button class="outline" data-guild-test ${!g.active || !g.target_channel_id ? "disabled" : ""}>Enviar teste</button></div></article>`;
  }).join("") : `<div class="empty card">Nenhum servidor conectado. Use “Adicionar ao servidor” acima.</div>`;
}
async function loadYouTube() {
  state.channels = await api("/api/youtube-channels");
  $("#youtube-list").innerHTML = state.channels.length ? state.channels.map(c => `<article class="item" data-youtube="${escapeHTML(c.channel_id)}"><div class="item-head"><div><h2>${escapeHTML(c.name)}</h2><small class="mono">${escapeHTML(c.channel_id)}</small></div><span class="pill ${c.active ? "good" : "warn"}">${c.active ? "Monitorando" : "Pausado"}</span></div><p>Playlist: ${date(c.last_poll)} · Busca de lives agendadas: ${date(c.last_upcoming_search)} · ${c.last_error ? `Erro: ${escapeHTML(c.last_error)}` : "Sem erro recente"}</p><div class="actions"><button class="outline small" data-youtube-toggle>${c.active ? "Pausar" : "Retomar"}</button><button class="outline small" data-youtube-check ${c.active ? "" : "disabled"}>Verificar lives agendadas agora</button></div></article>`).join("") : `<div class="empty card">Cadastre seu primeiro Channel ID para começar.</div>`;
}
async function loadSubscriptions() {
  const [guilds, channels, subscriptions] = await Promise.all([api("/api/guilds"),api("/api/youtube-channels"),api("/api/subscriptions")]);
  state.guilds = guilds; state.channels = channels; state.subscriptions = subscriptions;
  $("#subscription-guild").innerHTML = guilds.filter(g => g.active && g.present && g.owner_verified).map(g => `<option value="${escapeHTML(g.guild_id)}">${escapeHTML(g.name)}</option>`).join("");
  $("#subscription-channel").innerHTML = channels.map(c => `<option value="${escapeHTML(c.channel_id)}">${escapeHTML(c.name)}</option>`).join("");
  $("#subscription-list").innerHTML = subscriptions.length ? subscriptions.map(s => `<article class="item" data-sub-guild="${escapeHTML(s.guild_id)}" data-sub-channel="${escapeHTML(s.channel_id)}"><div class="item-head"><div><h2>${escapeHTML(s.guild_name)} → ${escapeHTML(s.youtube_name)}</h2><small class="mono">${escapeHTML(s.channel_id)}</small></div><span class="pill ${s.active ? "good" : "warn"}">${s.active ? "Ativa" : "Pausada"}</span></div><p>Notificar publicações criadas após: ${date(s.notify_after)}</p><div class="actions"><button class="outline small" data-sub-toggle>${s.active ? "Pausar" : "Reativar"}</button></div></article>`).join("") : `<div class="empty card">Nenhuma associação cadastrada.</div>`;
}
function previewTemplate() {
  const values = {"{tipo}":"LIVE AGENDADA","{canal}":"Canal de exemplo","{titulo}":"Próxima live especial","{link}":"https://www.youtube.com/watch?v=exemplo","{live_id}":"exemplo12345","{data}":"25/09/2026 às 20:00","{hora}":"25/09/2026 às 20:00","{everyone}":"@everyone\n"};
  const substitute = text => Object.entries(values).reduce((s,[key,value]) => s.replaceAll(key,value),text || "");
  const content = substitute($("#template-content").value), title = substitute($("#template-title").value), description = substitute($("#template-description").value);
  const footer = substitute($("#template-footer").value), image = substitute($("#template-image").value);
  const youtube = $("#template-preview-mode").value === "youtube";
  const message = youtube && !content.split("\n").some(line => line.trim() === values["{link}"]) ? `${content}\n\n${values["{link}"]}` : content;
  $("#template-preview").innerHTML = youtube ? `${escapeHTML(message)}<p class="muted">▶ Prévia grande do YouTube aparece no Discord ao enviar.</p>` : `${escapeHTML(content)}${title ? `<h3>${escapeHTML(title)}</h3>` : ""}${description ? `<div>${escapeHTML(description)}</div>` : ""}${footer ? `<p class="muted">${escapeHTML(footer)}</p>` : ""}${image ? `<small>Imagem: ${escapeHTML(image)}</small>` : ""}`;
  $("#template-preview").style.borderLeftColor = $("#template-color").value;
  $("#template-lines").innerHTML = $("#template-content").value.split("\n").map((line,i) => `<div class="drag-line" draggable="true" data-line="${i}"><span>⠿</span> ${escapeHTML(line || "(linha vazia)")}</div>`).join("");
}
function selectTemplate() {
  const template = state.templates.find(t => String(t.id) === $("#template-select").value);
  if (!template) return;
  $("#template-name").value = template.name; $("#template-content").value = template.content;
  $("#template-preview-mode").value = template.preview_mode;
  $("#template-title").value = template.embed_title; $("#template-description").value = template.embed_description;
  $("#template-footer").value = template.embed_footer; $("#template-image").value = template.embed_image;
  $("#template-color").value = `#${template.embed_color.toString(16).padStart(6,"0")}`;
  previewTemplate();
}
async function loadTemplates(selected) {
  state.templates = await api("/api/templates");
  $("#template-select").innerHTML = state.templates.map(t => `<option value="${t.id}">${escapeHTML(t.name)}</option>`).join("");
  if (selected) $("#template-select").value = String(selected);
  selectTemplate();
}
async function loadApiKeys() {
  state.apiKeys = await api("/api/api-keys");
  $("#api-list").innerHTML = state.apiKeys.map(key => {
    const percent = Math.min(100, Math.round(key.calls / key.quota_limit * 100));
    const badge = key.current ? "Em uso" : key.retry_after > Date.now()/1000 ? "Em espera" : key.active ? "Próxima" : "Inativa";
    const summary = `<div class="item-head"><div><h2>${escapeHTML(key.name)}</h2><small>${escapeHTML(key.masked)} · ${key.project_id ? `Projeto ${escapeHTML(key.project_id)}` : "Projeto não informado"}</small></div><span class="pill ${key.current ? "good" : key.active ? "warn" : "bad"}">${badge}</span></div><p>Chamadas estimadas hoje: ${key.calls} / ${key.quota_limit} · Restante: ${key.remaining} · Último uso: ${date(key.last_used)} ${key.last_error ? `· Erro: ${escapeHTML(key.last_error)}` : ""}${key.retry_after > Date.now()/1000 ? ` · Nova tentativa: ${date(key.retry_after)}` : ""}</p><div class="meter"><span style="width:${percent}%"></span></div>`;
    if (key.id === 0) return `<article class="item">${summary}<p class="muted">Chave de reserva configurada no .env da VPS.</p><button class="outline small" data-api-test="0">Testar</button></article>`;
    return `<article class="item" data-api-id="${key.id}">${summary}<div class="grid-form"><label>Nome<input name="name" value="${escapeHTML(key.name)}" maxlength="80"></label><label>Projeto Google (identificador)<input name="project_id" value="${escapeHTML(key.project_id)}" maxlength="100"></label><label>Chave API (vazio mantém a atual)<input name="key" type="password" autocomplete="new-password" placeholder="${escapeHTML(key.masked)}"></label><label>Limite diário estimado<input name="quota_limit" type="number" min="100" value="${key.quota_limit}"></label><label>Ordem de reserva (menor primeiro)<input name="priority" type="number" min="1" value="${key.priority}"></label><label class="check"><input name="active" type="checkbox" ${key.active ? "checked" : ""}> Ativa</label></div><div class="actions"><button class="primary" data-api-save>Salvar</button><button class="outline" data-api-primary ${!key.configured ? "disabled" : ""}>Usar primeiro</button><button class="outline" data-api-test="${key.id}" ${!key.configured ? "disabled" : ""}>Testar</button><button class="danger" data-api-delete>Excluir</button></div></article>`;
  }).join("");
}
function renderActivity(data) {
  $("#delivery-list").innerHTML = data.deliveries.length ? `<table><thead><tr><th>Quando</th><th>Vídeo</th><th>Servidor</th><th>Estado</th><th>Ação</th></tr></thead><tbody>${data.deliveries.map(d => `<tr data-delivery="${d.id}"><td>${date(d.created_at)}</td><td class="title">${escapeHTML(d.title)}</td><td>${escapeHTML(d.guild_name)}</td><td><span class="pill ${d.status === "sent" ? "good" : d.status === "failed" || d.status === "uncertain" ? "bad" : "warn"}">${escapeHTML(d.status)}</span><small>${escapeHTML(d.error || "")}</small></td><td>${["failed","uncertain"].includes(d.status) ? `<button class="outline small" data-retry>Reenviar</button>` : ""}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">Nenhuma entrega até agora.</div>`;
  $("#log-list").innerHTML = data.logs.length ? data.logs.map(l => `<div class="log"><small>${date(l.at)} · ${escapeHTML(l.level)} · ${escapeHTML(l.service)}</small>${escapeHTML(l.message)}</div>`).join("") : `<div class="empty">Sem logs.</div>`;
}
function renderSettings(data) {
  $("#settings-form").elements.playlist_interval.value = data.playlist_interval;
  $("#settings-form").elements.timezone.value = data.timezone;
  $("#settings-summary").innerHTML = `<p>Chave Google: <span class="pill ${data.google_key_configured ? "good" : "bad"}">${data.google_key_configured ? "configurada" : "ausente"}</span></p><p>Chamadas YouTube estimadas hoje: <strong>${data.quota_estimate}</strong></p><p>Buscas de lives agendadas: <strong>${data.upcoming_searches} / ${data.upcoming_search_limit}</strong> hoje (limite local de chamadas).</p>`;
}

$("#login-form").addEventListener("submit", async event => {
  event.preventDefault(); $("#login-error").textContent = "";
  const form = new FormData(event.currentTarget);
  try {
    const response = await fetch("/api/login", {method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:form.get("username"),password:form.get("password")})});
    const data = await response.json();
    if (!response.ok) throw Error(data.detail || "Falha no login");
    $("#login-form").reset(); showApp(await api("/api/session"));
  } catch (error) {$("#login-error").textContent = error.message;}
});
$("#logout").addEventListener("click", async () => {try {await api("/api/logout","POST"); showLogin();} catch (e) {toast(e.message,true);}});
$("#nav").addEventListener("click", e => {const button=e.target.closest("button[data-view]"); if(button) navigate(button.dataset.view);});
document.addEventListener("click", e => {if(e.target.closest("[data-refresh]")) refresh();});
$("#invite").addEventListener("click", async () => {try {const data=await api("/api/discord/install","POST"); location.href=data.url;} catch(e) {toast(e.message,true);}});
$("#guild-list").addEventListener("click", async e => {
  const item=e.target.closest("[data-guild]"); if(!item) return;
  const guildId=item.dataset.guild;
  try {
    if(e.target.closest("[data-guild-save]")) {
      const read=name => item.querySelector(`[name="${name}"]`);
      await api(`/api/guilds/${encodeURIComponent(guildId)}`,"PATCH",{target_channel_id:read("target").value,template_id:Number(read("template").value),active:read("active").checked,notify_uploads:read("uploads").checked,notify_scheduled:read("scheduled").checked,mention_everyone:read("everyone").checked});
      toast("Servidor salvo"); await loadDiscord();
    }
    if(e.target.closest("[data-guild-test]")) {await api(`/api/guilds/${encodeURIComponent(guildId)}/test`,"POST");toast("Teste enviado à fila");}
  } catch(error) {toast(error.message,true);}
});
$("#channel-form").addEventListener("submit", async e => {e.preventDefault();try {await api("/api/youtube-channels","POST",{channel_id:e.target.elements.channel_id.value.trim()});e.target.reset();toast("Canal cadastrado; vídeos existentes registrados como linha de base");await loadYouTube();} catch(error) {toast(error.message,true);}});
$("#youtube-list").addEventListener("click", async e => {
  const item=e.target.closest("[data-youtube]"); if(!item) return;
  const channel=state.channels.find(c=>c.channel_id===item.dataset.youtube);
  try {
    if(e.target.closest("[data-youtube-toggle]")) {
      await api(`/api/youtube-channels/${encodeURIComponent(channel.channel_id)}`,"PATCH",{active:!channel.active});
      await loadYouTube();
    } else if(e.target.closest("[data-youtube-check]")) {
      const result=await api(`/api/youtube-channels/${encodeURIComponent(channel.channel_id)}/check`,"POST");
      toast(`${result.found} live(s) agendada(s) encontrada(s), ${result.new} nova(s), ${result.queued} aviso(s) na fila. Conteúdo anterior à associação não é avisado.`);
      await loadYouTube();
    }
  } catch(error) {toast(error.message,true);}
});
$("#subscription-form").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/subscriptions","POST",{guild_id:e.target.elements.guild_id.value,channel_id:e.target.elements.channel_id.value});toast("Associação ativada. Conteúdo antigo não será enviado; apenas publicações novas.");await loadSubscriptions();}catch(error){toast(error.message,true);}});
$("#subscription-list").addEventListener("click",async e=>{const item=e.target.closest("[data-sub-guild]");if(!item||!e.target.closest("[data-sub-toggle]"))return;try{const sub=state.subscriptions.find(s=>s.guild_id===item.dataset.subGuild&&s.channel_id===item.dataset.subChannel);if(sub.active)await api(`/api/subscriptions/${encodeURIComponent(sub.guild_id)}/${encodeURIComponent(sub.channel_id)}`,"DELETE");else await api("/api/subscriptions","POST",{guild_id:sub.guild_id,channel_id:sub.channel_id});await loadSubscriptions();}catch(error){toast(error.message,true);}});
$("#template-select").addEventListener("change",selectTemplate);
["#template-content","#template-title","#template-description","#template-footer","#template-image","#template-color","#template-preview-mode"].forEach(id=>$(id).addEventListener("input",previewTemplate));
$("#template-lines").addEventListener("dragstart", e => {const row=e.target.closest("[data-line]");if(!row)return;e.dataTransfer.setData("text/plain",row.dataset.line);e.dataTransfer.effectAllowed="move";});
$("#template-lines").addEventListener("dragover", e => {if(e.target.closest("[data-line]"))e.preventDefault();});
$("#template-lines").addEventListener("drop", e => {const row=e.target.closest("[data-line]");if(!row)return;e.preventDefault();const from=Number(e.dataTransfer.getData("text/plain")),to=Number(row.dataset.line),lines=$("#template-content").value.split("\n");if(!Number.isInteger(from)||from<0||from>=lines.length||to<0||to>=lines.length)return;lines.splice(to,0,lines.splice(from,1)[0]);$("#template-content").value=lines.join("\n");previewTemplate();});
const templateData=()=>({name:$("#template-name").value,content:$("#template-content").value,preview_mode:$("#template-preview-mode").value,embed_title:$("#template-title").value,embed_description:$("#template-description").value,embed_footer:$("#template-footer").value,embed_image:$("#template-image").value,embed_color:parseInt($("#template-color").value.slice(1),16)});
$("#template-save").addEventListener("click",async()=>{try{await api(`/api/templates/${$("#template-select").value}`,"PATCH",templateData());toast("Modelo atualizado");await loadTemplates($("#template-select").value);}catch(error){toast(error.message,true);}});
$("#template-new").addEventListener("click",async()=>{try{const data=templateData();data.name=`Cópia de ${data.name}`.slice(0,80);const result=await api("/api/templates","POST",data);toast("Modelo criado");await loadTemplates(result.id);}catch(error){toast(error.message,true);}});
$("#api-add").addEventListener("click",async()=>{try{await api("/api/api-keys","POST",{name:`API ${String(state.apiKeys.length+1).padStart(2,"0")}`});await loadApiKeys();toast("Espaço para API criado");}catch(error){toast(error.message,true);}});
$("#api-list").addEventListener("click",async e=>{
  const item=e.target.closest("[data-api-id]");
  const test=e.target.closest("[data-api-test]");
  try {
    if(test) {await api(`/api/api-keys/${test.dataset.apiTest}/test`,"POST");toast("Chave validada");await loadApiKeys();return;}
    if(!item)return;
    const id=item.dataset.apiId, field=name=>item.querySelector(`[name="${name}"]`);
    const data={name:field("name").value,project_id:field("project_id").value,key:field("key").value,quota_limit:Number(field("quota_limit").value),priority:Number(field("priority").value),active:field("active").checked};
    if(e.target.closest("[data-api-save]")){await api(`/api/api-keys/${id}`,"PATCH",data);toast("Credencial salva");}
    else if(e.target.closest("[data-api-primary]")){await api(`/api/api-keys/${id}`,"PATCH",{...data,active:true,primary:true});toast("Chave principal alterada");}
    else if(e.target.closest("[data-api-delete]")){if(!confirm("Excluir esta credencial? O histórico de chamadas permanece."))return;await api(`/api/api-keys/${id}`,"DELETE");toast("Credencial excluída");}
    else return;
    await loadApiKeys();
  }catch(error){toast(error.message,true);}
});
$("#delivery-list").addEventListener("click",async e=>{const item=e.target.closest("[data-delivery]");if(!item||!e.target.closest("[data-retry]"))return;try{await api(`/api/deliveries/${item.dataset.delivery}/retry`,"POST");toast("Reenvio solicitado; confira antes se não chegou ao Discord");await refresh();}catch(error){toast(error.message,true);}});
$("#settings-form").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/settings","PATCH",{playlist_interval:Number(e.target.elements.playlist_interval.value),timezone:e.target.elements.timezone.value});toast("Configurações salvas");await refresh();}catch(error){toast(error.message,true);}});
api("/api/session").then(showApp).catch(showLogin);
