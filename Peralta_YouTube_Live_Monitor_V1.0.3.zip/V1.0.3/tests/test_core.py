"""Run: PYTHONPATH=/tmp/peralta-monitor-deps:. python -m unittest discover -s tests -v"""
import os
import asyncio
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from urllib.parse import parse_qs, urlparse
from unittest.mock import patch

DATA = tempfile.TemporaryDirectory(prefix="peralta-test-")
os.environ.update({
    "DATA_DIR": DATA.name, "APP_DOMAIN": "peraltamonitor.peraltaultrachat.shop",
    "APP_SECRET": "a" * 64, "ADMIN_PASSWORD_HASH": "test-hash",
    "DISCORD_APPLICATION_ID": "1552171810949308426", "DISCORD_CLIENT_SECRET": "test-secret",
    "DISCORD_OWNER_USER_ID": "987654321012345678", "YOUTUBE_API_KEY": "test-key",
    "WEB_SUB_SECRET": "b" * 64,
})

from fastapi.testclient import TestClient
from app import db, security, youtube, web, api_keys, bot

ORIGIN = "https://peraltamonitor.peraltaultrachat.shop"
CID = "UC" + "a" * 22


def video(video_id, state="none", scheduled=None, published="2026-09-23T10:00:00Z"):
    return {"id": video_id, "snippet": {"channelId": CID, "title": "Novo vídeo",
            "liveBroadcastContent": state, "publishedAt": published},
            "liveStreamingDetails": {"scheduledStartTime": scheduled} if scheduled else {},
            "status": {"privacyStatus": "public"}}


class FakeResponse:
    def __init__(self, content, status_code=200): self.content = content; self.status_code = status_code
    def json(self): return self.content


class FakeOAuthClient:
    def __init__(self, *args, user_id="987654321012345678", **kwargs): self.user_id = user_id
    async def __aenter__(self): return self
    async def __aexit__(self, *args): pass
    async def post(self, *args, **kwargs):
        return FakeResponse({"access_token": "dummy", "guild": {"id": "222222222222222222", "name": "Teste"}})
    async def get(self, *args, **kwargs): return FakeResponse({"id": self.user_id})


class CoreTests(unittest.TestCase):
    def setUp(self):
        db.write("DELETE FROM api_key_usage")
        db.write("DELETE FROM search_usage")
        db.write("UPDATE templates SET preview_mode='youtube' WHERE id=1")
        db.write("UPDATE api_credentials SET encrypted_key=NULL,last4='',active=0,primary_flag=0,"
                 "retry_after=0,last_error='' ")
        for table in ("deliveries", "videos", "subscriptions", "discord_channels", "guilds",
                      "youtube_channels", "oauth_states"):
            db.write(f"DELETE FROM {table}")
        db.write("INSERT INTO youtube_channels(channel_id,name,uploads_id,baseline_done,created_at) VALUES(?,?,?,?,?)",
                 (CID, "Canal", "UUtest", 0, db.ts()))
        db.write("INSERT INTO guilds(guild_id,name,present,active,owner_verified,target_channel_id,last_seen) "
                 "VALUES(?,?,?,?,?,?,?)", ("222222222222222222", "Teste", 1, 1, 1, "333333333333333333", db.ts()))
        db.write("INSERT INTO subscriptions(guild_id,channel_id) VALUES(?,?)", ("222222222222222222", CID))

    def test_baseline_dedupe_and_scheduled_once(self):
        self.assertEqual(youtube.store_videos(CID, [video("base1234567")]), (1, 0))
        self.assertEqual(youtube.store_videos(CID, [video("base1234567")]), (0, 0))
        item = video("new12345678", "upcoming", "2026-09-25T20:00:00Z")
        self.assertEqual(youtube.store_videos(CID, [item]), (1, 1))
        self.assertEqual(db.one("SELECT kind FROM videos WHERE video_id=?", (item["id"],))["kind"], "scheduled")
        self.assertEqual(youtube.store_videos(CID, [video(item["id"], "live")]), (0, 0))
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM deliveries")["n"], 1)
        self.assertEqual(youtube.store_videos(CID, [video("up_12345678")]), (1, 1))

    def test_discord_message_uses_video_type_not_delivery_type(self):
        template = db.one("SELECT * FROM templates WHERE id=1")
        item = {"video_kind": "scheduled", "title": "Minha live", "channel_name": "Canal",
                "url": "https://www.youtube.com/watch?v=abc", "video_id": "abc",
                "thumbnail": "https://i.ytimg.com/vi/abc/hqdefault.jpg", "scheduled_at": "2026-09-25T20:00:00Z"}
        content, embed = bot.render(template, item, {"mention_everyone": 0}, "America/Sao_Paulo")
        self.assertIn("LIVE AGENDADA", content)
        self.assertIsNone(embed)
        self.assertEqual(content.count(item["url"]), 1)
        without_link = {**template, "content": "{tipo}: {titulo}"}
        added, _ = bot.render(without_link, item, {"mention_everyone": 0}, "America/Sao_Paulo")
        self.assertTrue(added.endswith(item["url"]))
        custom = {**template, "preview_mode": "custom"}
        _, image_embed = bot.render(custom, item, {"mention_everyone": 0}, "America/Sao_Paulo")
        self.assertEqual(image_embed.image.url, item["thumbnail"])

    def test_youtube_preview_is_sent_as_plain_link_without_custom_embed(self):
        db.write("UPDATE youtube_channels SET baseline_done=1")
        self.assertEqual(youtube.store_videos(CID, [video("new12345678", "upcoming")]), (1, 1))
        delivery = db.one("SELECT id,status FROM deliveries")
        sent = []
        class FakeChannel:
            async def send(self, **kwargs):
                sent.append(kwargs)
                return SimpleNamespace(id=42)
        client = bot.MonitorBot()
        async def destination(guild_id, channel_id):
            return FakeChannel(), SimpleNamespace(embed_links=True, mention_everyone=False)
        client.get_destination = destination
        asyncio.run(client.send_delivery(delivery))
        self.assertEqual(db.one("SELECT status FROM deliveries WHERE id=?", (delivery["id"],))["status"], "sent")
        self.assertNotIn("embed", sent[0])
        self.assertIn("https://www.youtube.com/watch?v=new12345678", sent[0]["content"])

    def test_preview_mode_can_be_changed_in_panel(self):
        token = security.sign_session()
        session = security.read_session(token)
        current = db.one("SELECT * FROM templates WHERE id=1")
        with TestClient(web.app, base_url=ORIGIN) as client:
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            headers = {"Origin": ORIGIN, "X-CSRF-Token": security.csrf_token(session)}
            response = client.patch("/api/templates/1", headers=headers,
                                    json={**current, "preview_mode": "custom"})
            self.assertEqual(response.status_code, 200, response.text)
            self.assertEqual(client.get("/api/templates").json()[0]["preview_mode"], "custom")
            bad = client.patch("/api/templates/1", headers=headers,
                               json={**current, "preview_mode": "invalid"})
            self.assertEqual(bad.status_code, 400)

    def test_association_skips_existing_and_delayed_old_but_sends_new(self):
        db.write("DELETE FROM subscriptions")
        db.write("UPDATE youtube_channels SET baseline_done=1")
        old = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self.assertEqual(youtube.store_videos(CID, [video("old_scheduled", "upcoming", published=old)]), (1, 0))
        token = security.sign_session()
        session = security.read_session(token)
        with TestClient(web.app, base_url=ORIGIN) as client:
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            headers = {"Origin": ORIGIN, "X-CSRF-Token": security.csrf_token(session)}
            response = client.post("/api/subscriptions", headers=headers,
                                   json={"guild_id":"222222222222222222", "channel_id":CID})
            self.assertEqual(response.status_code, 200, response.text)
        self.assertGreater(db.one("SELECT notify_after FROM subscriptions")["notify_after"], 0)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM deliveries")["n"], 0)
        # An older event may appear in YouTube's API only after subscribing.
        self.assertEqual(youtube.store_videos(CID, [video("late_old", "upcoming", published=old)]), (1, 0))
        fresh = datetime.now(timezone.utc).isoformat()
        self.assertEqual(youtube.store_videos(CID, [video("fresh_live", "upcoming", published=fresh)]), (1, 1))
        self.assertEqual(youtube.store_videos(CID, [video("fresh_live", "live", published=fresh)]), (0, 0))
        self.assertEqual(youtube.store_videos(CID, [video("fresh_upload", published=fresh)]), (1, 1))
        self.assertEqual({r["video_id"] for r in db.rows("SELECT video_id FROM deliveries")},
                         {"fresh_live", "fresh_upload"})

    def test_manual_upcoming_check_and_minimum_interval(self):
        token = security.sign_session()
        session = security.read_session(token)
        async def fake_check(channel_id, search_limit=80):
            self.assertEqual(channel_id, CID)
            self.assertEqual(search_limit, 100)
            return {"found": 1, "new": 1, "queued": 1}
        with TestClient(web.app, base_url=ORIGIN) as client:
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            headers = {"Origin": ORIGIN, "X-CSRF-Token": security.csrf_token(session)}
            update = client.patch("/api/settings", json={"playlist_interval": 30}, headers=headers)
            self.assertEqual(update.status_code, 200, update.text)
            self.assertEqual(client.get("/api/settings").json()["playlist_interval"], 30)
            self.assertEqual(client.patch("/api/settings", json={"playlist_interval": 29}, headers=headers).status_code, 400)
            with patch("app.youtube.check_upcoming", fake_check):
                result = client.post(f"/api/youtube-channels/{CID}/check", headers=headers)
            self.assertEqual(result.json()["queued"], 1)

    def test_search_budget_counts_failover_attempts_and_websub_path(self):
        attempts = []
        class FakeClient:
            def __init__(self, *args, **kwargs): pass
            async def __aenter__(self): return self
            async def __aexit__(self, *args): pass
            async def get(self, url, params):
                attempts.append(url)
                return FakeResponse({"items": []})
        import asyncio
        with patch("httpx.AsyncClient", FakeClient):
            asyncio.run(youtube.upcoming_video_ids(CID, search_limit=1))
            with self.assertRaises(youtube.YouTubeError):
                asyncio.run(youtube.upcoming_video_ids(CID, search_limit=1))
        self.assertEqual(len(attempts), 1)
        self.assertEqual(db.search_calls(), 1)
        self.assertEqual(web.websub_channel("https://www.youtube.com/feeds/videos.xml?channel_id=" + CID), CID)
        self.assertIsNone(web.websub_channel("https://www.youtube.com/xml/feeds/videos.xml?channel_id=" + CID))

    def test_panel_assets_health_and_private_api(self):
        with TestClient(web.app, base_url=ORIGIN) as client:
            self.assertEqual(client.get("/health").json()["version"], "1.0.3")
            self.assertIn("Peralta Live Monitor", client.get("/").text)
            for asset in ("app.js", "style.css", "api.css", "editor.css"):
                self.assertEqual(client.get("/static/" + asset).status_code, 200)
            self.assertEqual(client.get("/api/guilds").status_code, 401)

    def test_unverified_server_stays_locked_and_oauth_owner_can_authorize(self):
        db.write("UPDATE guilds SET active=0,owner_verified=0 WHERE guild_id='222222222222222222'")
        with TestClient(web.app, base_url=ORIGIN) as client:
            token = security.sign_session()
            session = security.read_session(token)
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            headers = {"Origin": ORIGIN, "X-CSRF-Token": security.csrf_token(session)}
            payload = {"active": True, "target_channel_id": "333333333333333333"}
            blocked = client.patch("/api/guilds/222222222222222222", json=payload, headers=headers)
            self.assertEqual(blocked.status_code, 400)
            start = client.post("/api/discord/install", headers=headers)
            self.assertEqual(start.status_code, 200)
            link = start.json()["url"]
            params = parse_qs(urlparse(link).query)
            self.assertEqual(params["scope"], ["bot identify"])
            self.assertEqual(params["client_id"], ["1552171810949308426"])
            with patch("httpx.AsyncClient", FakeOAuthClient):
                response = client.get("/auth/discord/callback", params={"state":params["state"][0],"code":"abc"}, follow_redirects=False)
            self.assertEqual(response.status_code, 303, response.text)
            guild = db.one("SELECT active,owner_verified FROM guilds WHERE guild_id='222222222222222222'")
            self.assertEqual((guild["active"],guild["owner_verified"]),(0,1))
            db.write("INSERT INTO discord_channels(channel_id,guild_id,name,can_view,can_send,can_embed,can_mention,last_seen) "
                     "VALUES(?,?,?,?,?,?,?,?)", ("333333333333333333","222222222222222222","avisos",1,1,1,1,db.ts()))
            activated = client.patch("/api/guilds/222222222222222222", json=payload, headers=headers)
            self.assertEqual(activated.status_code, 200, activated.text)

    def test_oauth_rejects_other_discord_user(self):
        db.write("UPDATE guilds SET active=0,owner_verified=0 WHERE guild_id='222222222222222222'")
        token = security.sign_session()
        session = security.read_session(token)
        with TestClient(web.app, base_url=ORIGIN) as client:
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            start = client.post("/api/discord/install", headers={"Origin":ORIGIN,"X-CSRF-Token":security.csrf_token(session)})
            state = parse_qs(urlparse(start.json()["url"]).query)["state"][0]
            with patch("httpx.AsyncClient", lambda *a, **kw: FakeOAuthClient(user_id="123")):
                response = client.get("/auth/discord/callback", params={"state":state,"code":"abc"})
            self.assertEqual(response.status_code, 403)
            self.assertEqual(db.one("SELECT owner_verified FROM guilds WHERE guild_id='222222222222222222'")["owner_verified"],0)

    def test_api_key_failover_and_local_quota(self):
        db.write("UPDATE api_credentials SET encrypted_key=?,last4='1111',active=1,primary_flag=1 WHERE id=1",
                 (api_keys.encrypt("first-key-1111"),))
        db.write("UPDATE api_credentials SET encrypted_key=?,last4='2222',active=1,priority=2 WHERE id=2",
                 (api_keys.encrypt("second-key-2222"),))
        attempts = []

        class FakeYouTubeClient:
            def __init__(self,*args,**kwargs): pass
            async def __aenter__(self): return self
            async def __aexit__(self,*args): pass
            async def get(self,url,params):
                attempts.append(params["key"])
                return FakeResponse({"items":[]}, 403 if params["key"] == "first-key-1111" else 200)

        with patch("httpx.AsyncClient", FakeYouTubeClient):
            result = __import__("asyncio").run(youtube.request("videos", {"part":"id","id":"dQw4w9WgXcQ"}))
        self.assertEqual(result, {"items":[]})
        self.assertEqual(attempts, ["first-key-1111", "second-key-2222"])
        self.assertGreater(db.one("SELECT retry_after FROM api_credentials WHERE id=1")["retry_after"], db.ts())
        self.assertEqual(api_keys.candidates()[0][0], 2)
        self.assertEqual(db.one("SELECT calls FROM api_key_usage WHERE credential_id=1")["calls"], 1)
        self.assertEqual(db.one("SELECT calls FROM api_key_usage WHERE credential_id=2")["calls"], 1)
        self.assertNotIn("first-key", db.one("SELECT encrypted_key FROM api_credentials WHERE id=1")["encrypted_key"])
        db.write("UPDATE api_credentials SET retry_after=0,quota_limit=1 WHERE id=1")
        attempts.clear()
        with patch("httpx.AsyncClient", FakeYouTubeClient):
            __import__("asyncio").run(youtube.request("videos", {"part":"id","id":"dQw4w9WgXcQ"}))
        self.assertEqual(attempts, ["second-key-2222"])

    def test_api_credentials_panel_never_returns_full_secret(self):
        token = security.sign_session()
        session = security.read_session(token)
        with TestClient(web.app, base_url=ORIGIN) as client:
            client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
            headers = {"Origin": ORIGIN, "X-CSRF-Token": security.csrf_token(session)}
            response = client.patch("/api/api-keys/1", headers=headers,
                                    json={"name":"Principal", "key":"private-google-secret-1234",
                                          "active":True, "primary":True,"priority":1})
            self.assertEqual(response.status_code, 200, response.text)
            listing = client.get("/api/api-keys").text
            self.assertIn("••••1234", listing)
            self.assertNotIn("private-google-secret-1234", listing)
            self.assertEqual(api_keys.candidates()[0][0], 1)


if __name__ == "__main__": unittest.main()
