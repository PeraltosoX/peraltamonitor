import asyncio
import re
from datetime import datetime
from zoneinfo import ZoneInfo

import discord

from . import db
from .config import DISCORD_BOT_TOKEN, require


def safe_text(value):
    return discord.utils.escape_markdown(discord.utils.escape_mentions(str(value or "")))


def render(template, video, guild, tz_name):
    kind = {"scheduled": "LIVE AGENDADA", "live": "LIVE AO VIVO",
            "upload": "NOVO VÍDEO"}.get(video["video_kind"], "NOVO VÍDEO")
    date_text = ""
    if video["scheduled_at"]:
        try:
            tz = ZoneInfo(tz_name)
            date_text = datetime.fromisoformat(video["scheduled_at"].replace("Z", "+00:00"))
            date_text = date_text.astimezone(tz).strftime("%d/%m/%Y às %H:%M")
        except (ValueError, KeyError):
            date_text = "Horário a confirmar"
    variables = {"{tipo}": kind, "{canal}": safe_text(video["channel_name"]),
                 "{titulo}": safe_text(video["title"]), "{link}": video["url"],
                 "{live_id}": video["video_id"],
                 "{data}": date_text, "{hora}": date_text,
                 "{everyone}": "@everyone\n" if guild["mention_everyone"] else ""}

    def substitute(value):
        for key, replacement in variables.items():
            value = value.replace(key, replacement)
        return value.strip()

    content = substitute(template["content"])
    if template["preview_mode"] == "youtube":
        # Discord generates its own playable YouTube card from a plain URL.
        # A standalone link also works when the message template omits {link}.
        if video["url"] not in (line.strip() for line in content.splitlines()):
            content = content.rstrip() + "\n\n" + video["url"]
        return content[:2000], None
    content = content[:2000]
    title = substitute(template["embed_title"])[:256]
    description = substitute(template["embed_description"])[:4096]
    footer = substitute(template["embed_footer"])[:2048]
    image_url = substitute(template["embed_image"])
    embed = None
    if title or description or footer or image_url:
        embed = discord.Embed(title=title or None, description=description or None,
                              url=video["url"], color=template["embed_color"])
        if footer:
            embed.set_footer(text=footer)
        if image_url.startswith("https://"):
            embed.set_image(url=image_url)
        elif video["thumbnail"].startswith("https://"):
            embed.set_image(url=video["thumbnail"])
    return content, embed


class MonitorBot(discord.Client):
    def __init__(self):
        intents = discord.Intents.none()
        intents.guilds = True
        super().__init__(intents=intents)
        self.delivery_task = None

    async def on_ready(self):
        ids = {str(guild.id) for guild in self.guilds}
        for guild in self.guilds:
            self.sync_guild(guild)
        with db.transaction() as con:
            if ids:
                placeholders = ",".join("?" for _ in ids)
                con.execute(f"UPDATE guilds SET present=0,active=0,owner_verified=0 "
                            f"WHERE guild_id NOT IN ({placeholders})", tuple(ids))
            else:
                con.execute("UPDATE guilds SET present=0,active=0,owner_verified=0")
        db.log("discord", "info", f"Bot conectado em {len(self.guilds)} servidor(es)")
        if self.delivery_task is None or self.delivery_task.done():
            self.delivery_task = asyncio.create_task(self.deliver_loop())

    def sync_guild(self, guild):
        now = db.ts()
        member = guild.me
        with db.transaction() as con:
            con.execute("INSERT INTO guilds(guild_id,name,present,last_seen) VALUES(?,?,1,?) "
                        "ON CONFLICT(guild_id) DO UPDATE SET name=excluded.name,present=1,last_seen=excluded.last_seen",
                        (str(guild.id), guild.name, now))
            current = set()
            for channel in guild.text_channels:
                p = channel.permissions_for(member) if member else None
                current.add(str(channel.id))
                con.execute("INSERT INTO discord_channels(channel_id,guild_id,name,can_view,can_send,"
                            "can_embed,can_mention,last_seen) VALUES(?,?,?,?,?,?,?,?) "
                            "ON CONFLICT(channel_id) DO UPDATE SET name=excluded.name,"
                            "can_view=excluded.can_view,can_send=excluded.can_send,"
                            "can_embed=excluded.can_embed,can_mention=excluded.can_mention,"
                            "last_seen=excluded.last_seen",
                            (str(channel.id), str(guild.id), channel.name, int(bool(p and p.view_channel)),
                             int(bool(p and p.send_messages)), int(bool(p and p.embed_links)),
                             int(bool(p and p.mention_everyone)), now))
            if current:
                placeholders = ",".join("?" for _ in current)
                con.execute(f"DELETE FROM discord_channels WHERE guild_id=? AND channel_id NOT IN ({placeholders})",
                            (str(guild.id), *current))
            else:
                con.execute("DELETE FROM discord_channels WHERE guild_id=?", (str(guild.id),))

    async def on_guild_join(self, guild):
        self.sync_guild(guild)
        db.log("discord", "info", f"Bot entrou no servidor {guild.id}")

    async def on_guild_remove(self, guild):
        db.write("UPDATE guilds SET present=0,active=0,owner_verified=0,last_seen=? WHERE guild_id=?",
                 (db.ts(), str(guild.id)))
        db.log("discord", "warning", f"Bot saiu do servidor {guild.id}")

    async def on_guild_channel_create(self, channel):
        self.sync_guild(channel.guild)

    async def on_guild_channel_update(self, before, after):
        self.sync_guild(after.guild)

    async def on_guild_channel_delete(self, channel):
        self.sync_guild(channel.guild)

    async def get_destination(self, guild_id, channel_id):
        guild = self.get_guild(int(guild_id))
        if guild is None:
            raise ValueError("Bot não está mais no servidor")
        channel = guild.get_channel(int(channel_id))
        if channel is None:
            raise ValueError("Canal removido ou indisponível")
        if guild.me is None:
            raise PermissionError("Permissões do bot ainda não disponíveis")
        p = channel.permissions_for(guild.me)
        if not p.view_channel or not p.send_messages:
            raise PermissionError("Sem permissão para visualizar/enviar neste canal")
        return channel, p

    async def send_delivery(self, item):
        joined = db.one("SELECT d.*,g.mention_everyone,g.template_id,g.present,g.active,"
                        "v.title,v.url,v.thumbnail,v.kind AS video_kind,v.scheduled_at,y.name AS channel_name "
                        "FROM deliveries d JOIN guilds g ON g.guild_id=d.guild_id "
                        "JOIN videos v ON v.video_id=d.video_id "
                        "JOIN youtube_channels y ON y.channel_id=v.channel_id WHERE d.id=?", (item["id"],))
        if not joined or not joined["present"] or not joined["active"]:
            db.write("UPDATE deliveries SET status='failed',error='Servidor inativo',updated_at=? WHERE id=?",
                     (db.ts(), item["id"]))
            return
        try:
            channel, perms = await self.get_destination(joined["guild_id"], joined["channel_id"])
            template = db.one("SELECT * FROM templates WHERE id=?", (joined["template_id"],))
            if template is None:
                template = db.one("SELECT * FROM templates WHERE id=1")
            content, embed = render(template, joined, joined, db.setting("timezone", "America/Sao_Paulo"))
            if embed and not perms.embed_links:
                embed = None
            everyone = bool(joined["mention_everyone"] and perms.mention_everyone)
            if not everyone:
                content = content.replace("@everyone", "")
            kwargs = {"content": content or None,
                      "allowed_mentions": discord.AllowedMentions(everyone=everyone,
                          users=False, roles=False, replied_user=False), "nonce": item["id"]}
            if embed is not None:
                kwargs["embed"] = embed
            message = await channel.send(**kwargs)
            if embed is None and not perms.embed_links:
                db.log("discord", "warning", f"Canal {joined['channel_id']} sem permissão Embed Links; prévia do YouTube pode não aparecer")
            db.write("UPDATE deliveries SET status='sent',message_id=?,error=NULL,updated_at=? WHERE id=?",
                     (str(message.id), db.ts(), item["id"]))
            db.log("discord", "info", f"Vídeo {joined['video_id']} enviado ao servidor {joined['guild_id']}")
        except (ValueError, PermissionError, discord.Forbidden, discord.NotFound) as exc:
            db.write("UPDATE deliveries SET status='failed',error=?,updated_at=? WHERE id=?",
                     (str(exc)[:250], db.ts(), item["id"]))
        except Exception as exc:
            # Unknown outcome: avoid an automatic duplicate after a timeout/crash.
            db.write("UPDATE deliveries SET status='uncertain',error=?,updated_at=? WHERE id=?",
                     (f"Resultado incerto ({type(exc).__name__}); confira o Discord antes de reenviar", db.ts(), item["id"]))

    async def send_test(self, item):
        try:
            channel, p = await self.get_destination(item["guild_id"], item["channel_id"])
            message = await channel.send("✅ Teste do Peralta YouTube Live Monitor. Este canal pode receber avisos.",
                allowed_mentions=discord.AllowedMentions.none())
            db.write("UPDATE test_requests SET status='sent',message_id=?,updated_at=? WHERE id=?",
                     (str(message.id), db.ts(), item["id"]))
        except Exception as exc:
            db.write("UPDATE test_requests SET status='failed',error=?,updated_at=? WHERE id=?",
                     (f"{type(exc).__name__}: {str(exc)[:160]}", db.ts(), item["id"]))

    async def deliver_loop(self):
        while not self.is_closed():
            db.heartbeat("bot", f"Conectado a {len(self.guilds)} servidores")
            try:
                for item in db.rows("SELECT id FROM deliveries WHERE status='pending' AND next_try<=? "
                                    "ORDER BY created_at LIMIT 10", (db.ts(),)):
                    if db.write("UPDATE deliveries SET status='sending',attempts=attempts+1,updated_at=? "
                                "WHERE id=? AND status='pending'", (db.ts(), item["id"])):
                        await self.send_delivery(item)
                for item in db.rows("SELECT * FROM test_requests WHERE status='pending' ORDER BY id LIMIT 10"):
                    if db.write("UPDATE test_requests SET status='sending',updated_at=? "
                                "WHERE id=? AND status='pending'", (db.ts(), item["id"])):
                        await self.send_test(item)
            except Exception as exc:
                db.log("discord", "error", f"Fila: {type(exc).__name__}")
            await asyncio.sleep(3)


def main():
    require("DISCORD_BOT_TOKEN")
    db.init_db()
    # A message in flight when the container died has an unknown outcome.
    db.write("UPDATE deliveries SET status='uncertain',error='Bot reiniciado durante envio',updated_at=? "
             "WHERE status='sending'", (db.ts(),))
    db.write("UPDATE test_requests SET status='failed',error='Bot reiniciado',updated_at=? "
             "WHERE status='sending'", (db.ts(),))
    MonitorBot().run(DISCORD_BOT_TOKEN, log_handler=None)


if __name__ == "__main__":
    main()
