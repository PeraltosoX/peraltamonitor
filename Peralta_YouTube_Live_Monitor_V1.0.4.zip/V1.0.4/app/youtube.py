import httpx
from datetime import datetime

from . import db, api_keys

BASE = "https://www.googleapis.com/youtube/v3"
HUB = "https://pubsubhubbub.appspot.com/subscribe"


class YouTubeError(Exception):
    pass


async def request(method, params, credential_id=None, search_limit=100):
    try:
        if credential_id is None:
            candidates = api_keys.candidates()
        elif credential_id == 0:
            from .config import YOUTUBE_API_KEY
            candidates = [(0, YOUTUBE_API_KEY)] if YOUTUBE_API_KEY else []
        else:
            row = db.one("SELECT encrypted_key FROM api_credentials WHERE id=?", (credential_id,))
            if not row or not row["encrypted_key"]:
                raise YouTubeError("Chave não configurada")
            candidates = [(credential_id, api_keys.decrypt(row["encrypted_key"]))]
    except RuntimeError as exc:
        raise YouTubeError(str(exc)) from exc
    if not candidates:
        raise YouTubeError("Nenhuma chave API ativa disponível; confira cota e espera no painel")
    last_error = ""
    skipped_search_keys = 0
    for key_id, key in candidates:
        if method == "search" and not db.reserve_search_call(key_id, search_limit):
            skipped_search_keys += 1
            continue
        # Key stays in the backend. Never put the URL/headers in a log or error.
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                response = await client.get(f"{BASE}/{method}", params={**params, "key": key})
        except httpx.HTTPError:
            last_error = "Falha de rede"
            api_keys.mark_result(key_id, last_error, db.ts() + 120)
            db.log("api", "warning", f"Credencial {key_id} indisponível na rede; tentando próxima")
            continue
        db.record_api_call(key_id)  # Failed requests may also consume quota.
        if response.status_code == 200:
            api_keys.mark_result(key_id)
            return response.json()
        last_error = f"HTTP {response.status_code}"
        retry_at = (api_keys.next_reset() if response.status_code in (403, 429)
                    else db.ts() + (3600 if response.status_code in (400, 401) else 300))
        api_keys.mark_result(key_id, last_error, retry_at)
        db.log("api", "warning", f"Credencial {key_id}: {last_error}; tentando próxima")
    if skipped_search_keys == len(candidates):
        raise YouTubeError("Todas as chaves disponíveis atingiram o limite local diário de buscas; "
                           "aguarde a virada do dia no Pacífico")
    raise YouTubeError("Todas as chaves disponíveis falharam; confira APIs no painel. " + last_error)


async def test_key(credential_id):
    # A valid request returns HTTP 200 even if the ID does not exist.
    await request("videos", {"part":"id", "id":"dQw4w9WgXcQ"}, credential_id)


async def get_channel(channel_id):
    result = await request("channels", {"part": "snippet,contentDetails", "id": channel_id})
    items = result.get("items", [])
    if len(items) != 1 or items[0].get("id") != channel_id:
        raise YouTubeError("Channel ID público não encontrado")
    item = items[0]
    uploads = item.get("contentDetails", {}).get("relatedPlaylists", {}).get("uploads")
    if not uploads:
        raise YouTubeError("Playlist de uploads indisponível neste canal")
    thumbs = item.get("snippet", {}).get("thumbnails", {})
    thumb = (thumbs.get("default") or {}).get("url", "")
    return {"channel_id": channel_id, "name": item["snippet"]["title"],
            "uploads_id": uploads, "thumbnail": thumb}


async def latest_video_ids(uploads_id, count=25):
    result = await request("playlistItems", {"part": "contentDetails", "playlistId": uploads_id,
                                             "maxResults": min(50, count)})
    return list(dict.fromkeys(item.get("contentDetails", {}).get("videoId")
                              for item in result.get("items", [])
                              if item.get("contentDetails", {}).get("videoId")))


async def video_details(ids):
    found = []
    for start in range(0, len(ids), 50):
        part = ids[start:start + 50]
        if not part:
            continue
        result = await request("videos", {"part": "snippet,contentDetails,liveStreamingDetails,status",
                                          "id": ",".join(part)})
        found.extend(result.get("items", []))
    return found


async def upcoming_video_ids(channel_id, search_limit=100):
    result = await request("search", {"part": "snippet", "channelId": channel_id,
                                      "eventType": "upcoming", "type": "video",
                                      "maxResults": 50}, search_limit=search_limit)
    return list(dict.fromkeys(item.get("id", {}).get("videoId")
                              for item in result.get("items", [])
                              if item.get("id", {}).get("videoId")))


async def check_upcoming(channel_id, search_limit=100):
    ids = await upcoming_video_ids(channel_id, search_limit)
    details = await video_details(ids)
    count, queued = store_videos(channel_id, details)
    db.write("UPDATE youtube_channels SET last_upcoming_search=? WHERE channel_id=?", (db.ts(), channel_id))
    return {"found": len(ids), "new": count, "queued": queued}


def classify(item):
    snippet = item.get("snippet", {})
    live = item.get("liveStreamingDetails") or {}
    state = snippet.get("liveBroadcastContent", "none")
    if state == "upcoming":
        kind = "scheduled"
    elif state == "live":
        kind = "live"
    elif live.get("actualEndTime"):
        kind = "ended"
    else:
        kind = "upload"  # includes Shorts; no reliable public Shorts flag
    return {"video_id": item["id"], "channel_id": snippet.get("channelId", ""),
            "title": snippet.get("title", "Vídeo sem título"),
            "url": f"https://www.youtube.com/watch?v={item['id']}",
            "thumbnail": (snippet.get("thumbnails", {}).get("high") or
                          snippet.get("thumbnails", {}).get("default") or {}).get("url", ""),
            "kind": kind, "live_state": state, "scheduled_at": live.get("scheduledStartTime"),
            "published_at": snippet.get("publishedAt"),
            "public": item.get("status", {}).get("privacyStatus", "public") == "public"}


def published_timestamp(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


def store_videos(channel_id, items, baseline=False):
    new_count = 0
    queued_count = 0
    with db.transaction() as con:
        channel = con.execute("SELECT baseline_done FROM youtube_channels WHERE channel_id=?",
                              (channel_id,)).fetchone()
        if not channel:
            return (0, 0)
        seed = baseline or not channel["baseline_done"]
        for raw in items:
            v = classify(raw)
            if v["channel_id"] != channel_id or not v["public"]:
                continue
            exists = con.execute("SELECT video_id FROM videos WHERE video_id=?", (v["video_id"],)).fetchone()
            if exists:
                con.execute("UPDATE videos SET title=?,thumbnail=?,kind=?,live_state=?,scheduled_at=?,last_seen=? "
                            "WHERE video_id=?", (v["title"], v["thumbnail"], v["kind"], v["live_state"],
                                                v["scheduled_at"], db.ts(), v["video_id"]))
                continue
            new_count += 1
            con.execute("INSERT INTO videos(video_id,channel_id,title,url,thumbnail,kind,live_state,"
                        "scheduled_at,published_at,seeded,first_seen,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (v["video_id"], channel_id, v["title"], v["url"], v["thumbnail"], v["kind"],
                         v["live_state"], v["scheduled_at"], v["published_at"], int(seed), db.ts(), db.ts()))
            if seed or v["kind"] == "ended":
                continue
            targets = con.execute("SELECT g.guild_id,g.target_channel_id,g.notify_uploads,"
                                  "g.notify_scheduled,s.notify_after FROM subscriptions s "
                                  "JOIN guilds g ON g.guild_id=s.guild_id "
                                  "WHERE s.channel_id=? AND s.active=1 AND g.active=1 AND g.present=1 "
                                  "AND g.owner_verified=1 "
                                  "AND g.target_channel_id IS NOT NULL", (channel_id,)).fetchall()
            for target in targets:
                published = published_timestamp(v["published_at"])
                if published is None or published <= target["notify_after"]:
                    continue
                enabled = (target["notify_uploads"] if v["kind"] == "upload" else
                           target["notify_scheduled"])
                if not enabled:
                    continue
                inserted = con.execute("INSERT OR IGNORE INTO deliveries(video_id,guild_id,channel_id,kind,status,"
                            "next_try,created_at,updated_at) VALUES(?,?,?,'announcement','pending',?,?,?)",
                            (v["video_id"], target["guild_id"], target["target_channel_id"],
                             db.ts(), db.ts(), db.ts()))
                queued_count += inserted.rowcount
        if seed:
            con.execute("UPDATE youtube_channels SET baseline_done=1 WHERE channel_id=?", (channel_id,))
    return (new_count, queued_count)


async def register_channel(channel_id):
    info = await get_channel(channel_id)
    ids = await latest_video_ids(info["uploads_id"])
    videos = await video_details(ids)
    with db.transaction() as con:
        already = con.execute("SELECT channel_id FROM youtube_channels WHERE channel_id=?", (channel_id,)).fetchone()
        if already:
            return info
        con.execute("INSERT INTO youtube_channels(channel_id,name,uploads_id,thumbnail,baseline_done,created_at) "
                    "VALUES(?,?,?,?,0,?)", (channel_id, info["name"], info["uploads_id"],
                                          info["thumbnail"], db.ts()))
    store_videos(channel_id, videos, baseline=True)
    db.log("youtube", "info", f"Canal {channel_id} cadastrado, {len(videos)} vídeos iniciais conhecidos")
    return info


async def subscribe_push(channel_id, callback, secret):
    if not callback or not secret:
        return
    form = {"hub.callback": callback, "hub.mode": "subscribe", "hub.topic":
            f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}",
            "hub.verify": "async", "hub.secret": secret}
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            result = await client.post(HUB, data=form)
        if result.status_code not in (200, 202, 204):
            raise YouTubeError(f"Inscrição push rejeitada: HTTP {result.status_code}")
    except httpx.HTTPError as exc:
        raise YouTubeError("Falha de rede assinando notificações push") from exc
