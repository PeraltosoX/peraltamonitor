# Histórico de versões

## V1.0.5 — 2026-09-23

- Descoberta somente pela playlist de uploads (`playlistItems.list`). `search.list` e WebSub não são utilizados. Apenas IDs novos e elegíveis entram em lotes de `videos.list`; rodada sem ID novo não faz chamada `videos.list`.
- IDs existentes na playlist no cadastro e IDs publicados antes do início da atualização viram linha de base sem consulta de detalhes e sem avisos. IDs publicados após esse marco podem ser tratados já na primeira verificação. IDs antigos vistos posteriormente com data anterior ao início também são guardados sem `videos.list`. A consulta antiga de vídeos já conhecidos foi removida. Falha ao buscar detalhes deixa os novos IDs para nova tentativa.
- Playlist verifica até 50 IDs por página, consultando páginas adicionais apenas em uma sequência cheia sem ID conhecido, até cinco páginas por rodada. Um aviso continua único quando uma live agendada muda para ao vivo.
- Novo painel com cronômetro da próxima consulta, estado/último erro/novos IDs de cada canal, imagem da marca e favicon enviado pelo usuário.
- Um servidor Discord aceita vários canais de aviso; o destino atual é migrado. Cada entrega é identificada por vídeo, servidor e destino; há botão de teste por canal e resultados visíveis.
- Botões para apagar associação, canal YouTube e logs do painel. As remoções cancelam pendências relacionadas, preservando o histórico de envios e os IDs para evitar repetição.
- Migração não destrutiva das tabelas antigas: cria `seen_video_ids` e `guild_destinations`, adapta a unicidade de `deliveries`, preserva `.env`, banco, avisos e configuração do servidor. Faça backup antes de atualizar.

## V1.0.4 — 2026-09-23

- A busca de lives agendadas ganha intervalo próprio no painel: padrão 300 segundos, mínimo 30, sem alongamento automático para ~19 minutos.
- Retira o bloqueio global de 80 buscas automáticas diárias. A contagem local passa a ser por chave; após 100 tentativas ou erro, tenta a próxima credencial disponível em ordem. A cota oficial continua por projeto Google, compartilhada por chaves do mesmo projeto.
- Mostra o consumo local das buscas em cada chave e distingue os intervalos da playlist e das lives.
- A migração cria a tabela `search_key_usage` e preserva as demais configurações e registros. A nova estimativa por chave começa zerada, mas o Google pode esgotar a cota real antes e responder 403.

## V1.0.3 — 2026-09-23

- Prévia grande do YouTube como padrão para lives e vídeos: o bot envia o link em linha própria e o Discord cria o cartão com capa e reprodução.
- Modo de prévia configurável em **Mensagem e embed**; o embed personalizado continua disponível e usa imagem grande em vez de miniatura.
- Modelos existentes preservam texto, título e demais campos e passam ao modo YouTube. É possível voltar ao modo personalizado no painel.
- A migração acrescenta apenas o modo de prévia ao banco. Mantém a regra da V1.0.2 de avisar somente publicações criadas após a associação.
- Informa nos logs quando o canal de destino não tem permissão de inserir links com prévia.

## V1.0.2 — 2026-09-23

- Nova regra de início: ao associar um canal YouTube ao servidor Discord, publicações existentes ficam registradas sem aviso; somente as criadas depois são notificadas.
- Ignora vídeos e lives antigos que aparecerem tardiamente na API, comparando a data de publicação com o início da associação.
- Remove a recuperação retroativa da V1.0.1. Na migração, associações ativas recebem um novo marco de início e entregas antigas ainda pendentes são marcadas como ignoradas, sem apagar os registros.
- Corrige o tipo apresentado no Discord para distinguir LIVE AGENDADA, LIVE AO VIVO e NOVO VÍDEO.
- Mantém as configurações, o banco de dados, a busca controlada de agendamentos e o intervalo mínimo de 30 segundos para a playlist.

## V1.0.1 — 2026-09-23

- Recupera para o Discord as lives ainda agendadas e vídeos novos vistos na última hora quando uma associação ou servidor é ativado, e ao iniciar o worker após a atualização. Não repete entregas existentes.
- Busca lives agendadas pelo canal com `search.list` sob limite local diário de 100 chamadas, respeitando o intervalo automático por quantidade de canais; botão de verificação manual no painel.
- Corrige o tópico WebSub para `/feeds/videos.xml` e mantém o monitoramento por playlist e `videos.list`.
- Aceita 30 segundos como mínimo da recuperação da playlist; o valor inicial continua 300 segundos.
- Migração preserva o banco e os segredos de V1.0.0; acrescenta a coluna da última busca e a tabela de uso de buscas. Mantenha backup antes de atualizar.

## V1.0.0 — 2026-09-23

- Painel privado com login, proteção CSRF e interface para servidores, canais, associações, modelos e logs.
- Instalação Discord via OAuth2 iniciada no painel e vinculada ao Discord User ID autorizado.
- Servidores adicionados por convite externo permanecem sem autorização; ativação exige verificação no painel.
- Worker YouTube com WebSub e recuperação por playlist/vídeos; linha de base, persistência dos IDs e entregas por servidor.
- Cinco espaços iniciais de API keys, novas entradas ilimitadas, cifragem em repouso, medição por chave e uso sequencial com espera/failover em erro ou cota.
- Notificação única para live programada detectada, live já iniciada ou vídeo/Short novo.
- Implantação Docker Compose com porta local 8081 e dados separados do Auto Server.
