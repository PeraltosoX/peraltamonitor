# Peralta YouTube Live Monitor — V1.0.5

Painel privado em **https://peraltamonitor.peraltaultrachat.shop** para avisar vídeos, Shorts e lives do YouTube em canais Discord. Docker Compose usa o projeto `peralta_live_monitor`, porta local 8081 e banco próprio em `/opt/peralta-live-monitor/data`. O Auto Server em 8080 e o Caddy existente não são alterados. Ubuntu 24.04 LTS ou versão estável posterior com Docker Compose v2.

## Funcionamento

- `playlistItems.list` consulta até 50 IDs recentes por canal YouTube no intervalo configurado (padrão 300 s, mínimo 30 s). Só consulta páginas adicionais se uma página cheia não contiver IDs já conhecidos, até cinco páginas por rodada. O mesmo canal YouTube é consultado uma vez, mesmo associado a vários servidores.
- O monitor guarda os IDs já conhecidos. No cadastro, os IDs visíveis da playlist são considerados antigos sem chamada a `videos.list` nem aviso. Na primeira rodada após a atualização, IDs publicados antes do início desta versão também são guardados sem consulta de detalhes; IDs publicados depois desse marco podem ser notificados. Um ID antigo que aparecer posteriormente com data anterior ao início é registrado sem `videos.list`.
- **Apenas IDs desconhecidos e publicados após o início** são enviados em lotes de até 50 para `videos.list`. Se não houver ID novo, **não há chamada a `videos.list`**. Se os detalhes falharem ou o YouTube ainda não disponibilizar o vídeo, o ID não é marcado como concluído e será tentado novamente. O banco preserva IDs, detalhes e histórico ao reiniciar.
- `videos.list` classifica a live agendada, a live ao vivo e os vídeos; Shorts são tratados como vídeos. A notificação ocorre uma vez quando o ID novo é encontrado. Uma mudança posterior de agendada para ao vivo não gera outro aviso, nem provoca nova consulta de IDs antigos.
- `search.list` e WebSub não são usados na V1.0.5. **Uma live agendada só será encontrada quando seu ID aparecer na playlist pública consultada**. Não há garantia de aviso no instante exato do agendamento. Esse é o compromisso escolhido para economizar a cota de buscas.
- Cada servidor autorizado pode ter vários canais Discord de avisos. Uma publicação nova gera uma entrega independente em cada destino, sem reenvio duplicado. Instale o bot uma única vez pelo botão OAuth do painel, usando o Discord User ID autorizado.

Cada chamada `playlistItems.list` ou `videos.list` consome uma unidade da cota geral do projeto Google. `videos.list` aceita vários IDs na mesma chamada. Cinco canais verificados a cada 300 segundos gastam aproximadamente 1.440 chamadas de playlist por dia, mais os lotes de IDs novos e chamadas de cadastro/teste. Com 30 segundos, cinco canais chegariam a cerca de 14.400 chamadas de playlist por dia, acima da cota geral padrão de 10.000 por projeto. A contagem local de chaves é estimada; chaves do mesmo projeto compartilham a cota oficial. Em falha/limite, o monitor tenta a próxima chave ativa na ordem configurada.

Referências: [custos e cotas da API](https://developers.google.com/youtube/v3/determine_quota_cost), [`playlistItems.list`](https://developers.google.com/youtube/v3/docs/playlistItems/list), [`videos.list`](https://developers.google.com/youtube/v3/docs/videos/list).

## Atualização segura da V1.0.4 (ou V1.0.3)

Envie o arquivo `Peralta_YouTube_Live_Monitor_V1.0.5.zip` para a **raiz da branch `main`** em `https://github.com/PeraltosoX/peraltamonitor` antes de executar os comandos. Faça um bloco por vez. Confira antes a versão ativa:

```bash
curl -fsS http://127.0.0.1:8081/health
```

**1. Baixar, verificar e extrair sem afetar os serviços atuais:**

```bash
curl -fL -o /tmp/Peralta_YouTube_Live_Monitor_V1.0.5.zip \
  https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.0.5.zip
unzip -tq /tmp/Peralta_YouTube_Live_Monitor_V1.0.5.zip
test ! -e /opt/peralta-live-monitor/releases/V1.0.5 && \
unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.0.5.zip -d /opt/peralta-live-monitor/releases
```

**2. Construir a nova imagem:**

```bash
cd /opt/peralta-live-monitor/releases/V1.0.5
docker compose build
```

**3. Parar o worker e o bot antigos e fazer backup consistente do SQLite.** O exemplo parte da V1.0.4; se o `/health` respondeu `1.0.3`, substitua apenas `V1.0.4` por `V1.0.3` no `cd` abaixo:

```bash
cd /opt/peralta-live-monitor/releases/V1.0.4
docker compose stop worker bot
docker compose exec -T web python -m scripts.backup /data/backup/monitor-$(date +%Y%m%d-%H%M%S).sqlite3
```

**4. Iniciar e conferir:**

```bash
cd /opt/peralta-live-monitor/releases/V1.0.5
docker compose up -d --no-build
docker compose ps
curl -fsS http://127.0.0.1:8081/health
curl -fsS https://peraltamonitor.peraltaultrachat.shop/health
docker compose logs --tail=60 web worker bot
```

O `/health` deve responder com versão `1.0.5`. Web, worker e bot devem aparecer ativos. Na primeira consulta após atualizar, IDs publicados antes da atualização entram na linha de base sem aviso e sem `videos.list`; IDs publicados depois podem ser verificados e notificados. O banco, o `.env`, os avisos enviados e a pasta anterior são preservados. A migração copia o destino Discord atual para a nova lista de destinos e adapta as entregas para aceitar vários canais no mesmo servidor. Faça backup **antes** da migração; se precisar voltar à versão anterior, restaure também o banco compatível de seu backup. O Caddyfile e a porta do Auto Server permanecem como estão.

Se o ZIP estiver como asset de uma release `v1.0.5` em vez de na raiz da branch, use `https://github.com/PeraltosoX/peraltamonitor/releases/download/v1.0.5/Peralta_YouTube_Live_Monitor_V1.0.5.zip` como URL. Um repositório privado exige download autenticado.

## Usar o painel

1. **Discord e servidores:** o servidor já instalado aparece com seu destino anterior. Use **Adicionar canal de avisos** para selecionar `#chat-geral`, `#divulgacoes` ou outros canais. O botão **Testar** de cada destino envia uma mensagem de teste; veja o resultado em **Atividade e logs → Testes de canais Discord**. Remover um destino cancela os avisos ainda pendentes apenas naquele canal.
2. **Canais YouTube:** o cadastro consulta o canal e sua playlist, guardando os IDs atuais como antigos. A tela mostra a última verificação, quantidade de novos IDs e erro. **Verificar IDs agora** consulta a playlist imediatamente. **Apagar canal** remove todas as associações e cancela avisos pendentes; mantém o histórico de envios e os IDs já registrados no banco para auditoria e para evitar repetição.
3. **Associações:** vincule um servidor a um canal YouTube; **Pausar** interrompe avisos futuros, **Reativar** define novo início e **Apagar associação** remove o vínculo sem afetar outros servidores. Avisos pendentes dessa associação são cancelados.
4. **Visão geral:** o cronômetro mostra a próxima verificação prevista entre os canais ativos, com estado de cada um. Ele atualiza a cada segundo no navegador; o painel sincroniza os dados do servidor a cada 10 segundos sem consumir cota YouTube. O worker executa um ciclo aproximadamente a cada 10 segundos, então o horário é uma previsão.
5. **Atividade e logs:** **Limpar logs** apaga somente os registros de log do painel. IDs conhecidos, testes, entregas e deduplicação permanecem. Logs novos podem aparecer em seguida enquanto os serviços trabalham.
6. **APIs do YouTube:** mantenha a chave principal e as reservas ativas em ordem. Erros tentam a próxima. A consulta manual de teste da chave usa `channels.list` e consome uma chamada, sem usar `videos.list`.

## Configuração inicial, caso instale do zero

O arquivo `.env` reside em `/opt/peralta-live-monitor/.env`, fora das pastas de releases. Use a `.env.example` como modelo. Preencha `DISCORD_APPLICATION_ID`, `DISCORD_BOT_TOKEN`, `DISCORD_CLIENT_SECRET`, `DISCORD_OWNER_USER_ID`, `ADMIN_PASSWORD_HASH` e `APP_SECRET`. Você pode deixar `YOUTUBE_API_KEY` vazia e cadastrar a chave no painel. `APP_SECRET` é uma chave aleatória gerada localmente com `openssl rand -hex 32`; preserve-a entre versões, pois protege sessões e as chaves cifradas. O `WEB_SUB_SECRET` de instalações anteriores pode permanecer no `.env`, mas a V1.0.5 não o usa.

No Discord Developer Portal, deixe **Public Bot desligado**, **Require OAuth2 Code Grant ligado**, instalação em servidor habilitada e adicione o redirect exato `https://peraltamonitor.peraltaultrachat.shop/auth/discord/callback`. Instale pelo botão do painel com a conta cujo User ID está no `.env`; convites por fora não autorizam um servidor no painel. O bot precisa visualizar e enviar mensagens nos canais escolhidos, embutir links para a prévia do YouTube e ter permissão de menção se `@everyone` estiver ligado.

O Caddy existente deve conter uma única entrada para o monitor, além da entrada já usada pelo Auto Server:

```caddyfile
peraltamonitor.peraltaultrachat.shop {
    reverse_proxy 127.0.0.1:8081
}
```

Não acrescente esse bloco outra vez se ele já estiver no Caddyfile. A imagem do painel, inclusive o favicon, vem no ZIP. O bot não precisa receber o logotipo pelo Discord Developer Portal para o favicon funcionar; o avatar do bot no Discord é configurado separadamente no Developer Portal.
