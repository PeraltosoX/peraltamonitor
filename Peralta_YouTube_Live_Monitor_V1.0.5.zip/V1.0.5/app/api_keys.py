"""Encrypted credentials, ordered failover and local per-key usage estimates."""
import base64
import hashlib
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from cryptography.fernet import Fernet, InvalidToken

from . import db
from .config import APP_SECRET, YOUTUBE_API_KEY

PACIFIC = ZoneInfo("America/Los_Angeles")


def quota_day():
    return datetime.now(PACIFIC).strftime("%Y-%m-%d")


def next_reset():
    now = datetime.now(PACIFIC)
    tomorrow = now.date() + timedelta(days=1)
    return int(datetime(tomorrow.year, tomorrow.month, tomorrow.day, tzinfo=PACIFIC).timestamp()) + 60


def cipher():
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(APP_SECRET.encode()).digest()))


def encrypt(key):
    return cipher().encrypt(key.encode()).decode()


def decrypt(value):
    try:
        return cipher().decrypt(value.encode()).decode()
    except InvalidToken as exc:
        raise RuntimeError("Chave API não pode ser descriptografada; confira APP_SECRET") from exc


def candidates():
    """Use preferred key first, then next configured keys; never loop a key twice."""
    records = db.rows("SELECT c.*,COALESCE(u.calls,0) AS calls FROM api_credentials c "
                      "LEFT JOIN api_key_usage u ON u.credential_id=c.id AND u.day=? "
                      "WHERE c.active=1 AND c.encrypted_key IS NOT NULL "
                      "ORDER BY c.primary_flag DESC,c.priority ASC,c.id ASC", (quota_day(),))
    available = []
    now = db.ts()
    for row in records:
        if row["retry_after"] > now or row["calls"] >= row["quota_limit"]:
            continue
        available.append((row["id"], decrypt(row["encrypted_key"])))
    if YOUTUBE_API_KEY and not YOUTUBE_API_KEY.startswith("COLE_AQUI_"):
        env_usage = db.one("SELECT calls FROM api_key_usage WHERE day=? AND credential_id=0", (quota_day(),))
        env_retry = int(db.setting("env_key_retry_after", "0"))
        if env_retry <= now and (not env_usage or env_usage["calls"] < 10000):
            if any(r["primary_flag"] for r in records):
                available.append((0, YOUTUBE_API_KEY))
            else:
                available.insert(0, (0, YOUTUBE_API_KEY))
    return available


def mark_result(credential_id, error="", retry_after=0):
    if credential_id == 0:
        db.write("INSERT INTO settings(key,value) VALUES('env_key_retry_after',?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(retry_after),))
        db.write("INSERT INTO settings(key,value) VALUES('env_key_last_error',?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (error[:120],))
    else:
        db.write("UPDATE api_credentials SET last_used=?,last_error=?,retry_after=? WHERE id=?",
                 (db.ts(), error[:120], retry_after, credential_id))


def public_list():
    records = db.rows("SELECT c.id,c.name,c.project_id,c.last4,c.active,c.primary_flag,c.priority,"
                      "c.retry_after,c.quota_limit,c.last_used,c.last_error,"
                      "c.encrypted_key IS NOT NULL AS configured,COALESCE(u.calls,0) AS calls "
                      "FROM api_credentials c LEFT JOIN api_key_usage u "
                      "ON u.credential_id=c.id AND u.day=? "
                      "ORDER BY c.priority,c.id", (quota_day(),))
    for row in records:
        row["masked"] = ("••••" + row.pop("last4")) if row["configured"] else "Não configurada"
        row["remaining"] = max(0, row["quota_limit"] - row["calls"])
    if YOUTUBE_API_KEY and not YOUTUBE_API_KEY.startswith("COLE_AQUI_"):
        usage = db.one("SELECT calls FROM api_key_usage WHERE day=? AND credential_id=0", (quota_day(),))
        count = usage["calls"] if usage else 0
        records.insert(0, {"id":0,"name":"Chave inicial (.env)","project_id":"",
                           "masked":"••••"+YOUTUBE_API_KEY[-4:],"active":1,
                           "primary_flag":int(not any(r["primary_flag"] and r["active"] for r in records)),
                           "priority":0,"retry_after":int(db.setting("env_key_retry_after", "0")),
                           "quota_limit":10000,"calls":count,"remaining":max(0,10000-count),
                           "configured":1,"last_used":None,"last_error":db.setting("env_key_last_error")})
    selected = candidates()
    current = selected[0][0] if selected else None
    for row in records:
        row["current"] = row["id"] == current
    return records
