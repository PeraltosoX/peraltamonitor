import sqlite3
import time
from contextlib import contextmanager, closing
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from .config import DATA_DIR, DB_PATH


def ts():
    return int(time.time())


def connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=30000")
    db.execute("PRAGMA foreign_keys=ON")
    return db


@contextmanager
def transaction():
    db = connect()
    try:
        db.execute("BEGIN IMMEDIATE")
        yield db
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise
    finally:
        db.close()


def init_db():
    with closing(connect()) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS guilds (
            guild_id TEXT PRIMARY KEY, name TEXT NOT NULL, present INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 0, owner_verified INTEGER NOT NULL DEFAULT 0,
            notify_uploads INTEGER NOT NULL DEFAULT 1,
            notify_scheduled INTEGER NOT NULL DEFAULT 1, mention_everyone INTEGER NOT NULL DEFAULT 0,
            target_channel_id TEXT, template_id INTEGER NOT NULL DEFAULT 1, last_seen INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS discord_channels (
            channel_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, name TEXT NOT NULL,
            can_view INTEGER NOT NULL, can_send INTEGER NOT NULL, can_embed INTEGER NOT NULL,
            can_mention INTEGER NOT NULL, last_seen INTEGER NOT NULL,
            FOREIGN KEY(guild_id) REFERENCES guilds(guild_id)
        );
        CREATE TABLE IF NOT EXISTS guild_destinations (
            guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, created_at INTEGER NOT NULL,
            PRIMARY KEY(guild_id,channel_id), FOREIGN KEY(guild_id) REFERENCES guilds(guild_id)
        );
        CREATE TABLE IF NOT EXISTS youtube_channels (
            channel_id TEXT PRIMARY KEY, name TEXT NOT NULL, uploads_id TEXT NOT NULL,
            thumbnail TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
            baseline_done INTEGER NOT NULL DEFAULT 0, last_poll INTEGER,
            last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS subscriptions (
            guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
            notify_after REAL NOT NULL DEFAULT 0,
            PRIMARY KEY(guild_id, channel_id),
            FOREIGN KEY(guild_id) REFERENCES guilds(guild_id),
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );
        CREATE TABLE IF NOT EXISTS videos (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, title TEXT NOT NULL,
            url TEXT NOT NULL, thumbnail TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL,
            live_state TEXT NOT NULL, scheduled_at TEXT, published_at TEXT,
            seeded INTEGER NOT NULL DEFAULT 0, first_seen INTEGER NOT NULL,
            last_seen INTEGER NOT NULL,
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );
        CREATE TABLE IF NOT EXISTS templates (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, content TEXT NOT NULL,
            embed_title TEXT NOT NULL DEFAULT '', embed_description TEXT NOT NULL DEFAULT '',
            embed_footer TEXT NOT NULL DEFAULT '', embed_image TEXT NOT NULL DEFAULT '',
            embed_color INTEGER NOT NULL DEFAULT 15086414,
            preview_mode TEXT NOT NULL DEFAULT 'youtube'
        );
        CREATE TABLE IF NOT EXISTS deliveries (
            id INTEGER PRIMARY KEY AUTOINCREMENT, video_id TEXT NOT NULL, guild_id TEXT NOT NULL,
            channel_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0, next_try INTEGER NOT NULL,
            message_id TEXT, error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
            UNIQUE(video_id, guild_id, kind)
        );
        CREATE TABLE IF NOT EXISTS test_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending', message_id TEXT, error TEXT,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pending_video_ids (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, received_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS seen_video_ids (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, first_seen INTEGER NOT NULL,
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );
        CREATE TABLE IF NOT EXISTS oauth_states (
            state_hash TEXT PRIMARY KEY, session_id TEXT NOT NULL, expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS api_usage (
            day TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS api_credentials (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, project_id TEXT NOT NULL DEFAULT '',
            encrypted_key TEXT, last4 TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 0,
            primary_flag INTEGER NOT NULL DEFAULT 0, quota_limit INTEGER NOT NULL DEFAULT 10000,
            priority INTEGER NOT NULL DEFAULT 100, retry_after INTEGER NOT NULL DEFAULT 0,
            last_used INTEGER, last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS api_key_usage (
            day TEXT NOT NULL, credential_id INTEGER NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL, PRIMARY KEY(day, credential_id)
        );
        CREATE TABLE IF NOT EXISTS search_usage (
            day TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS search_key_usage (
            day TEXT NOT NULL, credential_id INTEGER NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL, PRIMARY KEY(day, credential_id)
        );
        CREATE TABLE IF NOT EXISTS service_heartbeats (
            service TEXT PRIMARY KEY, at INTEGER NOT NULL, detail TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
            service TEXT NOT NULL, level TEXT NOT NULL, message TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS deliveries_due ON deliveries(status, next_try);
        CREATE INDEX IF NOT EXISTS videos_channel ON videos(channel_id, first_seen DESC);
        CREATE INDEX IF NOT EXISTS seen_channel ON seen_video_ids(channel_id);
        CREATE INDEX IF NOT EXISTS logs_at ON logs(at DESC);
        """)
        # Schema migration for a persistent V1.0.0 database. Never drop tables.
        columns = {row["name"] for row in db.execute("PRAGMA table_info(youtube_channels)")}
        if "last_upcoming_search" not in columns:
            db.execute("ALTER TABLE youtube_channels ADD COLUMN last_upcoming_search INTEGER")
        if "ids_baseline_done" not in columns:
            db.execute("ALTER TABLE youtube_channels ADD COLUMN ids_baseline_done INTEGER NOT NULL DEFAULT 0")
        if "removed" not in columns:
            db.execute("ALTER TABLE youtube_channels ADD COLUMN removed INTEGER NOT NULL DEFAULT 0")
        if "last_new_count" not in columns:
            db.execute("ALTER TABLE youtube_channels ADD COLUMN last_new_count INTEGER NOT NULL DEFAULT 0")
        if "monitor_after" not in columns:
            db.execute("ALTER TABLE youtube_channels ADD COLUMN monitor_after REAL NOT NULL DEFAULT 0")
            db.execute("UPDATE youtube_channels SET monitor_after=?", (time.time(),))
        subscription_columns = {row["name"] for row in db.execute("PRAGMA table_info(subscriptions)")}
        if "notify_after" not in subscription_columns:
            # Existing associations start a fresh baseline when upgrading.
            cutoff = time.time()
            db.execute("ALTER TABLE subscriptions ADD COLUMN notify_after REAL NOT NULL DEFAULT 0")
            db.execute("UPDATE subscriptions SET notify_after=?", (cutoff,))
            # Do not send announcements queued by the older catch-up rule.
            db.execute("UPDATE deliveries SET status='skipped',error=?,updated_at=? "
                       "WHERE status='pending' AND created_at<=?",
                       ("Ignorado na atualização: conteúdo anterior ao início do monitoramento", ts(), cutoff))
        template_columns = {row["name"] for row in db.execute("PRAGMA table_info(templates)")}
        if "preview_mode" not in template_columns:
            db.execute("ALTER TABLE templates ADD COLUMN preview_mode TEXT NOT NULL DEFAULT 'custom'")
            db.execute("UPDATE templates SET preview_mode='youtube'")
        # Existing videos and the currently selected Discord destination remain known.
        db.execute("INSERT OR IGNORE INTO seen_video_ids(video_id,channel_id,first_seen) "
                   "SELECT video_id,channel_id,first_seen FROM videos")
        db.execute("INSERT OR IGNORE INTO guild_destinations(guild_id,channel_id,created_at) "
                   "SELECT guild_id,target_channel_id,? FROM guilds WHERE target_channel_id IS NOT NULL", (ts(),))
        delivery_sql = db.execute("SELECT sql FROM sqlite_master WHERE name='deliveries'").fetchone()["sql"]
        if "UNIQUE(video_id, guild_id, kind)" in delivery_sql:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("CREATE TABLE deliveries_new ("
                           "id INTEGER PRIMARY KEY AUTOINCREMENT, video_id TEXT NOT NULL, guild_id TEXT NOT NULL, "
                           "channel_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', "
                           "attempts INTEGER NOT NULL DEFAULT 0, next_try INTEGER NOT NULL, "
                           "message_id TEXT, error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, "
                           "UNIQUE(video_id,guild_id,channel_id,kind))")
                db.execute("INSERT INTO deliveries_new SELECT * FROM deliveries")
                db.execute("DROP TABLE deliveries")
                db.execute("ALTER TABLE deliveries_new RENAME TO deliveries")
                db.execute("CREATE INDEX deliveries_due ON deliveries(status,next_try)")
                db.execute("COMMIT")
            except Exception:
                db.execute("ROLLBACK")
                raise
        db.execute("INSERT OR IGNORE INTO templates(id,name,content,embed_title,embed_description) VALUES(1,?,?,?,?)",
                   ("Padrão", "{everyone}🔴 {tipo}: {canal}\n{titulo}\n{link}\n{data}", "{titulo}", "{canal} • {data}"))
        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('playlist_interval','300')")
        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('upcoming_interval','300')")
        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('timezone','America/Sao_Paulo')")
        if not db.execute("SELECT 1 FROM api_credentials LIMIT 1").fetchone():
            db.executemany("INSERT INTO api_credentials(name,priority,created_at) VALUES(?,?,?)",
                           [(f"API {n:02d}", n, ts()) for n in range(1, 6)])


def rows(query, args=()):
    with closing(connect()) as db:
        return [dict(row) for row in db.execute(query, args).fetchall()]


def one(query, args=()):
    with closing(connect()) as db:
        row = db.execute(query, args).fetchone()
        return dict(row) if row else None


def write(query, args=()):
    with closing(connect()) as db:
        return db.execute(query, args).rowcount


def log(service, level, message):
    # Callers pass human-readable context only, never keys or response headers.
    write("INSERT INTO logs(at,service,level,message) VALUES(?,?,?,?)",
          (ts(), service, level, str(message)[:900]))


def heartbeat(service, detail=""):
    write("INSERT INTO service_heartbeats(service,at,detail) VALUES(?,?,?) "
          "ON CONFLICT(service) DO UPDATE SET at=excluded.at,detail=excluded.detail",
          (service, ts(), str(detail)[:120]))


def setting(name, default=""):
    row = one("SELECT value FROM settings WHERE key=?", (name,))
    return row["value"] if row else default


def record_api_call(credential_id=0):
    day = datetime.now(ZoneInfo("America/Los_Angeles")).strftime("%Y-%m-%d")
    write("INSERT INTO api_usage(day,calls,updated_at) VALUES(?,1,?) "
          "ON CONFLICT(day) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at", (day, ts()))
    write("INSERT INTO api_key_usage(day,credential_id,calls,updated_at) VALUES(?,?,1,?) "
          "ON CONFLICT(day,credential_id) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at",
          (day, credential_id, ts()))


def search_calls():
    from .api_keys import quota_day
    row = one("SELECT calls FROM search_usage WHERE day=?", (quota_day(),))
    return row["calls"] if row else 0


def search_key_calls(credential_id):
    from .api_keys import quota_day
    row = one("SELECT calls FROM search_key_usage WHERE day=? AND credential_id=?",
              (quota_day(), credential_id))
    return row["calls"] if row else 0


def reserve_search_call(credential_id, limit=100):
    """Reserve one attempt for a key; Google applies its actual quota by project."""
    from .api_keys import quota_day
    day = quota_day()
    with transaction() as con:
        row = con.execute("SELECT calls FROM search_key_usage WHERE day=? AND credential_id=?",
                          (day, credential_id)).fetchone()
        if row and row["calls"] >= limit:
            return False
        con.execute("INSERT INTO search_key_usage(day,credential_id,calls,updated_at) VALUES(?,?,1,?) "
                    "ON CONFLICT(day,credential_id) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at",
                    (day, credential_id, ts()))
        con.execute("INSERT INTO search_usage(day,calls,updated_at) VALUES(?,1,?) "
                    "ON CONFLICT(day) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at",
                    (day, ts()))
    return True


def prune():
    cutoff = ts() - 30 * 86400
    write("DELETE FROM logs WHERE at < ?", (cutoff,))
    write("DELETE FROM test_requests WHERE created_at < ?", (cutoff,))
    write("DELETE FROM oauth_states WHERE expires_at < ?", (ts(),))
    write("DELETE FROM api_usage WHERE day < ?", (datetime.fromtimestamp(cutoff, timezone.utc).strftime("%Y-%m-%d"),))
    write("DELETE FROM api_key_usage WHERE day < ?", (datetime.fromtimestamp(cutoff, timezone.utc).strftime("%Y-%m-%d"),))
    write("DELETE FROM search_usage WHERE day < ?", (datetime.fromtimestamp(cutoff, timezone.utc).strftime("%Y-%m-%d"),))
    write("DELETE FROM search_key_usage WHERE day < ?", (datetime.fromtimestamp(cutoff, timezone.utc).strftime("%Y-%m-%d"),))
