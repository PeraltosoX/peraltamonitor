import asyncio
import time

from . import db, youtube, api_keys
from .config import require


async def poll_channel(channel):
    cid = channel["channel_id"]
    try:
        result = await youtube.check_playlist(cid, channel["uploads_id"])
        if result["baseline"]:
            db.log("worker", "info", f"{cid}: linha de base concluída; {result['new']} novo(s), {result['queued']} entrega(s)")
        elif result["new"]:
            db.log("worker", "info", f"{cid}: {result['new']} vídeo(s) novo(s), {result['queued']} entrega(s)")
    except Exception as exc:
        # YouTubeError messages contain no request URL, token or API key.
        reason = str(exc) if isinstance(exc, youtube.YouTubeError) else type(exc).__name__
        db.write("UPDATE youtube_channels SET last_poll=?,last_error=? WHERE channel_id=?",
                 (db.ts(), reason[:250], cid))
        db.log("worker", "error", f"{cid}: {reason}")


async def main():
    require("APP_DOMAIN", "APP_SECRET")
    db.init_db()
    last_prune = 0
    last_api_warning = 0
    while True:
        db.heartbeat("worker", "Monitorando")
        try:
            interval = max(30, min(86400, int(db.setting("playlist_interval", "300"))))
        except ValueError:
            interval = 300
        for channel in db.rows("SELECT * FROM youtube_channels WHERE active=1 AND removed=0 "
                               "ORDER BY last_poll IS NOT NULL,last_poll"):
            if channel["last_poll"] and db.ts() - channel["last_poll"] < interval:
                continue
            try:
                available = api_keys.candidates()
            except RuntimeError as exc:
                if time.time() - last_api_warning > 300:
                    db.log("worker", "warning", str(exc))
                    last_api_warning = time.time()
                break
            if not available:
                if time.time() - last_api_warning > 300:
                    db.log("worker", "warning", "Nenhuma chave API disponível; aguardando cota ou correção")
                    last_api_warning = time.time()
                break
            await poll_channel(channel)
            await asyncio.sleep(0.15)
        if time.time() - last_prune > 86400:
            db.prune()
            last_prune = time.time()
        await asyncio.sleep(10)


if __name__ == "__main__":
    asyncio.run(main())
