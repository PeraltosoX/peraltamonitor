import httpx
import time
from datetime import datetime

from . import db, api_keys

BASE = "https://www.googleapis.com/youtube/v3"


class YouTubeError(Exception):
    pass


async def request(method, params, credential_id=None):
    try:
        if credential_id is None:
            candidates = api_keys.candidates()
        elif credential_id == 0:
            from .config import YOUTUBE_API_KEY
            candidates = [(0, YOUTUBE_API_KEY)] if YOUTUBE_API_KEY else []
        else:
            row = db.one("SELECT encrypted_key FROM api_credentials WHERE id=?", (credential_id,))
            if not row or not row["encrypted_key"]:
                raise YouTubeError("Chave não configurada")
            candidates = [(credential_id, api_keys.decrypt(row["encrypted_key"]))]
    except RuntimeError as exc:
        raise YouTubeError(str(exc)) from exc
    if not candidates:
        raise YouTubeError("Nenhuma chave API ativa disponível; confira cota e espera no painel")
    last_error = ""
    for key_id, key in candidates:
        # Key stays in the backend. Never put the URL/headers in a log or error.
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                response = await client.get(f"{BASE}/{method}", params={**params, "key": key})
        except httpx.HTTPError:
            last_error = "Falha de rede"
            api_keys.mark_result(key_id, last_error, db.ts() + 120)
            db.log("api", "warning", f"Credencial {key_id} indisponível na rede; tentando próxima")
            continue
        db.record_api_call(key_id)  # Failed requests may also consume quota.
        if response.status_code == 200:
            api_keys.mark_result(key_id)
            return response.json()
        last_error = f"HTTP {response.status_code}"
        retry_at = (api_keys.next_reset() if response.status_code in (403, 429)
                    else db.ts() + (3600 if response.status_code in (400, 401) else 300))
        api_keys.mark_result(key_id, last_error, retry_at)
        db.log("api", "warning", f"Credencial {key_id}: {last_error}; tentando próxima")
    raise YouTubeError("Todas as chaves disponíveis falharam; confira APIs no painel. " + last_error)


async def test_key(credential_id):
    # A valid request returns HTTP 200 even if the ID does not exist.
    await request("channels", {"part":"id", "id":"UC0000000000000000000000"}, credential_id)


async def get_channel(channel_id):
    result = await request("channels", {"part": "snippet,contentDetails", "id": channel_id})
    items = result.get("items", [])
    if len(items) != 1 or items[0].get("id") != channel_id:
        raise YouTubeError("Channel ID público não encontrado")
    item = items[0]
    uploads = item.get("contentDetails", {}).get("relatedPlaylists", {}).get("uploads")
    if not uploads:
        raise YouTubeError("Playlist de uploads indisponível neste canal")
    thumbs = item.get("snippet", {}).get("thumbnails", {})
    thumb = (thumbs.get("default") or {}).get("url", "")
    return {"channel_id": channel_id, "name": item["snippet"]["title"],
            "uploads_id": uploads, "thumbnail": thumb}


async def latest_video_ids(uploads_id, known_ids=None):
    """Read 50 IDs per page; scan more only when a full page has no known ID."""
    entries, token = [], None
    for _ in range(5):
        params = {"part": "contentDetails", "playlistId": uploads_id, "maxResults": 50}
        if token:
            params["pageToken"] = token
        result = await request("playlistItems", params)
        page = [{"video_id":item.get("contentDetails", {}).get("videoId"),
                 "published_at":item.get("contentDetails", {}).get("videoPublishedAt")}
                for item in result.get("items", [])]
        page = [item for item in page if item["video_id"]]
        entries.extend(page)
        token = result.get("nextPageToken")
        if known_ids is None or len(page) < 50 or any(item["video_id"] in known_ids for item in page) or not token:
            break
    return list({item["video_id"]:item for item in entries}.values())


async def video_details(ids):
    found = []
    for start in range(0, len(ids), 50):
        part = ids[start:start + 50]
        if not part:
            continue
        result = await request("videos", {"part": "snippet,contentDetails,liveStreamingDetails,status",
                                          "id": ",".join(part)})
        found.extend(result.get("items", []))
    return found


async def check_playlist(channel_id, uploads_id):
    channel = db.one("SELECT ids_baseline_done,monitor_after,removed FROM youtube_channels WHERE channel_id=?", (channel_id,))
    if not channel or channel["removed"]:
        raise YouTubeError("Canal removido")
    known = {row["video_id"] for row in db.rows("SELECT video_id FROM seen_video_ids WHERE channel_id=?", (channel_id,))}
    entries = await latest_video_ids(uploads_id, known)
    ids = [entry["video_id"] for entry in entries]
    baseline = not channel["ids_baseline_done"]
    if not channel["ids_baseline_done"]:
        # On upgrade, IDs published before the cutoff become old without videos.list.
        # IDs published after the cutoff remain eligible even if the first poll was delayed.
        old_ids = [entry["video_id"] for entry in entries if entry["video_id"] in known or
                   (published_timestamp(entry["published_at"]) or 0) <= channel["monitor_after"]]
        with db.transaction() as con:
            con.executemany("INSERT OR IGNORE INTO seen_video_ids(video_id,channel_id,first_seen) VALUES(?,?,?)",
                            [(vid, channel_id, db.ts()) for vid in old_ids])
            con.execute("UPDATE youtube_channels SET ids_baseline_done=1,baseline_done=1,last_poll=?,"
                        "last_new_count=0,last_error='' WHERE channel_id=?", (db.ts(), channel_id))
        known.update(old_ids)
    old_visible = [entry["video_id"] for entry in entries
                   if entry["video_id"] not in known and
                   (published_timestamp(entry["published_at"]) or float("inf")) <= channel["monitor_after"]]
    if old_visible:
        with db.transaction() as con:
            con.executemany("INSERT OR IGNORE INTO seen_video_ids(video_id,channel_id,first_seen) VALUES(?,?,?)",
                            [(vid,channel_id,db.ts()) for vid in old_visible])
    new_ids = [vid for vid in ids if vid not in known and vid not in old_visible]
    details = await video_details(new_ids)
    count, queued = store_videos(channel_id, details)
    db.write("UPDATE youtube_channels SET last_poll=?,last_new_count=?,last_error='' WHERE channel_id=?",
             (db.ts(), count, channel_id))
    return {"found": len(ids), "new": count, "queued": queued, "baseline": baseline}


def classify(item):
    snippet = item.get("snippet", {})
    live = item.get("liveStreamingDetails") or {}
    state = snippet.get("liveBroadcastContent", "none")
    if state == "upcoming":
        kind = "scheduled"
    elif state == "live":
        kind = "live"
    elif live.get("actualEndTime"):
        kind = "ended"
    else:
        kind = "upload"  # includes Shorts; no reliable public Shorts flag
    return {"video_id": item["id"], "channel_id": snippet.get("channelId", ""),
            "title": snippet.get("title", "Vídeo sem título"),
            "url": f"https://www.youtube.com/watch?v={item['id']}",
            "thumbnail": (snippet.get("thumbnails", {}).get("high") or
                          snippet.get("thumbnails", {}).get("default") or {}).get("url", ""),
            "kind": kind, "live_state": state, "scheduled_at": live.get("scheduledStartTime"),
            "published_at": snippet.get("publishedAt"),
            "public": item.get("status", {}).get("privacyStatus", "public") == "public"}


def published_timestamp(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


def store_videos(channel_id, items, baseline=False):
    new_count = 0
    queued_count = 0
    with db.transaction() as con:
        channel = con.execute("SELECT baseline_done FROM youtube_channels WHERE channel_id=?",
                              (channel_id,)).fetchone()
        if not channel:
            return (0, 0)
        seed = baseline or not channel["baseline_done"]
        for raw in items:
            v = classify(raw)
            if v["channel_id"] != channel_id or not v["public"]:
                continue
            con.execute("INSERT OR IGNORE INTO seen_video_ids(video_id,channel_id,first_seen) VALUES(?,?,?)",
                        (v["video_id"], channel_id, db.ts()))
            exists = con.execute("SELECT video_id FROM videos WHERE video_id=?", (v["video_id"],)).fetchone()
            if exists:
                con.execute("UPDATE videos SET title=?,thumbnail=?,kind=?,live_state=?,scheduled_at=?,last_seen=? "
                            "WHERE video_id=?", (v["title"], v["thumbnail"], v["kind"], v["live_state"],
                                                v["scheduled_at"], db.ts(), v["video_id"]))
                continue
            new_count += 1
            con.execute("INSERT INTO videos(video_id,channel_id,title,url,thumbnail,kind,live_state,"
                        "scheduled_at,published_at,seeded,first_seen,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (v["video_id"], channel_id, v["title"], v["url"], v["thumbnail"], v["kind"],
                         v["live_state"], v["scheduled_at"], v["published_at"], int(seed), db.ts(), db.ts()))
            if seed or v["kind"] == "ended":
                continue
            targets = con.execute("SELECT g.guild_id,d.channel_id AS target_channel_id,g.notify_uploads,"
                                  "g.notify_scheduled,s.notify_after FROM subscriptions s "
                                  "JOIN guilds g ON g.guild_id=s.guild_id "
                                  "JOIN guild_destinations d ON d.guild_id=g.guild_id "
                                  "WHERE s.channel_id=? AND s.active=1 AND g.active=1 AND g.present=1 "
                                  "AND g.owner_verified=1", (channel_id,)).fetchall()
            for target in targets:
                published = published_timestamp(v["published_at"])
                if published is None or published <= target["notify_after"]:
                    continue
                enabled = (target["notify_uploads"] if v["kind"] == "upload" else
                           target["notify_scheduled"])
                if not enabled:
                    continue
                inserted = con.execute("INSERT OR IGNORE INTO deliveries(video_id,guild_id,channel_id,kind,status,"
                            "next_try,created_at,updated_at) VALUES(?,?,?,'announcement','pending',?,?,?)",
                            (v["video_id"], target["guild_id"], target["target_channel_id"],
                             db.ts(), db.ts(), db.ts()))
                queued_count += inserted.rowcount
        if seed:
            con.execute("UPDATE youtube_channels SET baseline_done=1 WHERE channel_id=?", (channel_id,))
    return (new_count, queued_count)


async def register_channel(channel_id):
    cutoff = time.time()
    info = await get_channel(channel_id)
    entries = await latest_video_ids(info["uploads_id"])
    ids = [entry["video_id"] for entry in entries]
    with db.transaction() as con:
        already = con.execute("SELECT channel_id,removed FROM youtube_channels WHERE channel_id=?", (channel_id,)).fetchone()
        if already and not already["removed"]:
            return info
        if already:
            con.execute("UPDATE youtube_channels SET name=?,uploads_id=?,thumbnail=?,active=1,removed=0,"
                        "ids_baseline_done=1,baseline_done=1,last_poll=?,last_new_count=0,last_error='',monitor_after=? "
                        "WHERE channel_id=?", (info["name"], info["uploads_id"],info["thumbnail"],db.ts(),cutoff,channel_id))
        else:
            con.execute("INSERT INTO youtube_channels(channel_id,name,uploads_id,thumbnail,baseline_done,"
                        "ids_baseline_done,last_poll,monitor_after,created_at) VALUES(?,?,?,?,1,1,?,?,?)",
                        (channel_id, info["name"], info["uploads_id"],info["thumbnail"],db.ts(),cutoff,db.ts()))
        con.executemany("INSERT OR IGNORE INTO seen_video_ids(video_id,channel_id,first_seen) VALUES(?,?,?)",
                        [(vid, channel_id, db.ts()) for vid in ids])
    db.log("youtube", "info", f"Canal {channel_id} cadastrado, {len(ids)} IDs iniciais conhecidos")
    return info
