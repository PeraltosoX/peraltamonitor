# Atualizar da V1.0.5 para a V1.0.6

Use o **mesmo `.env`, a mesma `APP_SECRET` e a mesma pasta `data`**. A nova versão fica em uma pasta separada. Os comandos abaixo consideram a instalação existente em `/opt/peralta-live-monitor`, que já era utilizada pela V1.0.5.

Execute os blocos em ordem. Se um bloco apresentar erro, resolva-o antes de continuar. Não faça uma instalação do zero sobre a instalação atual.

## 1. Conferir a versão atual

```bash
curl -fsS http://127.0.0.1:8081/health
```

O retorno deve mostrar a versão `1.0.5`. Se o caminho de instalação ou a versão forem diferentes, adapte os caminhos antes de seguir.

## 2. Disponibilizar e extrair o ZIP novo

Se for baixar pelo GitHub, coloque primeiro `Peralta_YouTube_Live_Monitor_V1.0.6.zip` na raiz da branch `main` de `PeraltosoX/peraltamonitor`. O ZIP não é publicado automaticamente por esta entrega.

```bash
(
set -e
curl -fL -o /tmp/Peralta_YouTube_Live_Monitor_V1.0.6.zip \
  https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.0.6.zip
unzip -tq /tmp/Peralta_YouTube_Live_Monitor_V1.0.6.zip
test -f /opt/peralta-live-monitor/.env
test -s /opt/peralta-live-monitor/data/monitor.sqlite3
test -f /opt/peralta-live-monitor/releases/V1.0.5/compose.yaml
test ! -e /opt/peralta-live-monitor/releases/V1.0.6
unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.0.6.zip -d /opt/peralta-live-monitor/releases
)
```

Se enviar o ZIP diretamente à VPS, use esse arquivo no lugar do download. Um repositório privado exige download autenticado. Se a pasta V1.0.6 já existir, confira seu conteúdo antes de reaproveitá-la; o bloco acima não sobrescreve uma versão existente.

## 3. Construir a imagem com a versão atual ainda rodando

```bash
cd /opt/peralta-live-monitor/releases/V1.0.6
docker compose build web
```

`web`, `worker` e `bot` usam a mesma imagem `peralta-live-monitor:1.0.6`. Só continue quando a construção terminar com sucesso.

## 4. Parar os serviços e fazer backup

A partir deste bloco haverá uma pausa no monitoramento até o passo 6. O painel também será parado para impedir gravações durante o backup. O banco e as configurações são copiados sem apagar os originais.

```bash
(
set -e
cd /opt/peralta-live-monitor/releases/V1.0.5
test -s ../../data/monitor.sqlite3
test -s ../../.env
PLM_BACKUP_NAME="antes-V1.0.6-$(date +%Y%m%d-%H%M%S)"
mkdir -p "../../data/backup/$PLM_BACKUP_NAME"
chmod 700 "../../data/backup/$PLM_BACKUP_NAME"
cp -p ../../.env "../../data/backup/$PLM_BACKUP_NAME/config.env"
chmod 600 "../../data/backup/$PLM_BACKUP_NAME/config.env"
docker compose stop worker bot web
cd ../V1.0.6
docker compose run --rm --no-deps -T web python -m scripts.backup \
  "/data/backup/$PLM_BACKUP_NAME/monitor.sqlite3"
printf 'Backup concluído em: /opt/peralta-live-monitor/data/backup/%s\n' "$PLM_BACKUP_NAME"
)
```

O comando usa a cópia SQLite consistente, confere a integridade e recusa substituir um backup já existente. Anote o caminho exibido. Não prossiga se o backup falhar. Antes de iniciar qualquer serviço novo, é possível retomar a V1.0.5 com `docker compose up -d --no-build` dentro da pasta dela.

## 5. Iniciar e conferir o painel novo

```bash
cd /opt/peralta-live-monitor/releases/V1.0.6
docker compose up -d --no-deps web
curl --retry 12 --retry-connrefused --retry-delay 2 --max-time 5 \
  -fsS http://127.0.0.1:8081/health
```

Aguarde o retorno com `"version":"1.0.6"` e `"status":"ok"`. A abertura do banco acrescenta a configuração por canal, preservando dados e marcos de monitoramento da V1.0.5.

## 6. Retomar o monitoramento

```bash
cd /opt/peralta-live-monitor/releases/V1.0.6
docker compose up -d worker bot
docker compose ps
docker compose logs --tail=60 web worker bot
```

Confira os três serviços ativos. Abra o painel pelo endereço de sempre, faça login e confira seus canais, servidores, modelos e APIs. Em **Visão geral**, verifique os sinais do worker e do bot. O funcionamento passa a ser o da nova versão; os canais anteriores continuam com suas escolhas atuais até você editá-los.

A migração não zera os IDs conhecidos nem redefine a data de início do canal. Publicações novas durante a breve parada continuam elegíveis quando forem encontradas na playlist, respeitando as regras já existentes.

## Recuperação em caso de problema

Preserve a pasta V1.0.5 e o backup. Consulte primeiro os logs. Não recrie `.env`, `APP_SECRET` ou o banco para tentar resolver uma falha.

Se decidir voltar para a V1.0.5, pare **todos os serviços da V1.0.6** antes de mexer no banco. A reversão completa deve usar o banco de antes da atualização com a versão antiga: ela não entende as escolhas individuais de destinos da V1.0.6. Restaurar esse backup também volta os registros ao momento em que ele foi feito, então alterações e avisos posteriores precisam ser considerados para evitar perdas ou duplicações. Não restaure o banco com serviços gravando nele.

Esta entrega não executa nenhum comando na VPS. Domínio, Caddy, porta 8081, `.env` e a pasta de dados mantêm os mesmos locais.
