# Peralta YouTube Live Monitor — V1.0.6

Atualização da V1.0.5 com um painel redesenhado e edição de avisos por canal do YouTube. O mesmo canal pode usar **texto, modelo e estilo diferentes em cada servidor e em cada canal Discord**.

O ícone original foi preservado. O projeto continua com `web`, `worker` e `bot`, porta local **8081**, projeto Compose `peralta_live_monitor` e banco em `/opt/peralta-live-monitor/data`. O domínio e o Caddy existentes continuam sendo usados.

**Para atualizar uma instalação existente, siga [ATUALIZAR_SEM_PERDER_DADOS.md](ATUALIZAR_SEM_PERDER_DADOS.md).** Não substitua o `.env` pela `.env.example`. A `APP_SECRET` existente precisa ser mantida para abrir as chaves cifradas.

## O novo fluxo

1. Abra **Canais & avisos** e clique em **Adicionar canal**. Informe o Channel ID `UC…`, como na versão anterior. O cadastro leva diretamente à edição.
2. Em **Destinos**, escolha o servidor e o canal Discord. Adicione quantos destinos precisar, inclusive vários no mesmo servidor.
3. Em cada destino, clique em **Editar mensagem & estilo**. Em **Mensagem que você está editando**, confirme o servidor/canal desejado.
4. Escolha **Usar modelo existente** ou **Personalizar uma cópia para este destino**. Uma cópia recebe, por padrão, o nome do canal YouTube, do servidor e do destino; o nome também pode ser editado.
5. Defina a mensagem e o estilo: prévia nativa do YouTube ou embed personalizado com título, descrição, rodapé, imagem e cor. Cada destino tem suas próprias opções de vídeos/Shorts, lives e `@everyone`.
6. Troque de destino na prévia para conferir cada mensagem. **Enviar teste neste destino** coloca uma mensagem real na fila do bot, com todas as menções bloqueadas. Você confirma o destino antes do teste. A prévia não chama a API YouTube e o teste não salva o rascunho.
7. Abra **Revisar**, confira todos os destinos, modelos e estados e clique em **Salvar configuração**. O conjunto é salvo em uma única transação.

Exemplo: um canal YouTube pode enviar texto curto com prévia do YouTube ao servidor A, um embed personalizado ao servidor B e outro modelo ao servidor C. Destinos de um mesmo servidor também podem usar estilos diferentes.

O **Padrão deste canal** é opcional: permite reutilizar uma mensagem nos destinos que escolherem esse padrão. A configuração específica do destino tem prioridade. Se nenhum modelo do canal/destino for escolhido, continua valendo o padrão daquele servidor.

## Cópias e modelos compartilhados

- **Personalizar uma cópia** preserva o modelo de origem. Se uma cópia for compartilhada posteriormente, uma nova personalização do canal cria outra cópia para não modificar os outros usos.
- A aba **Modelos** reúne todos os modelos, incluindo as cópias por canal/destino. Sua edição direta é uma edição compartilhada e pede confirmação antes de salvar.
- O editor de modelos mantém variáveis, modo YouTube/embed e reordenação de linhas por arraste; as setas também permitem reordenar por teclado ou toque.
- Ao trocar entre servidores no editor, os rascunhos são mantidos até salvar ou descartá-los. Fechar uma edição com alterações pede confirmação.

## Pausas, remoções e histórico

Cada destino pode ser pausado sem pausar os outros. Salve para aplicar a pausa. Avisos ainda pendentes desse destino são marcados como ignorados, com o motivo registrado; entregas enviadas e IDs conhecidos permanecem no banco. Um envio que já esteja em andamento pode terminar antes da pausa.

Retomar um destino começa pelas novas publicações após a retomada. Não há reenvio automático do período pausado. Remover um destino na edição afeta somente aquele canal YouTube. Remover um destino padrão na aba Discord é uma ação do servidor e cancela pendências daquele destino.

A aba **Entregas & logs** mostra o canal YouTube, servidor, canal Discord, resultado e motivo da falha. Há filtros por texto e estado. O reenvio manual continua disponível para falhas/resultados incertos, com confirmação para evitar duplicar um aviso que já tenha chegado.

**Limpar logs** apaga somente logs. Vídeos conhecidos, entregas e deduplicação são preservados.

## Compatibilidade com a V1.0.5

A atualização acrescenta campos e uma tabela de destinos por canal. Não apaga tabelas ou registros existentes ao partir da V1.0.5; não redefine o começo do monitoramento, as cotas, as chaves, os modelos ou os avisos anteriores.

Canais que ainda não foram salvos no novo editor continuam usando suas associações e os destinos padrão já configurados na V1.0.5. O editor mostra essas escolhas atuais. Depois de salvar, aquele canal passa a ter sua própria lista de destinos. Adicionar um destino nessa edição não o adiciona aos outros canais do servidor.

**Discord** mantém autorização, instalação OAuth, destinos e padrões por servidor. **Associações** mantém os vínculos antigos e suas ações de pausar/reativar/remover. Esses controles continuam disponíveis. Se um servidor está pausado, seus destinos individuais também aguardam a ativação na aba Discord.

O editor detecta alterações concorrentes na configuração do canal e pede para recarregar a edição antes de sobrescrever dados mais recentes.

## Monitoramento e consumo

- O worker continua independente da página aberta no navegador.
- `playlistItems.list` descobre IDs, até 50 por página, no intervalo global escolhido (padrão 300 segundos; mínimo 30). Páginas adicionais são consultadas apenas quando necessárias, até cinco por rodada.
- Apenas IDs desconhecidos e elegíveis vão para `videos.list`, em lotes de até 50. Sem ID novo, não há consulta a `videos.list`. Falhas deixam o ID disponível para nova tentativa.
- IDs antigos e histórico permanecem conhecidos. Uma publicação produz um aviso por destino. A mudança posterior de agendada para ao vivo não gera outro aviso nem consulta recorrente de IDs antigos.
- Shorts continuam incluídos em vídeos; a API pública usada não fornece um indicador confiável de Shorts separado.
- `search.list` e WebSub continuam desativados. Uma live agendada é encontrada quando seu ID aparece na playlist pública consultada; o instante da descoberta depende do YouTube.
- A troca para a próxima chave ativa em caso de falha/limite continua funcionando, com a mesma configuração.

Em **Ajustes**, a estimativa mostra `canais ativos × 86.400 ÷ intervalo`, arredondada para cima, considerando uma página por verificação. Cada chamada de playlist e de detalhes custa uma unidade. Páginas adicionais, lotes de IDs novos, cadastros, testes de chaves e novas tentativas somam consumo. O ciclo do worker também pode alongar o intervalo real quando há muitos canais ou lentidão.

A estimativa não soma cotas de chaves: chaves do mesmo projeto Google compartilham a cota. A contagem local não substitui a medição oficial do Google Cloud. Referências: [playlistItems.list](https://developers.google.com/youtube/v3/docs/playlistItems/list), [videos.list](https://developers.google.com/youtube/v3/docs/videos/list) e [custos da API](https://developers.google.com/youtube/v3/determine_quota_cost).

## Estrutura e configuração

```text
/opt/peralta-live-monitor/
  .env
  data/
    monitor.sqlite3
    backup/
  releases/
    V1.0.5/
    V1.0.6/
```

Para uma instalação nova, use a `.env.example` como referência. Em uma atualização, mantenha o `.env` existente com seu domínio, credenciais Discord, login do painel e `APP_SECRET`. A API YouTube pode continuar cadastrada no painel ou na variável `YOUTUBE_API_KEY`, conforme a instalação atual.

A instalação do bot continua exigindo seu Discord User ID autorizado. No Developer Portal: Public Bot desligado, Require OAuth2 Code Grant ligado, instalação em servidor habilitada e redirect correspondente ao domínio configurado, por exemplo `https://peraltamonitor.peraltaultrachat.shop/auth/discord/callback`. O bot precisa visualizar e enviar no destino; Embed Links habilita as prévias e Mention Everyone permite as menções quando escolhidas.

O Caddy existente continua apontando o domínio para `127.0.0.1:8081`. Não é preciso alterar serviços que usem outras portas, como o Auto Server.

## Validação

Execute os testes com Python 3.12 e as dependências de `requirements.txt`:

```bash
python -m unittest discover -s tests -v
```

A entrega foi verificada com testes automatizados de migração da base V1.0.5, preservação das chaves cifradas e do histórico, deduplicação, permissões, modelos por servidor, isolamento entre canais, pausas e testes sem menções. O painel também foi exercitado no navegador em computador e celular, incluindo salvar e reabrir mensagens diferentes por destino.

As verificações usam dados de teste e envios simulados. A instalação na VPS e o envio com suas contas reais devem ser conferidos após a atualização. Veja também [VALIDACAO.md](VALIDACAO.md) e [CHANGELOG.md](CHANGELOG.md).
