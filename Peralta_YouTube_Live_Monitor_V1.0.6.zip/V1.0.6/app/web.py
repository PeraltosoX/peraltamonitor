import hashlib
import hmac
import re
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from . import VERSION, db, security, youtube, api_keys
from .config import (ADMIN_PASSWORD_HASH, ADMIN_USERNAME, APP_DOMAIN, APP_SECRET,
                     DISCORD_APPLICATION_ID, DISCORD_BOT_TOKEN, DISCORD_CLIENT_SECRET,
                     DISCORD_OWNER_USER_ID, DISCORD_REDIRECT_URI, require)

require("APP_DOMAIN", "APP_SECRET", "ADMIN_PASSWORD_HASH", "DISCORD_APPLICATION_ID",
        "DISCORD_CLIENT_SECRET", "DISCORD_OWNER_USER_ID")
db.init_db()
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=[APP_DOMAIN, "127.0.0.1", "localhost"])
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")
failures = {}


@app.middleware("http")
async def response_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Cache-Control"] = "no-store" if request.url.path.startswith("/api/") else "private"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; "
        "img-src 'self' https://i.ytimg.com https://yt3.ggpht.com https://yt3.googleusercontent.com data:; connect-src 'self'; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
    return response


def origin_ok(request):
    origin = request.headers.get("origin", "")
    return origin in (f"https://{APP_DOMAIN}",) or (
        request.client and request.client.host in ("127.0.0.1", "::1")
        and origin in ("http://127.0.0.1:8081", "http://localhost:8081"))


async def auth(request: Request):
    session = security.read_session(request.cookies.get("plm_session", ""))
    if not session:
        raise HTTPException(401, "Faça login no painel")
    if request.method not in ("GET", "HEAD"):
        if not origin_ok(request):
            raise HTTPException(403, "Origem inválida")
        expected = security.csrf_token(session)
        if not hmac.compare_digest(expected, request.headers.get("x-csrf-token", "")):
            raise HTTPException(403, "Token de sessão inválido")
    return session


async def body(request):
    if int(request.headers.get("content-length", "0") or 0) > 32768:
        raise HTTPException(413, "Dados muito grandes")
    try:
        data = await request.json()
    except ValueError:
        raise HTTPException(400, "JSON inválido")
    if not isinstance(data, dict):
        raise HTTPException(400, "Informe um objeto JSON")
    return data


@app.get("/")
def index():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.get("/health")
def health():
    try:
        db.one("SELECT 1 AS ok")
        db.heartbeat("web", "Painel disponível")
        return {"status": "ok", "version": VERSION}
    except Exception:
        raise HTTPException(503, "Banco indisponível")


@app.post("/api/login")
async def login(request: Request):
    if not origin_ok(request):
        raise HTTPException(403, "Origem inválida")
    data = await body(request)
    ip = request.client.host if request.client else "unknown"
    recent = [stamp for stamp in failures.get(ip, []) if stamp > time.time() - 900]
    if len(recent) >= 8:
        raise HTTPException(429, "Muitas tentativas; aguarde 15 minutos")
    if data.get("username") != ADMIN_USERNAME or not security.verify_password(str(data.get("password", ""))):
        failures[ip] = recent + [time.time()]
        db.log("auth", "warning", "Tentativa de login rejeitada")
        raise HTTPException(401, "Usuário ou senha inválidos")
    failures.pop(ip, None)
    signed = security.sign_session()
    session = security.read_session(signed)
    from fastapi.responses import JSONResponse
    response = JSONResponse({"username": ADMIN_USERNAME, "csrf": security.csrf_token(session)})
    response.set_cookie("plm_session", signed, max_age=8 * 3600, secure=True,
                        httponly=True, samesite="lax", path="/")
    db.log("auth", "info", "Administrador entrou no painel")
    return response


@app.get("/api/session")
def session(current=Depends(auth)):
    return {"username": ADMIN_USERNAME, "csrf": security.csrf_token(current), "version": VERSION}


@app.post("/api/logout")
def logout(current=Depends(auth)):
    from fastapi.responses import JSONResponse
    response = JSONResponse({"ok": True})
    response.delete_cookie("plm_session", path="/")
    return response


@app.get("/api/dashboard")
def dashboard(current=Depends(auth)):
    def count(table, clause="1=1"):
        return db.one(f"SELECT COUNT(*) AS n FROM {table} WHERE {clause}")["n"]
    day = api_keys.quota_day()
    usage = db.one("SELECT calls FROM api_usage WHERE day=?", (day,))
    return {"version": VERSION, "domain": APP_DOMAIN,
            "guilds": count("guilds", "present=1"),
            "authorized_guilds": count("guilds", "present=1 AND active=1"),
            "youtube_channels": count("youtube_channels", "active=1 AND removed=0"),
            "subscriptions": count("subscriptions", "active=1"),
            "videos": count("videos", "seeded=0"),
            "deliveries": count("deliveries", "status='sent'"),
            "pending": count("deliveries", "status IN ('pending','sending','uncertain')"),
            "quota_estimate": usage["calls"] if usage else 0,
            "heartbeats": db.rows("SELECT * FROM service_heartbeats"),
            "recent": db.rows("SELECT * FROM logs ORDER BY id DESC LIMIT 8"),
            "channels": db.rows("SELECT channel_id,name,active,last_poll,last_error,last_new_count,"
                                "ids_baseline_done FROM youtube_channels WHERE removed=0 ORDER BY name"),
            "server_time": db.ts(), "interval": int(db.setting("playlist_interval", "300"))}


@app.get("/api/discord")
def discord_info(current=Depends(auth)):
    return {"application_id": DISCORD_APPLICATION_ID,
            "owner_user_id": DISCORD_OWNER_USER_ID, "token_configured": bool(DISCORD_BOT_TOKEN)}


@app.post("/api/discord/install")
def start_discord_install(current=Depends(auth)):
    state = secrets.token_urlsafe(32)
    db.write("INSERT INTO oauth_states(state_hash,session_id,expires_at) VALUES(?,?,?)",
             (hashlib.sha256(state.encode()).hexdigest(), current["sid"], db.ts() + 600))
    params = {"client_id": DISCORD_APPLICATION_ID, "scope": "bot identify", "permissions": "150528",
              "response_type": "code", "redirect_uri": DISCORD_REDIRECT_URI,
              "state": state, "integration_type": "0"}
    return {"url": "https://discord.com/oauth2/authorize?" + urlencode(params)}


@app.get("/auth/discord/callback")
async def discord_callback(request: Request):
    from fastapi.responses import HTMLResponse, RedirectResponse
    session = security.read_session(request.cookies.get("plm_session", ""))
    state = request.query_params.get("state", "")
    code = request.query_params.get("code", "")
    if not session or not state or not code:
        raise HTTPException(403, "Instalação precisa começar pelo painel autenticado")
    hashed = hashlib.sha256(state.encode()).hexdigest()
    with db.transaction() as con:
        row = con.execute("SELECT * FROM oauth_states WHERE state_hash=?", (hashed,)).fetchone()
        if not row or row["expires_at"] < db.ts() or row["session_id"] != session["sid"]:
            raise HTTPException(403, "Instalação expirada ou iniciada fora do painel")
        con.execute("DELETE FROM oauth_states WHERE state_hash=?", (hashed,))
    import httpx
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            token = await client.post("https://discord.com/api/v10/oauth2/token",
                                      data={"client_id": DISCORD_APPLICATION_ID,
                                            "client_secret": DISCORD_CLIENT_SECRET,
                                            "grant_type": "authorization_code", "code": code,
                                            "redirect_uri": DISCORD_REDIRECT_URI})
            if token.status_code != 200:
                raise HTTPException(400, "Discord rejeitou o retorno da instalação")
            token_data = token.json()
            who = await client.get("https://discord.com/api/v10/users/@me",
                                   headers={"Authorization": "Bearer " + token_data["access_token"]})
        if who.status_code != 200 or str(who.json().get("id")) != DISCORD_OWNER_USER_ID:
            db.log("auth", "warning", "Instalação rejeitada: usuário Discord não autorizado")
            raise HTTPException(403, "Somente seu Discord User ID pode autorizar servidores")
        guild = token_data.get("guild")
        if not isinstance(guild, dict) or not str(guild.get("id", "")).isdigit():
            raise HTTPException(400, "Discord não confirmou o servidor; ative Require OAuth2 Code Grant")
        guild_id = str(guild["id"])
        callback_guild = request.query_params.get("guild_id", "")
        if callback_guild and callback_guild != guild_id:
            raise HTTPException(400, "Servidor retornado pelo Discord não confere")
        db.write("INSERT INTO guilds(guild_id,name,present,active,owner_verified,last_seen) VALUES(?,?,0,0,1,?) "
                 "ON CONFLICT(guild_id) DO UPDATE SET owner_verified=1,name=excluded.name",
                 (guild_id, str(guild.get("name") or "Servidor autorizado")[:100], db.ts()))
        db.log("auth", "info", f"Servidor {guild_id} verificado pelo Discord User ID autorizado")
        return RedirectResponse("/?installed=1", status_code=303)
    except httpx.HTTPError:
        raise HTTPException(502, "Falha de conexão com o Discord durante a autorização")


@app.get("/api/guilds")
def guilds(current=Depends(auth)):
    result = db.rows("SELECT * FROM guilds ORDER BY present DESC,name")
    for guild in result:
        guild["custom_destination_count"] = db.one("SELECT COUNT(DISTINCT r.channel_id) AS n FROM channel_destinations r "
                                                   "JOIN youtube_channels y ON y.channel_id=r.youtube_channel_id "
                                                   "WHERE r.guild_id=? AND y.routing_custom=1 AND y.removed=0", (guild["guild_id"],))["n"]
        guild["channels"] = db.rows("SELECT * FROM discord_channels WHERE guild_id=? ORDER BY name",
                                    (guild["guild_id"],))
        guild["destinations"] = db.rows("SELECT d.channel_id,COALESCE(c.name,d.channel_id) AS name,"
                                        "c.can_view,c.can_send,c.can_embed,c.can_mention "
                                        "FROM guild_destinations d LEFT JOIN discord_channels c "
                                        "ON c.channel_id=d.channel_id AND c.guild_id=d.guild_id "
                                        "WHERE d.guild_id=? ORDER BY d.created_at,d.channel_id", (guild["guild_id"],))
    return result


@app.patch("/api/guilds/{guild_id}")
async def update_guild(guild_id: str, request: Request, current=Depends(auth)):
    g = db.one("SELECT * FROM guilds WHERE guild_id=?", (guild_id,))
    if not g:
        raise HTTPException(404, "Servidor não encontrado")
    data = await body(request)
    target = str(data.get("target_channel_id", g["target_channel_id"]) or "")
    if target:
        channel = db.one("SELECT * FROM discord_channels WHERE guild_id=? AND channel_id=?", (guild_id, target))
        if not channel:
            raise HTTPException(400, "Canal não pertence a este servidor")
    else:
        channel = None
    active = bool(data.get("active", g["active"]))
    if active and (not g["present"] or not g["owner_verified"]):
        raise HTTPException(400, "Instale pelo painel com seu Discord User ID antes de autorizar")
    destination_count = db.one("SELECT COUNT(*) AS n FROM (SELECT channel_id FROM guild_destinations WHERE guild_id=? "
                               "UNION SELECT r.channel_id FROM channel_destinations r JOIN youtube_channels y "
                               "ON y.channel_id=r.youtube_channel_id WHERE r.guild_id=? AND y.routing_custom=1 "
                               "AND y.removed=0)", (guild_id,guild_id))["n"]
    if active and not (target or destination_count):
        raise HTTPException(400, "Selecione um canal para ativar o servidor")
    if active and target and (not channel["can_view"] or not channel["can_send"]):
        raise HTTPException(400, "Bot não pode visualizar/enviar nesse canal")
    mention = bool(data.get("mention_everyone", g["mention_everyone"]))
    if mention and ((channel and not channel["can_mention"]) or any(
            not dest["can_mention"] for dest in db.rows("SELECT c.can_mention FROM guild_destinations d "
                "LEFT JOIN discord_channels c ON c.channel_id=d.channel_id AND c.guild_id=d.guild_id "
                "WHERE d.guild_id=?", (guild_id,)))):
        raise HTTPException(400, "Todos os destinos precisam de permissão para @everyone")
    template_id = int(data.get("template_id", g["template_id"]))
    if not db.one("SELECT id FROM templates WHERE id=?", (template_id,)):
        raise HTTPException(400, "Modelo inválido")
    with db.transaction() as con:
        if target:
            con.execute("INSERT OR IGNORE INTO guild_destinations(guild_id,channel_id,created_at) VALUES(?,?,?)",
                        (guild_id,target,db.ts()))
        con.execute("UPDATE guilds SET active=?,target_channel_id=?,mention_everyone=?,notify_uploads=?,"
                    "notify_scheduled=?,template_id=? WHERE guild_id=?",
                    (int(active), target or None, int(mention), int(bool(data.get("notify_uploads", g["notify_uploads"]))),
                     int(bool(data.get("notify_scheduled", g["notify_scheduled"]))), template_id, guild_id))
        if active and not g["active"]:
            con.execute("UPDATE subscriptions SET notify_after=? WHERE guild_id=? AND active=1",
                        (time.time(), guild_id))
    db.log("admin", "info", f"Configuração do servidor {guild_id} atualizada")
    return {"ok": True}


@app.post("/api/guilds/{guild_id}/test")
def test_guild(guild_id: str, current=Depends(auth)):
    guild = db.one("SELECT * FROM guilds WHERE guild_id=?", (guild_id,))
    if not guild or not guild["present"] or not guild["active"] or not guild["target_channel_id"]:
        raise HTTPException(400, "Autorize o servidor e selecione um canal")
    db.write("INSERT INTO test_requests(guild_id,channel_id,created_at,updated_at) VALUES(?,?,?,?)",
             (guild_id, guild["target_channel_id"], db.ts(), db.ts()))
    return {"ok": True, "message": "Teste entrou na fila do bot"}


@app.post("/api/guilds/{guild_id}/destinations")
async def add_destination(guild_id: str, request: Request, current=Depends(auth)):
    data = await body(request)
    channel_id = str(data.get("channel_id", ""))
    guild = db.one("SELECT * FROM guilds WHERE guild_id=?", (guild_id,))
    channel = db.one("SELECT * FROM discord_channels WHERE guild_id=? AND channel_id=?", (guild_id,channel_id))
    if not guild or not guild["present"] or not guild["owner_verified"]:
        raise HTTPException(400, "Servidor não autorizado no painel")
    if not channel or not channel["can_view"] or not channel["can_send"]:
        raise HTTPException(400, "Bot sem permissão de visualizar/enviar nesse canal")
    if guild["mention_everyone"] and not channel["can_mention"]:
        raise HTTPException(400, "Canal sem permissão para @everyone")
    with db.transaction() as con:
        con.execute("INSERT OR IGNORE INTO guild_destinations(guild_id,channel_id,created_at) VALUES(?,?,?)",
                    (guild_id,channel_id,db.ts()))
        con.execute("UPDATE guilds SET target_channel_id=COALESCE(target_channel_id,?) WHERE guild_id=?",
                    (channel_id,guild_id))
    db.log("admin", "info", f"Destino {channel_id} adicionado ao servidor {guild_id}")
    return {"ok": True}


@app.delete("/api/guilds/{guild_id}/destinations/{channel_id}")
def delete_destination(guild_id: str, channel_id: str, current=Depends(auth)):
    with db.transaction() as con:
        if not con.execute("DELETE FROM guild_destinations WHERE guild_id=? AND channel_id=?",
                           (guild_id,channel_id)).rowcount:
            raise HTTPException(404, "Destino não encontrado")
        con.execute("UPDATE deliveries SET status='skipped',error='Destino removido',updated_at=? "
                    "WHERE guild_id=? AND channel_id=? AND status='pending'", (db.ts(),guild_id,channel_id))
        con.execute("DELETE FROM channel_destinations WHERE guild_id=? AND channel_id=?", (guild_id,channel_id))
        next_dest = con.execute("SELECT channel_id FROM guild_destinations WHERE guild_id=? "
                                "ORDER BY created_at,channel_id LIMIT 1", (guild_id,)).fetchone()
        custom_remaining = con.execute("SELECT 1 FROM channel_destinations r JOIN youtube_channels y "
                                       "ON y.channel_id=r.youtube_channel_id WHERE r.guild_id=? "
                                       "AND y.routing_custom=1 AND y.removed=0 LIMIT 1", (guild_id,)).fetchone()
        con.execute("UPDATE guilds SET target_channel_id=?,active=CASE WHEN ? THEN active ELSE 0 END "
                    "WHERE guild_id=?", (next_dest["channel_id"] if next_dest else None,
                                          int(bool(next_dest or custom_remaining)),guild_id))
    db.log("admin", "info", f"Destino {channel_id} removido do servidor {guild_id}")
    return {"ok": True}


@app.post("/api/guilds/{guild_id}/destinations/{channel_id}/test")
def test_destination(guild_id: str, channel_id: str, current=Depends(auth)):
    if not db.one("SELECT 1 FROM guild_destinations WHERE guild_id=? AND channel_id=?", (guild_id,channel_id)):
        raise HTTPException(404, "Destino não encontrado")
    db.write("INSERT INTO test_requests(guild_id,channel_id,created_at,updated_at) VALUES(?,?,?,?)",
             (guild_id,channel_id,db.ts(),db.ts()))
    return {"ok": True}


@app.get("/api/youtube-channels")
def youtube_channels(current=Depends(auth)):
    return db.rows("SELECT * FROM youtube_channels WHERE removed=0 ORDER BY name")


@app.post("/api/youtube-channels")
async def add_youtube_channel(request: Request, current=Depends(auth)):
    data = await body(request)
    cid = str(data.get("channel_id", "")).strip()
    if not re.fullmatch(r"UC[A-Za-z0-9_-]{22}", cid):
        raise HTTPException(400, "Informe um Channel ID UC válido (24 caracteres)")
    try:
        info = await youtube.register_channel(cid)
    except youtube.YouTubeError as exc:
        raise HTTPException(400, str(exc))
    return info


@app.patch("/api/youtube-channels/{channel_id}")
async def update_youtube_channel(channel_id: str, request: Request, current=Depends(auth)):
    data = await body(request)
    if not db.write("UPDATE youtube_channels SET active=? WHERE channel_id=? AND removed=0",
                    (int(bool(data.get("active"))), channel_id)):
        raise HTTPException(404, "Canal não encontrado")
    return {"ok": True}


@app.post("/api/youtube-channels/{channel_id}/check")
async def check_youtube_channel(channel_id: str, current=Depends(auth)):
    channel = db.one("SELECT uploads_id FROM youtube_channels WHERE channel_id=? AND active=1 AND removed=0",
                     (channel_id,))
    if not channel:
        raise HTTPException(404, "Canal não encontrado ou pausado")
    try:
        result = await youtube.check_playlist(channel_id, channel["uploads_id"])
    except youtube.YouTubeError as exc:
        raise HTTPException(400, str(exc))
    db.log("admin", "info", f"Verificação da playlist {channel_id}: {result['found']} ID(s), "
           f"{result['new']} nova(s), {result['queued']} entrega(s)")
    return result


@app.delete("/api/youtube-channels/{channel_id}")
def delete_youtube_channel(channel_id: str, current=Depends(auth)):
    with db.transaction() as con:
        if not con.execute("UPDATE youtube_channels SET active=0,removed=1 WHERE channel_id=? AND removed=0",
                           (channel_id,)).rowcount:
            raise HTTPException(404, "Canal não encontrado")
        con.execute("UPDATE deliveries SET status='skipped',error='Canal YouTube removido',updated_at=? "
                    "WHERE video_id IN (SELECT video_id FROM videos WHERE channel_id=?) AND status='pending'",
                    (db.ts(),channel_id))
        con.execute("DELETE FROM subscriptions WHERE channel_id=?", (channel_id,))
        con.execute("DELETE FROM channel_destinations WHERE youtube_channel_id=?", (channel_id,))
        con.execute("DELETE FROM pending_video_ids WHERE channel_id=?", (channel_id,))
    db.log("admin", "info", f"Canal YouTube {channel_id} removido com suas associações")
    return {"ok": True}


@app.get("/api/subscriptions")
def subscriptions(current=Depends(auth)):
    return db.rows("SELECT s.*,g.name AS guild_name,y.name AS youtube_name FROM subscriptions s "
                   "JOIN guilds g ON g.guild_id=s.guild_id "
                   "JOIN youtube_channels y ON y.channel_id=s.channel_id ORDER BY g.name,y.name")


@app.post("/api/subscriptions")
async def add_subscription(request: Request, current=Depends(auth)):
    data = await body(request)
    gid, cid = str(data.get("guild_id", "")), str(data.get("channel_id", ""))
    if not db.one("SELECT 1 FROM guilds WHERE guild_id=? AND active=1", (gid,)):
        raise HTTPException(400, "Autorize primeiro o servidor")
    if not db.one("SELECT 1 FROM youtube_channels WHERE channel_id=? AND removed=0", (cid,)):
        raise HTTPException(400, "Channel ID não cadastrado")
    with db.transaction() as con:
        cutoff = time.time()
        con.execute("INSERT INTO subscriptions(guild_id,channel_id,active,notify_after) VALUES(?,?,1,?) "
                    "ON CONFLICT(guild_id,channel_id) DO UPDATE SET active=1,notify_after=excluded.notify_after",
                    (gid, cid, cutoff))
        channel = con.execute("SELECT routing_custom FROM youtube_channels WHERE channel_id=?", (cid,)).fetchone()
        if channel["routing_custom"]:
            con.execute("INSERT OR IGNORE INTO channel_destinations(youtube_channel_id,guild_id,channel_id,notify_after,created_at) "
                        "SELECT ?,guild_id,channel_id,?,? FROM guild_destinations WHERE guild_id=?", (cid,cutoff,db.ts(),gid))
    return {"ok": True}


@app.delete("/api/subscriptions/{guild_id}/{channel_id}")
def remove_subscription(guild_id: str, channel_id: str, current=Depends(auth)):
    with db.transaction() as con:
        if not con.execute("DELETE FROM subscriptions WHERE guild_id=? AND channel_id=?",
                           (guild_id,channel_id)).rowcount:
            raise HTTPException(404, "Associação não encontrada")
        con.execute("DELETE FROM channel_destinations WHERE guild_id=? AND youtube_channel_id=?", (guild_id,channel_id))
        con.execute("UPDATE deliveries SET status='skipped',error='Associação removida',updated_at=? "
                    "WHERE guild_id=? AND status='pending' AND video_id IN "
                    "(SELECT video_id FROM videos WHERE channel_id=?)", (db.ts(),guild_id,channel_id))
    db.log("admin", "info", f"Associação {guild_id} / {channel_id} removida")
    return {"ok": True}


@app.patch("/api/subscriptions/{guild_id}/{channel_id}")
async def toggle_subscription(guild_id: str, channel_id: str, request: Request, current=Depends(auth)):
    data = await body(request)
    active = bool(data.get("active"))
    with db.transaction() as con:
        if not con.execute("UPDATE subscriptions SET active=?,notify_after=CASE WHEN ? THEN ? ELSE notify_after END "
                           "WHERE guild_id=? AND channel_id=?",
                           (int(active),int(active),time.time(),guild_id,channel_id)).rowcount:
            raise HTTPException(404, "Associação não encontrada")
        if not active:
            con.execute("UPDATE deliveries SET status='skipped',error='Associação pausada',updated_at=? "
                        "WHERE guild_id=? AND status='pending' AND video_id IN "
                        "(SELECT video_id FROM videos WHERE channel_id=?)", (db.ts(),guild_id,channel_id))
    return {"ok": True}


@app.get("/api/templates")
def templates(current=Depends(auth)):
    return db.rows("SELECT * FROM templates ORDER BY id")


@app.post("/api/templates")
async def create_template(request: Request, current=Depends(auth)):
    data = await body(request)
    name, content = str(data.get("name", "")).strip()[:80], str(data.get("content", ""))[:1900]
    mode = str(data.get("preview_mode", "youtube"))
    if not name or not content:
        raise HTTPException(400, "Nome e mensagem são obrigatórios")
    if mode not in ("youtube", "custom"):
        raise HTTPException(400, "Tipo de prévia inválido")
    try:
        color = int(data.get("embed_color", 15086414))
    except (ValueError, TypeError):
        raise HTTPException(400, "Cor do embed inválida")
    if not 0 <= color <= 0xFFFFFF:
        raise HTTPException(400, "Cor do embed inválida")
    with db.transaction() as con:
        cur = con.execute("INSERT INTO templates(name,content,embed_title,embed_description,"
                          "embed_footer,embed_image,embed_color,preview_mode) VALUES(?,?,?,?,?,?,?,?)",
                          (name, content, str(data.get("embed_title", ""))[:240],
                           str(data.get("embed_description", ""))[:3800],
                           str(data.get("embed_footer", ""))[:200],
                           str(data.get("embed_image", ""))[:500], color, mode))
        return {"id": cur.lastrowid}


@app.patch("/api/templates/{template_id}")
async def update_template(template_id: int, request: Request, current=Depends(auth)):
    data = await body(request)
    existing = db.one("SELECT preview_mode FROM templates WHERE id=?", (template_id,))
    if not existing:
        raise HTTPException(404, "Modelo não encontrado")
    mode = str(data.get("preview_mode", existing["preview_mode"]))
    if mode not in ("youtube", "custom"):
        raise HTTPException(400, "Tipo de prévia inválido")
    try:
        color = int(data.get("embed_color", 15086414))
    except (ValueError, TypeError):
        raise HTTPException(400, "Cor do embed inválida")
    if not 0 <= color <= 0xFFFFFF or not str(data.get("name", "")).strip() or not str(data.get("content", "")).strip():
        raise HTTPException(400, "Informe nome, mensagem e cor válida")
    if not db.write("UPDATE templates SET name=?,content=?,embed_title=?,embed_description=?,"
                    "embed_footer=?,embed_image=?,embed_color=?,preview_mode=? WHERE id=?",
                    (str(data.get("name", ""))[:80], str(data.get("content", ""))[:1900],
                     str(data.get("embed_title", ""))[:240], str(data.get("embed_description", ""))[:3800],
                     str(data.get("embed_footer", ""))[:200], str(data.get("embed_image", ""))[:500],
                     color, mode, template_id)):
        raise HTTPException(404, "Modelo não encontrado")
    return {"ok": True}


@app.get("/api/activity")
def activity(current=Depends(auth)):
    return {"videos": db.rows("SELECT v.*,y.name AS channel_name FROM videos v JOIN youtube_channels y "
                              "ON y.channel_id=v.channel_id WHERE v.seeded=0 ORDER BY v.first_seen DESC LIMIT 60"),
            "deliveries": db.rows("SELECT d.*,g.name AS guild_name,v.title,v.channel_id AS youtube_channel_id,"
                                  "y.name AS youtube_name,COALESCE(c.name,d.channel_id) AS destination_name FROM deliveries d "
                                  "JOIN guilds g ON g.guild_id=d.guild_id JOIN videos v ON v.video_id=d.video_id "
                                  "JOIN youtube_channels y ON y.channel_id=v.channel_id "
                                  "LEFT JOIN discord_channels c ON c.channel_id=d.channel_id AND c.guild_id=d.guild_id "
                                  "ORDER BY d.id DESC LIMIT 100"),
            "tests": db.rows("SELECT t.id,t.guild_id,t.channel_id,t.youtube_channel_id,t.status,t.message_id,t.error,"
                             "t.created_at,t.updated_at,g.name AS guild_name,COALESCE(c.name,t.channel_id) AS destination_name "
                             "FROM test_requests t LEFT JOIN guilds g ON g.guild_id=t.guild_id "
                             "LEFT JOIN discord_channels c ON c.channel_id=t.channel_id ORDER BY t.id DESC LIMIT 20"),
            "logs": db.rows("SELECT * FROM logs ORDER BY id DESC LIMIT 100")}


@app.delete("/api/logs")
def clear_logs(current=Depends(auth)):
    removed = db.write("DELETE FROM logs")
    return {"ok": True, "removed": removed}


@app.post("/api/deliveries/{delivery_id}/retry")
def retry_delivery(delivery_id: int, current=Depends(auth)):
    delivery = db.one("SELECT status FROM deliveries WHERE id=?", (delivery_id,))
    if not delivery or delivery["status"] not in ("failed", "uncertain"):
        raise HTTPException(400, "Somente falhas/resultados incertos podem ser reenviados")
    db.write("UPDATE deliveries SET status='pending',error=NULL,next_try=?,updated_at=? WHERE id=?",
             (db.ts(), db.ts(), delivery_id))
    db.log("admin", "warning", f"Reenvio manual solicitado para entrega {delivery_id}")
    return {"ok": True}


@app.get("/api/settings")
def settings(current=Depends(auth)):
    day = api_keys.quota_day()
    usage = db.one("SELECT calls FROM api_usage WHERE day=?", (day,))
    return {"playlist_interval": int(db.setting("playlist_interval", "300")),
            "timezone": db.setting("timezone", "America/Sao_Paulo"),
            "quota_estimate": usage["calls"] if usage else 0,
            "google_key_configured": any(r["configured"] and r["active"] and r["primary_flag"]
                                          for r in api_keys.public_list())}


def key_fields(data):
    name = str(data.get("name", "")).strip()[:80]
    key = str(data.get("key", "")).strip()
    project = str(data.get("project_id", "")).strip()[:100]
    try:
        limit = int(data.get("quota_limit", 10000))
        priority = int(data.get("priority", 100))
    except (ValueError, TypeError):
        raise HTTPException(400, "Limite de cota inválido")
    if not name or not 100 <= limit <= 10000000 or not 1 <= priority <= 1000000 or len(key) > 256:
        raise HTTPException(400, "Informe nome, cota válida e chave com até 256 caracteres")
    return name, key, project, limit, priority


@app.get("/api/api-keys")
def list_api_keys(current=Depends(auth)):
    return api_keys.public_list()


@app.post("/api/api-keys")
async def add_api_key(request: Request, current=Depends(auth)):
    data = await body(request)
    name, key, project, limit, priority = key_fields(data)
    active = bool(key and data.get("active", True))
    primary = bool(active and data.get("primary", False))
    with db.transaction() as con:
        if primary:
            con.execute("UPDATE api_credentials SET primary_flag=0")
        cur = con.execute("INSERT INTO api_credentials(name,project_id,encrypted_key,last4,"
                          "active,primary_flag,quota_limit,priority,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (name, project, api_keys.encrypt(key) if key else None,
                           key[-4:] if key else "", int(active), int(primary), limit, priority, db.ts()))
    db.log("api", "info", f"Credencial {cur.lastrowid} criada")
    return {"id":cur.lastrowid}


@app.patch("/api/api-keys/{credential_id}")
async def edit_api_key(credential_id: int, request: Request, current=Depends(auth)):
    existing = db.one("SELECT * FROM api_credentials WHERE id=?", (credential_id,))
    if not existing:
        raise HTTPException(404, "Credencial não encontrada")
    data = await body(request)
    name, key, project, limit, priority = key_fields({**existing, **data})
    configured = bool(key or existing["encrypted_key"])
    active = bool(configured and data.get("active", existing["active"]))
    primary = bool(active and data.get("primary", existing["primary_flag"]))
    if data.get("primary") and not active:
        raise HTTPException(400, "Configure e ative a chave antes de torná-la principal")
    with db.transaction() as con:
        if primary:
            con.execute("UPDATE api_credentials SET primary_flag=0")
        con.execute("UPDATE api_credentials SET name=?,project_id=?,encrypted_key=?,last4=?,"
                    "active=?,primary_flag=?,quota_limit=?,priority=?,retry_after=0,last_error='' WHERE id=?",
                    (name, project, api_keys.encrypt(key) if key else existing["encrypted_key"],
                     key[-4:] if key else existing["last4"], int(active), int(primary), limit, priority, credential_id))
    db.log("api", "info", f"Credencial {credential_id} atualizada")
    return {"ok":True}


@app.delete("/api/api-keys/{credential_id}")
def remove_api_key(credential_id: int, current=Depends(auth)):
    if not db.write("DELETE FROM api_credentials WHERE id=?", (credential_id,)):
        raise HTTPException(404, "Credencial não encontrada")
    db.log("api", "info", f"Credencial {credential_id} removida")
    return {"ok":True}


@app.post("/api/api-keys/{credential_id}/test")
async def test_api_key(credential_id: int, current=Depends(auth)):
    try:
        await youtube.test_key(credential_id)
    except youtube.YouTubeError as exc:
        db.log("api", "warning", f"Teste da credencial {credential_id} falhou")
        raise HTTPException(400, str(exc))
    db.log("api", "info", f"Credencial {credential_id} validada")
    return {"ok":True}


@app.patch("/api/settings")
async def update_settings(request: Request, current=Depends(auth)):
    data = await body(request)
    try:
        interval = int(data.get("playlist_interval", db.setting("playlist_interval", "300")))
        zone = str(data.get("timezone", db.setting("timezone", "America/Sao_Paulo")))
        ZoneInfo(zone)
    except (ValueError, KeyError, TypeError):
        raise HTTPException(400, "Intervalo ou fuso inválido")
    if not 30 <= interval <= 86400:
        raise HTTPException(400, "Intervalo deve ficar entre 30 e 86400 segundos")
    db.write("UPDATE settings SET value=? WHERE key='playlist_interval'", (str(interval),))
    db.write("UPDATE settings SET value=? WHERE key='timezone'", (zone,))
    return {"ok": True}


from .channel_editor import build_router
app.include_router(build_router(auth, body))
