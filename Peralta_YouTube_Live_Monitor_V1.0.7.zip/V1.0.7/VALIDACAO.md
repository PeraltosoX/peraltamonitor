# Validação da V1.0.7

Verificações concluídas em 27/09/2026, após a retomada do trabalho. O layout foi adaptado a partir do código do painel do servidor ChatFlow Peralta 3.0.3, com as cores vermelha e azul. O ícone e o favicon têm os mesmos bytes da V1.0.6.

## Testes automatizados

**40 testes aprovados** com Python 3.12 e as dependências de `requirements.txt`.

```bash
python -m unittest discover -s tests -v
```

| Área | O que foi conferido |
| --- | --- |
| Atualização | Bancos criados com os esquemas reais da V1.0.5 e V1.0.6 e dados de teste; migração executada duas vezes, preservando registros, credenciais cifradas, histórico, mensagens por destino e marcos de monitoramento. |
| Limpar entregas | Remove registros finalizados da exibição sem apagar o controle de duplicações, alterar configurações ou limpar os outros históricos. A limpeza permanece após reiniciar; novas entregas aparecem normalmente. |
| Limpar testes | Mantém pendentes e envios em andamento. O resultado individual continua disponível ao editor, sem devolver o conteúdo privado do rascunho nesse endpoint. |
| Filas | Um item pendente continua visível quando termina depois da limpeza. Um reenvio manual autorizado volta à fila visível. |
| Autorização da limpeza | As três ações exigem login e proteção CSRF. |
| Destinos independentes | O mesmo canal envia textos e estilos distintos a dois servidores. Um novo destino desse canal não passa a receber avisos dos outros canais. |
| Pausa e retomada | Pausar um destino cancela somente suas pendências. Retomar estabelece o início para novas publicações, preservando os demais destinos. |
| Modelos | Personalizar cria uma cópia e preserva modelos compartilhados. Uma gravação inválida é revertida integralmente. |
| Concorrência | Uma configuração desatualizada é recusada antes de sobrescrever escolhas mais recentes. |
| Teste de mensagem | Usa o rascunho e o estilo selecionado, bloqueando todas as menções. Os envios dos testes automatizados são simulados. |
| Compatibilidade | Associações e destinos antigos continuam funcionando; remover um destino mantém os outros e o histórico. |
| YouTube | IDs conhecidos não voltam à consulta de detalhes, falhas permitem nova tentativa e uma live agendada não gera outro aviso ao iniciar. |
| Acesso e APIs | Sessão, CSRF, autorização do proprietário, proteção das credenciais, troca de chave e contagem local. |
| Estimativa | O consumo-base considera canais YouTube ativos e intervalo, sem multiplicar pelos destinos Discord. |
| Backup | Cópia íntegra, recusa de sobrescrita e recusa de criar um backup vazio quando a origem não existe. |

## Interface no navegador

Teste automatizado em Chromium, com inspeção visual das telas:

- Computador: **1440 × 1000**.
- Tablet: **768 × 1024**.
- Celular: **390 × 844**.
- Temas claro e escuro em todas as áreas; escolha preservada depois de recarregar e sair da conta.
- Login, menu lateral no computador, menu recolhível no celular, fechamento por Escape e abertura do editor.
- Limpeza pelos três botões, cancelamento da confirmação e preservação dos itens em andamento.
- Abas de atividade também navegáveis com as setas, Home e End no teclado.
- Criação de mensagens diferentes para dois servidores, uma com prévia do YouTube e outra com embed personalizado.
- Alternância entre destinos sem perder os rascunhos; revisão, salvamento e reabertura das escolhas.
- Ausência de erros JavaScript no fluxo exercitado.
- Telas verificadas sem transbordamento horizontal da página no celular; tabelas e navegação têm rolagem própria quando necessário.
- Conferência específica de rolagem: escolher uma área no menu móvel mantém a página no topo, com o título disponível abaixo do cabeçalho.

Os dados da conferência visual são demonstrativos. A sintaxe dos scripts JavaScript e dos módulos Python também foi conferida.

## Alcance das verificações

Não foi usado o banco real da VPS, nem foram enviados avisos reais ao Discord ou alteradas suas contas. A preservação foi verificada com uma base de teste baseada no esquema anterior; faça o backup descrito em [ATUALIZAR_SEM_PERDER_DADOS.md](ATUALIZAR_SEM_PERDER_DADOS.md) antes de instalar.

A instalação Docker na VPS, as permissões reais dos destinos, a resposta da API YouTube e os envios com suas credenciais precisam ser conferidos após a atualização. Para conferir o envio, escolha um destino no editor e use **Enviar teste neste destino**: essa ação envia uma mensagem real, sem menções.

O ZIP contém código, testes e documentação. Seu banco e seu `.env` continuam na instalação existente.
