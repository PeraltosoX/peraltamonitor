# Configurar Telegram na V1.0.8

Toda a configuração do Telegram é feita no painel. O Discord mantém sua própria seção. As APIs do YouTube e o intervalo de busca continuam compartilhados.

## Bot e administrador

Abra **Telegram → Bot e administrador** e preencha:

| Campo | O que informar |
| --- | --- |
| ID do administrador do Telegram | Seu ID numérico de usuário no Telegram, positivo. É diferente do ID do Discord e do ID negativo de um grupo/canal. |
| Usuário do administrador | Seu `@usuário`, se tiver. Este campo ajuda na identificação; a autorização usa o ID numérico. |
| Token do bot | O token gerado pelo [BotFather](https://t.me/BotFather) para seu bot. |

Marque **Ativar notificações do Telegram** e clique em **Validar e salvar configuração**. O painel mostra o nome e o @usuário do bot confirmado pelo Telegram. O token é cifrado com a `APP_SECRET` da instalação e não volta nas respostas do painel. Ao editar, deixe o token em branco para mantê-lo.

Use um bot exclusivo para este monitor. Se o token já tem um webhook em outro serviço, o painel avisa e não altera esse webhook. Se outro serviço estiver consumindo as atualizações do mesmo bot, o erro aparece na conexão.

## Receber somente no privado

1. Configure seu ID de administrador e ative o Telegram como acima.
2. Abra **Telegram → Meu privado** e use **Abrir @seubot**.
3. Envie `/start` ou uma mensagem ao bot **a partir da conta que tem o ID cadastrado**.
4. Volte ao painel: o estado muda para **Privado vinculado**. A página verifica a conexão periodicamente; também há o botão **Verificar conexão**.
5. Em **Telegram → Canais e avisos**, cadastre ou escolha um YouTube e adicione **Meu privado** entre os destinos. Personalize a mensagem e salve.

Isso funciona sem cadastrar nenhum grupo ou canal do Telegram. Outras pessoas que iniciem o bot não são cadastradas para receber avisos. Ser administrador de um grupo não concede acesso ao privado. O bot não funciona como chat de comandos administrativos; ele recebe a sua mensagem para confirmar o vínculo, e o painel mostra o resultado.

Trocar o ID do administrador desvincula o privado anterior e cancela suas mensagens ainda pendentes. O novo administrador precisa iniciar o bot. Alterar apenas o @usuário não muda a autorização. Um envio já em andamento pode concluir antes da troca.

## Canais e grupos

1. Adicione o bot ao canal/grupo como administrador. Para canais, permita **publicar mensagens**.
2. Abra **Telegram → Canais e grupos**.
3. Informe o ID negativo do chat, por exemplo `-100…`, ou o `@usuário` público do canal/grupo. Não use links de convite.
4. Clique em **Verificar e adicionar**. O painel confirma o chat e as permissões do bot.
5. Escolha esse destino na edição de **Telegram → Canais e avisos**.

Cada destino tem ações de teste, verificação, pausa/retomada e remoção. Se as permissões mudarem, o resultado dos envios explica a falha. Depois de corrigir, use **Verificar** e teste novamente. Se um grupo mudar de ID ao ser convertido em supergrupo, cadastre e verifique o novo ID e selecione o novo destino.

## YouTube, mensagens e modelos

Em **Adicionar canal YouTube**, você pode escolher um canal já cadastrado no monitor ou informar um novo Channel ID `UC…`. Escolher um canal existente reaproveita a mesma busca e os mesmos IDs conhecidos. Um novo canal registra as publicações existentes como conhecidas, sem enviá-las.

No editor, adicione seus destinos e selecione um por vez para personalizar. Cada canal, grupo e privado pode ter texto, formato, prévia de link, envio sem som e tipos de publicação próprios. Os rascunhos são mantidos ao trocar de destino; clique em **Salvar configuração** para aplicar.

As variáveis disponíveis são `{tipo}`, `{canal}`, `{titulo}`, `{link}`, `{data}`, `{hora}` e `{live_id}`. Data/hora representam o horário da live quando houver. O link do YouTube é incluído automaticamente se faltar na mensagem.

O formato **Texto simples** não interpreta marcação. **HTML do Telegram** aceita negrito, itálico, sublinhado, riscado, código, citação e links HTTPS: `b`, `strong`, `i`, `em`, `u`, `s`, `code`, `pre`, `blockquote`, `a`. Para links, use `<a href="https://…">texto</a>`. O painel valida a marcação e escapa os dados do vídeo. O modelo tem limite de 3.000 caracteres; a mensagem pronta respeita o limite de 4.096 do Telegram.

**Modelos de mensagem** guarda bases reutilizáveis. Aplicar um modelo copia seus campos para o destino escolhido. Editar o modelo depois não modifica automaticamente os destinos já personalizados. A prévia usa os dados de uma publicação conhecida ou um exemplo, sem nova chamada à API YouTube. A aparência final e a prévia do link são produzidas pelo Telegram.

## Testes, filas e históricos

**Enviar teste neste destino** pede confirmação e coloca o rascunho na fila, com indicação de teste. Ele envia uma mensagem real após o worker processar. Consulte o resultado em **Telegram → Entregas e logs → Testes por destino**.

As abas de entregas, testes e logs têm botões próprios para limpar. A limpeza retira os envios finalizados da exibição, preserva a fila e mantém o registro que evita duplicações. Não apaga mensagens recebidas no Telegram.

Falhas de conexão que confirmam que o envio não começou e limites temporários são tentados novamente, com espera e limite de tentativas. Um timeout depois de iniciar o envio, uma resposta incerta ou um reinício durante o envio deixam o estado **Conferir envio**. Confira o chat antes de usar **Tentar novamente**, porque a mensagem pode já ter chegado.

O Telegram roda no serviço `worker`, junto da busca YouTube, em tarefas separadas. Uma falha do Telegram não bloqueia a fila do Discord. Pausar ou remover os avisos de uma plataforma mantém os da outra. Retomar um destino ou canal considera novas publicações a partir da retomada, sem recuperar o período pausado.

Referências: [Telegram Bot API](https://core.telegram.org/bots/api) e [funcionamento dos bots](https://core.telegram.org/bots#how-do-bots-work).
