# Validação da V1.0.8

Conferências locais concluídas em 28/09/2026. O painel mantém o visual baseado no ChatFlow Peralta, em vermelho e azul, com claro/escuro e o ícone original.

## Testes de funcionamento

**60 testes aprovados**, usando Python 3.12 e as dependências de `requirements.txt`:

```bash
python -m unittest discover -s tests -v
```

| Área | Evidência verificada |
| --- | --- |
| Migração | Esquemas V1.0.5, V1.0.6 e V1.0.7 com dados representativos. Migração executada duas vezes; campos e registros anteriores preservados, incluindo modelos, chaves cifradas, filas, histórico e marcos de início. Integridade SQLite conferida. |
| Busca única | Uma consulta de playlist e uma de detalhes para um vídeo novo alimentam ambas as filas. Na rodada seguinte o ID conhecido não volta a detalhes. Cadastro na segunda plataforma reutiliza metadados sem nova consulta ao YouTube. |
| Isolamento | Pausar/remover Discord mantém Telegram; pausar/remover Telegram mantém Discord. Cadastro somente no Telegram não aparece no editor Discord. Cota-base conta o canal uma vez. |
| Privado | Usuários diferentes, mensagens encaminhadas, chats de grupo e IDs incompatíveis não vinculam o destino. Somente a mensagem privada do ID cadastrado o confirma. Funciona sem grupo/canal Telegram. |
| Trocas de identidade | Trocar administrador ou bot invalida o vínculo anterior e cancela pendências afetadas. Antes de enviar, o destinatário e o bot são conferidos novamente. Uma resposta antiga de polling não vincula o administrador anterior. |
| Credenciais | Token cifrado e ausente nas respostas de configuração. Exceções de rede são convertidas em mensagens sem token ou URL. Leitura exige login; gravações exigem sessão e CSRF. |
| Permissões Telegram | Cadastro exige bot administrador; canais exigem permissão de publicar. Cadastro arbitrário de privado é recusado. Conflito de webhook é informado sem alterar outro serviço. |
| Mensagens | Textos independentes por destino, marcação HTML validada e dados do vídeo escapados. Gravações inválidas não mudam a configuração; edição desatualizada retorna conflito. |
| Pausa e retomada | Novo destino e retomada estabelecem o início das publicações elegíveis, sem recuperar conteúdo anterior. |
| Fila Telegram | Sucesso confirma o ID da mensagem; limite temporário espera para repetir. Timeout após envio deixa resultado incerto, sem repetição automática. Reenvio incerto exige confirmação. |
| Históricos | Limpezas separadas mantêm itens em andamento e controle de duplicações. Limpar logs do sistema não remove logs próprios do Telegram. |
| Discord existente | Testes anteriores mantidos: OAuth, permissões, destinos independentes, prévias/embeds, cópias, menções bloqueadas em testes, deduplicação e troca de APIs. |
| Backup | Cópia consistente e íntegra, recusa de substituir backup existente e de criar cópia vazia sem banco de origem. |

## Interface

Chromium com dados demonstrativos e transporte Telegram simulado:

- 14 telas percorridas no computador, em claro e escuro.
- Larguras de 1440, 768 e 390 pixels; telas novas, navegação móvel e editor sem transbordamento horizontal.
- Campos ID do administrador, usuário e token disponíveis; token salvo não aparece no formulário.
- Salvamento da configuração passa pelos handlers reais, com a resposta externa do Telegram simulada.
- Textos diferentes para três destinos salvos, reabertos e conferidos.
- Editor de modelos e aplicação de cópias, reutilização de canal global, privado, fila de testes e limpeza do histórico exercitados.
- Preferência de tema preservada depois de recarregar.
- Nenhum erro JavaScript nos fluxos exercitados e nenhuma requisição externa pelo navegador.
- Cabeçalho e botão de salvar do editor Telegram permanecem disponíveis durante a rolagem.

A sintaxe dos módulos Python, dos scripts JavaScript e dos oito blocos Bash do guia foi conferida. O ZIP foi verificado quanto à integridade e ao diretório raiz `V1.0.8/`. Ícone e favicon mantêm os mesmos bytes da V1.0.7.

## Alcance

As verificações usam bases de teste e APIs simuladas. Não foi acessada ou alterada a VPS do usuário, não foi usado o banco real e não foram enviados avisos reais ao Discord ou Telegram. A imagem Docker não foi construída neste ambiente; o guia a constrói antes de interromper os serviços atuais.

Após instalar, configure o Telegram no painel e faça um teste no destino real para conferir token e permissões. Use o mesmo `.env`, `APP_SECRET` e pasta `data`, seguindo [ATUALIZAR_SEM_PERDER_DADOS.md](ATUALIZAR_SEM_PERDER_DADOS.md).
