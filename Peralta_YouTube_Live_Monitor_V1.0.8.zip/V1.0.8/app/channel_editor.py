"""Channel editor endpoints. Saves are atomic and scoped to one channel."""
import json
import math
import time
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request

from . import db, routing


def boolean(data, key, default=False):
    value = data.get(key, default)
    if not isinstance(value, (bool, int)) or value not in (0, 1):
        raise HTTPException(400, f"Valor inválido: {key}")
    return int(value)


def template_fields(data):
    if not isinstance(data, dict):
        raise HTTPException(400, "Modelo inválido")
    limits = {"name": 80, "content": 1900, "embed_title": 240,
              "embed_description": 3800, "embed_footer": 200, "embed_image": 500}
    values = {k: str(data.get(k, "")) for k in limits}
    values["name"] = values["name"].strip()
    if not values["name"] or not values["content"].strip():
        raise HTTPException(400, "Informe nome e mensagem do modelo")
    for key, limit in limits.items():
        if len(values[key]) > limit:
            raise HTTPException(400, f"{key}: máximo de {limit} caracteres")
    if values["embed_image"] and not values["embed_image"].startswith("https://"):
        raise HTTPException(400, "A imagem do embed deve usar HTTPS")
    try:
        values["embed_color"] = int(data.get("embed_color", 15086414))
    except (TypeError, ValueError):
        raise HTTPException(400, "Cor do embed inválida")
    values["preview_mode"] = data.get("preview_mode", "youtube")
    if not 0 <= values["embed_color"] <= 0xFFFFFF or values["preview_mode"] not in ("youtube", "custom"):
        raise HTTPException(400, "Cor ou tipo de prévia inválido")
    return values


def valid_template(con, value):
    if value is None or value == "":
        return None
    try:
        tid = int(value)
    except (TypeError, ValueError):
        raise HTTPException(400, "Modelo inválido")
    if not con.execute("SELECT 1 FROM templates WHERE id=?", (tid,)).fetchone():
        raise HTTPException(400, "Modelo não encontrado")
    return tid


def save_copy(con, channel, template, destination=None, previous_template_id=None):
    """Only update an owned copy when no other channel/server uses it."""
    original_id = previous_template_id if destination else channel["template_id"]
    existing = con.execute("SELECT id FROM templates WHERE id=? AND owner_channel_id=?",
                           (original_id, channel["channel_id"])).fetchone()
    tid = existing["id"] if existing else None
    if destination:
        used_by_channels = con.execute("SELECT 1 FROM youtube_channels WHERE template_id=?", (tid,)).fetchone()
        used_by_routes = con.execute("SELECT 1 FROM channel_destinations WHERE template_id=? AND NOT "
                                    "(youtube_channel_id=? AND guild_id=? AND channel_id=?)",
                                    (tid, channel["channel_id"], *destination)).fetchone()
    else:
        used_by_channels = con.execute("SELECT 1 FROM youtube_channels WHERE template_id=? AND channel_id<>?",
                                       (tid, channel["channel_id"])).fetchone()
        used_by_routes = con.execute("SELECT 1 FROM channel_destinations WHERE template_id=?", (tid,)).fetchone()
    shared = tid and (used_by_channels or used_by_routes or
                      con.execute("SELECT 1 FROM guilds WHERE template_id=?", (tid,)).fetchone())
    columns = list(template)
    values = [template[k] for k in columns]
    if tid and not shared:
        con.execute("UPDATE templates SET " + ",".join(f"{k}=?" for k in columns) + " WHERE id=?", (*values, tid))
        return tid
    cursor = con.execute("INSERT INTO templates(" + ",".join(columns) + ",owner_channel_id) VALUES(" +
                         ",".join("?" for _ in values) + ",?)", (*values, channel["channel_id"]))
    return cursor.lastrowid


def save_configuration(channel_id, data):
    with db.transaction() as con:
        old = routing.configuration(channel_id, con)
        if old is None:
            raise HTTPException(404, "Canal não encontrado")
        if data.get("revision") != old["revision"]:
            raise HTTPException(409, "Este canal mudou desde que você abriu a edição. Reabra para carregar os dados atuais.")
        channel = old["channel"]
        old_routes = {(r["guild_id"], r["channel_id"]): r for r in old["destinations"]}
        raw_routes = data.get("destinations")
        if not isinstance(raw_routes, list) or len(raw_routes) > 100:
            raise HTTPException(400, "Informe até 100 destinos por canal")
        active = boolean(data, "active", channel["active"])
        prepared = []
        seen = set()
        for item in raw_routes:
            if not isinstance(item, dict):
                raise HTTPException(400, "Destino inválido")
            pair = (str(item.get("guild_id", "")), str(item.get("channel_id", "")))
            if pair in seen:
                raise HTTPException(400, "Destino repetido")
            seen.add(pair)
            previous = old_routes.get(pair)
            guild = con.execute("SELECT * FROM guilds WHERE guild_id=?", (pair[0],)).fetchone()
            dest = con.execute("SELECT * FROM discord_channels WHERE guild_id=? AND channel_id=?", pair).fetchone()
            enabled = boolean(item, "active", True)
            mention = boolean(item, "mention_everyone")
            # Keep existing broken destinations visible/editable. New or resumed
            # routes must be authorized and able to send before enabling them.
            enabling = enabled and (not previous or not previous["active"])
            if not guild or (not previous and (not guild["present"] or not guild["owner_verified"])):
                raise HTTPException(400, "Instale o bot pelo painel antes de escolher este servidor")
            if (not previous or enabling) and (not dest or not dest["can_view"] or not dest["can_send"]):
                raise HTTPException(400, "O bot precisa visualizar e enviar no destino selecionado")
            if enabling and (not guild["present"] or not guild["owner_verified"]):
                raise HTTPException(400, "O servidor precisa estar presente e autorizado")
            if mention and (not previous or not previous["mention_everyone"]) and (not dest or not dest["can_mention"]):
                raise HTTPException(400, "Destino sem permissão para @everyone")
            after = previous["notify_after"] if previous else time.time()
            if enabling or (active and not channel["active"]):
                after = time.time()
            copy = template_fields(item["template"]) if item.get("template_mode") == "copy" else None
            prepared.append({"guild_id": pair[0], "channel_id": pair[1], "active": enabled,
                             "template_id": valid_template(con, item.get("template_id")),
                             "copy": copy,
                             "notify_uploads": boolean(item, "notify_uploads", True),
                             "notify_scheduled": boolean(item, "notify_scheduled", True),
                             "mention_everyone": mention, "notify_after": after})
        mode = data.get("template_mode", "inherit")
        if mode == "copy":
            main_template = save_copy(con, channel, template_fields(data.get("template")))
        elif mode == "existing":
            main_template = valid_template(con, data.get("template_id"))
            if main_template is None:
                raise HTTPException(400, "Selecione o modelo do canal")
        elif mode == "inherit":
            main_template = None
        else:
            raise HTTPException(400, "Modo de mensagem inválido")
        # Copy per destination before replacing the route rows, so ownership and
        # shared references can be checked against the original configuration.
        for item in prepared:
            if item["copy"]:
                pair = (item["guild_id"], item["channel_id"])
                previous = old_routes.get(pair)
                item["template_id"] = save_copy(con, channel, item["copy"], pair,
                                                 previous["template_id"] if previous else None)
        # No shared model or other channel is changed by this transaction.
        con.execute("DELETE FROM channel_destinations WHERE youtube_channel_id=?", (channel_id,))
        for item in prepared:
            con.execute("INSERT INTO subscriptions(guild_id,channel_id,active,notify_after) VALUES(?,?,1,?) "
                        "ON CONFLICT(guild_id,channel_id) DO UPDATE SET active=1",
                        (item["guild_id"], channel_id, item["notify_after"]))
            con.execute("INSERT INTO channel_destinations(youtube_channel_id,guild_id,channel_id,active,"
                        "template_id,notify_uploads,notify_scheduled,mention_everyone,notify_after,created_at) "
                        "VALUES(?,?,?,?,?,?,?,?,?,?)", (channel_id, item["guild_id"], item["channel_id"], item["active"],
                        item["template_id"], item["notify_uploads"], item["notify_scheduled"], item["mention_everyone"],
                        item["notify_after"], db.ts()))
        con.execute("UPDATE youtube_channels SET discord_active=?,template_id=?,routing_custom=1,"
                    "config_revision=config_revision+1 WHERE channel_id=?", (active, main_template, channel_id))
        from .telegram_store import refresh_monitoring
        refresh_monitoring(con, channel_id)
        selected_active = {(r["guild_id"], r["channel_id"]) for r in prepared if r["active"] and active}
        pending = con.execute("SELECT d.id,d.guild_id,d.channel_id FROM deliveries d JOIN videos v "
                              "ON v.video_id=d.video_id WHERE v.channel_id=? AND d.status='pending'", (channel_id,)).fetchall()
        for item in pending:
            if (item["guild_id"], item["channel_id"]) not in selected_active:
                con.execute("UPDATE deliveries SET status='skipped',error='Destino pausado ou removido na edição do canal',"
                            "updated_at=? WHERE id=?", (db.ts(), item["id"]))
        result = routing.configuration(channel_id, con)
    db.log("admin", "info", f"Avisos de {channel_id} salvos: {len(prepared)} destino(s)")
    return result


def preview_message(channel_id, data, con):
    from .bot import render
    channel = con.execute("SELECT * FROM youtube_channels WHERE channel_id=? AND removed=0", (channel_id,)).fetchone()
    if not channel:
        raise HTTPException(404, "Canal não encontrado")
    gid, did = str(data.get("guild_id", "")), str(data.get("channel_id", ""))
    guild = con.execute("SELECT * FROM guilds WHERE guild_id=?", (gid,)).fetchone()
    mode = data.get("template_mode", "inherit")
    override = valid_template(con, data.get("destination_template_id"))
    if data.get("destination_template_mode") == "copy":
        template = template_fields(data.get("destination_template"))
    elif override:
        template = dict(con.execute("SELECT * FROM templates WHERE id=?", (override,)).fetchone())
    elif mode == "copy":
        template = template_fields(data.get("template"))
    else:
        tid = valid_template(con, data.get("template_id")) if mode == "existing" else None
        tid = tid or (guild["template_id"] if guild else 1)
        template = dict(con.execute("SELECT * FROM templates WHERE id=?", (tid,)).fetchone())
    example = {"video_id": "exemplo", "channel_name": channel["name"], "video_kind": "scheduled",
               "title": "Próxima live do canal", "url": "https://www.youtube.com/channel/" + channel_id,
               "thumbnail": "", "scheduled_at": (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()}
    video = con.execute("SELECT * FROM videos WHERE channel_id=? ORDER BY first_seen DESC LIMIT 1", (channel_id,)).fetchone()
    if video:
        example.update(dict(video))
        example["video_kind"] = video["kind"]
    content, embed = render(template, example, {"mention_everyone": boolean(data, "mention_everyone")},
                            db.setting("timezone", "America/Sao_Paulo"))
    return {"content": content, "embed": embed.to_dict() if embed else None,
            "preview_mode": template["preview_mode"], "sample": not bool(video),
            "guild_id": gid, "channel_id": did}


def build_router(auth, body):
    router = APIRouter()

    @router.get("/api/channel-editor")
    def channel_list(current=Depends(auth)):
        return routing.channel_summaries()

    @router.get("/api/youtube-channels/{channel_id}/configuration")
    def get_configuration(channel_id: str, current=Depends(auth)):
        result = routing.configuration(channel_id)
        if not result:
            raise HTTPException(404, "Canal não encontrado")
        return result

    @router.put("/api/youtube-channels/{channel_id}/configuration")
    async def put_configuration(channel_id: str, request: Request, current=Depends(auth)):
        return save_configuration(channel_id, await body(request))

    @router.post("/api/youtube-channels/{channel_id}/preview")
    async def preview(channel_id: str, request: Request, current=Depends(auth)):
        data = await body(request)
        with db.transaction() as con:
            return preview_message(channel_id, data, con)

    @router.post("/api/youtube-channels/{channel_id}/test")
    async def test(channel_id: str, request: Request, current=Depends(auth)):
        data = await body(request)
        # Both literal mentions and variables are suppressed for tests.
        data["mention_everyone"] = False
        with db.transaction() as con:
            payload = preview_message(channel_id, data, con)
            destination = con.execute("SELECT c.* FROM discord_channels c JOIN guilds g ON g.guild_id=c.guild_id "
                                      "WHERE c.guild_id=? AND c.channel_id=? AND g.present=1 AND g.owner_verified=1",
                                      (payload["guild_id"], payload["channel_id"])).fetchone()
            if not destination or not destination["can_view"] or not destination["can_send"]:
                raise HTTPException(400, "Servidor não autorizado ou destino sem permissão de envio")
            recent = con.execute("SELECT 1 FROM test_requests WHERE guild_id=? AND channel_id=? AND created_at>?",
                                 (payload["guild_id"], payload["channel_id"], db.ts() - 5)).fetchone()
            if recent:
                raise HTTPException(429, "Aguarde 5 segundos antes de testar este destino novamente")
            payload["content"] = payload["content"].replace("@everyone", "").replace("@here", "")
            cursor = con.execute("INSERT INTO test_requests(guild_id,channel_id,payload,youtube_channel_id,"
                                 "created_at,updated_at) VALUES(?,?,?,?,?,?)",
                                 (payload["guild_id"], payload["channel_id"], json.dumps(payload), channel_id, db.ts(), db.ts()))
            return {"id": cursor.lastrowid, "status": "pending"}

    @router.get("/api/quota-preview")
    def quota_preview(interval: int = 300, current=Depends(auth)):
        if not 30 <= interval <= 86400:
            raise HTTPException(400, "Intervalo deve ficar entre 30 e 86400 segundos")
        count = db.one("SELECT COUNT(*) AS n FROM youtube_channels WHERE active=1 AND removed=0")["n"]
        base = math.ceil(86400 / interval * count)
        return {"channels": count, "interval": interval, "playlist_units_per_day": base,
                "playlist_units_five_pages": base * 5,
                "note": "Estimativa com uma página por busca. Páginas extras, detalhes de novos IDs, cadastros, testes de chave e tentativas consomem mais. Chaves do mesmo projeto compartilham a cota."}

    return router
