"""Effective destinations, including unedited V1.0.5 associations.

Reading never migrates or writes a channel. A saved channel gets its own
destination list while all other channels keep their existing behavior.
"""
import hashlib
import json
from contextlib import closing

from . import db


def routes(con, channel_id):
    channel = con.execute("SELECT routing_custom FROM youtube_channels WHERE channel_id=?", (channel_id,)).fetchone()
    if not channel:
        return []
    # Custom destinations must not be inserted into guild_destinations: doing
    # so would subscribe every legacy channel on that server to the new target.
    destination_join = ("JOIN channel_destinations d ON d.guild_id=g.guild_id AND d.youtube_channel_id=s.channel_id "
                        if channel["routing_custom"] else "JOIN guild_destinations d ON d.guild_id=g.guild_id ")
    result = con.execute(
        "SELECT s.guild_id,d.channel_id,g.name AS guild_name,"
        "COALESCE(c.name,d.channel_id) AS destination_name,"
        "g.active AS guild_active,g.present,g.owner_verified,"
        "c.can_view,c.can_send,c.can_embed,c.can_mention,"
        "s.active AS subscription_active,COALESCE(r.active,1) AS route_active,"
        "r.template_id,COALESCE(r.template_id,y.template_id,g.template_id) AS effective_template_id,"
        "COALESCE(r.notify_uploads,g.notify_uploads) AS notify_uploads,"
        "COALESCE(r.notify_scheduled,g.notify_scheduled) AS notify_scheduled,"
        "COALESCE(r.mention_everyone,g.mention_everyone) AS mention_everyone,"
        "MAX(COALESCE(r.notify_after,0),s.notify_after) AS notify_after "
        "FROM subscriptions s JOIN youtube_channels y ON y.channel_id=s.channel_id "
        "JOIN guilds g ON g.guild_id=s.guild_id "
        + destination_join +
        "LEFT JOIN discord_channels c ON c.guild_id=d.guild_id AND c.channel_id=d.channel_id "
        "LEFT JOIN channel_destinations r ON r.youtube_channel_id=s.channel_id "
        "AND r.guild_id=d.guild_id AND r.channel_id=d.channel_id "
        "WHERE s.channel_id=? "
        "ORDER BY g.name,d.created_at,d.channel_id", (channel_id,)).fetchall()
    items = [dict(r) for r in result]
    for item in items:
        item["active"] = int(bool(item["route_active"] and item["subscription_active"]))
    return items


def delivery_targets(con, channel_id):
    state = con.execute("SELECT discord_enabled,discord_active,removed FROM youtube_channels WHERE channel_id=?", (channel_id,)).fetchone()
    if not state or not state['discord_enabled'] or not state['discord_active'] or state['removed']:
        return []
    return [r for r in routes(con, channel_id)
            if r["active"] and r["guild_active"] and r["present"] and r["owner_verified"]]


def revision(channel, destinations):
    # Exclude activity and heartbeat data: a poll cannot invalidate an edit.
    data = {"active": channel["active"], "template_id": channel["template_id"],
            "routing_custom": channel["routing_custom"], "revision": channel["config_revision"],
            "routes": [{k: r[k] for k in ("guild_id", "channel_id", "active", "template_id",
                        "effective_template_id", "notify_uploads", "notify_scheduled", "mention_everyone",
                        "notify_after", "guild_active", "present", "owner_verified")}
                       for r in destinations]}
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def configuration(channel_id, con=None):
    if con is None:
        with closing(db.connect()) as connection:
            return configuration(channel_id, connection)
    channel = con.execute("SELECT * FROM youtube_channels WHERE channel_id=? AND removed=0 AND discord_enabled=1",
                          (channel_id,)).fetchone()
    if not channel:
        return None
    channel = dict(channel)
    channel['active'] = channel['discord_active']
    destinations = routes(con, channel_id)
    return {"channel": channel, "destinations": destinations,
            "revision": revision(channel, destinations)}


def channel_summaries():
    with closing(db.connect()) as con:
        channels = [dict(r) for r in con.execute("SELECT * FROM youtube_channels WHERE removed=0 AND discord_enabled=1 ORDER BY name")]
        for channel in channels:
            channel['active'] = channel['discord_active']
            channel["destinations"] = routes(con, channel["channel_id"])
            last = con.execute("SELECT d.*,g.name AS guild_name,COALESCE(c.name,d.channel_id) AS destination_name "
                               "FROM deliveries d JOIN videos v ON v.video_id=d.video_id "
                               "JOIN guilds g ON g.guild_id=d.guild_id "
                               "LEFT JOIN discord_channels c ON c.channel_id=d.channel_id "
                               "WHERE v.channel_id=? ORDER BY d.id DESC LIMIT 1", (channel["channel_id"],)).fetchone()
            channel["last_delivery"] = dict(last) if last else None
    return channels
