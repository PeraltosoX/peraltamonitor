"use strict";

const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const state = {busy:false, activity:null, csrf:"", view:"dashboard", guilds:[], channels:[], templates:[], apiKeys:[]};
const date = (stamp) => stamp ? new Date(stamp * 1000).toLocaleString("pt-BR") : "—";

const mobileNavigation = window.matchMedia("(max-width: 920px)");
function setNavigation(open, focus=true) {
  const mobile = mobileNavigation.matches;
  const visible = Boolean(open && mobile);
  $("#sidebar").classList.toggle("open", visible);
  $("#sidebar").inert = mobile && !visible;
  $(".workspace").inert = visible;
  $("#nav-backdrop").classList.toggle("hidden", !visible);
  $("#menu-toggle").setAttribute("aria-expanded", String(visible));
  document.body.classList.toggle("nav-open", visible);
  if (focus) (visible ? $("#nav button.active") : $("#menu-toggle")).focus();
}
$("#menu-toggle").addEventListener("click", () => setNavigation(true));
$("#close-nav").addEventListener("click", () => setNavigation(false));
$("#nav-backdrop").addEventListener("click", () => setNavigation(false));
mobileNavigation.addEventListener("change", () => setNavigation(false, false));
document.addEventListener("keydown", event => {
  if (!document.body.classList.contains("nav-open")) return;
  if (event.key === "Escape") { event.preventDefault(); setNavigation(false); }
  if (event.key === "Tab") {
    const items = [...$("#sidebar").querySelectorAll("a,button")];
    const first = items[0], last = items.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
setNavigation(false, false);

function toast(message, error=false) {
  const node = $("#toast"); node.textContent = message; node.className = `toast${error ? " error-toast" : ""}`;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.add("hidden"), 5300);
}
async function api(path, method="GET", data) {
  const options = {method, credentials:"same-origin", headers:{}};
  if (method !== "GET") options.headers["X-CSRF-Token"] = state.csrf;
  if (data !== undefined) {options.headers["Content-Type"] = "application/json"; options.body = JSON.stringify(data);}
  const response = await fetch(path, options);
  let result = null;
  try {result = await response.json();} catch (_) {throw Error(`Resposta inesperada: HTTP ${response.status}`);}
  if (!response.ok) {
    if (response.status === 401) showLogin();
    throw Error(typeof result.detail === "string" ? result.detail : `HTTP ${response.status}`);
  }
  return result;
}
function showLogin() {setNavigation(false,false);document.querySelectorAll("dialog[open]").forEach(d=>d.close());document.body.classList.remove("no-scroll");$("#login").classList.remove("hidden"); $("#app").classList.add("hidden");}
function showApp(session) {
  state.csrf = session.csrf; $("#user-name").textContent = session.username;
  $("#side-version").textContent = `V${session.version}`;
  $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");
  if (new URL(location.href).searchParams.has("installed")) {
    history.replaceState({}, "", "/"); toast("Instalação autorizada. Configure e ative o servidor abaixo."); navigate("discord");
  } else navigate(location.hash.slice(1) || "dashboard");
}
function navigate(view) {
  if(!["dashboard","discord","youtube","templates","apis","activity","settings","global","tg-config","tg-destinations","tg-private","tg-channels","tg-messages","tg-activity"].includes(view))view="dashboard";
  state.view = view; history.replaceState({}, "", `#${view}`);
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el.id === view));
  document.querySelectorAll("#nav button").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  const names = {...TelegramUI.names,dashboard:"Visão geral",discord:"Servidores Discord",youtube:"Canais e avisos",templates:"Modelos de mensagem",apis:"APIs do YouTube",activity:"Entregas e logs",settings:"Configurações"};
  const descriptions = {...TelegramUI.descriptions,dashboard:"Uma busca do YouTube, avisos para suas comunidades.",discord:"Conexões, autorização e padrões de cada servidor.",youtube:"Mensagens e estilos independentes para cada destino.",templates:"Crie e reutilize mensagens para suas comunidades.",apis:"Controle suas chaves e acompanhe o consumo.",activity:"Consulte entregas, testes e registros do monitor.",settings:"Frequência de busca, fuso horário e estimativa de consumo."};
  $("#page-name").textContent = names[view];
  $("#page-description").textContent = descriptions[view];
  window.scrollTo(0,0);
  if(document.body.classList.contains("nav-open")){setNavigation(false,false);$("#main").focus({preventScroll:true});}
  document.querySelectorAll("#nav button").forEach(el=>el.setAttribute("aria-current",el.dataset.view===view ? "page" : "false"));
  refresh();
}
async function refresh() {
  if(state.busy){state.refreshQueued=true;return;}
  state.busy=true;
  $("#sync-state").textContent="Sincronizando…";
  try {
    if (state.view === "dashboard") renderDashboard(await api("/api/dashboard"));
    else if (state.view === "discord") await loadDiscord();
    else if (state.view === "youtube") await loadYouTube();
    else if (state.view === "templates") await loadTemplates();
    else if (state.view === "apis") await loadApiKeys();
    else if (state.view === "activity") renderActivity(await api("/api/activity"));
    else if (state.view === "settings") {renderSettings(await api("/api/settings"));await updateQuotaPreview();}
    else if (state.view === "global" || state.view.startsWith("tg-")) await TelegramUI.load(state.view);
    $("#sync-state").textContent=`Atualizado às ${new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}`;
  } catch (error) {$("#sync-state").textContent="Falha ao atualizar";toast(error.message, true);}
  finally {state.busy=false;if(state.refreshQueued){state.refreshQueued=false;refresh();}}
}

function renderDashboard(data) {
  state.dashboard = data;
  state.dashboardFetchedAt = Date.now();
  const stats = [["Servidores ativos",data.authorized_guilds],["Canais YouTube",data.youtube_channels],["Destinos Telegram",data.telegram_destinations],["Avisos enviados",data.deliveries+data.telegram_deliveries]];
  $("#stats").innerHTML = stats.map(([label,value]) => `<div class="stat"><strong>${value}</strong><span>${label}</span></div>`).join("");
  $("#services").innerHTML = ["web","worker","bot",...(data.telegram_enabled?["telegram"]:[])].map(name => {
    const item = data.heartbeats.find(h => h.service === name);
    const online = item && Date.now()/1000 - item.at < 90;
    return `<div class="row log"><span class="pill ${online ? "good" : "bad"}">${online ? "Ativo" : "Sem sinal"}</span><strong>${({web:"Painel",worker:"Busca YouTube",bot:"Discord",telegram:"Telegram"})[name]}</strong><small>${escapeHTML(item?.detail || "Ainda não iniciou")}</small></div>`;
  }).join("") + `<p class="muted">Chamadas estimadas hoje: ${data.quota_estimate}. Pendências: ${data.pending+data.telegram_pending}. Intervalo da playlist: ${data.interval}s.</p>`;
  $("#recent").innerHTML = data.recent.length ? data.recent.map(l => `<div class="log"><small>${date(l.at)} · ${escapeHTML(l.service)}</small>${escapeHTML(l.message)}</div>`).join("") : `<div class="empty">Nenhuma atividade ainda.</div>`;
  renderCountdown();
}
function renderCountdown() {
  const data = state.dashboard;
  if (!data || state.view !== "dashboard") return;
  const now = data.server_time + (Date.now() - state.dashboardFetchedAt)/1000;
  const worker = data.heartbeats.find(h => h.service === "worker");
  const running = worker && now - worker.at < 90;
  const active = data.channels.filter(c => c.active);
  const due = c => c.last_poll ? c.last_poll + data.interval : now;
  const format = seconds => {
    const left = Math.max(0,Math.ceil(seconds));
    const hh = Math.floor(left/3600), mm = Math.floor(left%3600/60), ss = left%60;
    return `${hh ? `${String(hh).padStart(2,"0")}:` : ""}${String(mm).padStart(2,"0")}:${String(ss).padStart(2,"0")}`;
  };
  if (!active.length) {$("#next-progress").value=0;$("#next-check").textContent = "Em espera";$("#next-check-detail").textContent = "Ative ou cadastre um canal YouTube.";$("#channel-schedule").innerHTML = `<div class="empty"><strong>Nenhum canal ativo.</strong>Adicione ou ative um canal em Canais e avisos.</div>`;return;}
  const next = [...active].sort((a,b)=>due(a)-due(b))[0];
  $("#next-check").textContent = !running ? "Sem sinal" : due(next)<=now ? "Na fila" : format(due(next)-now);
  $("#next-check-detail").textContent = `Próximo canal: ${next.name}. Tempo estimado até a próxima verificação.`;
  $("#next-progress").max=data.interval;
  $("#next-progress").value=running?Math.min(data.interval,Math.max(0,data.interval-(due(next)-now))):0;
  $("#channel-schedule").innerHTML = data.channels.map(c => `<div class="schedule-row"><span><strong>${escapeHTML(c.name)}</strong><small>Última: ${date(c.last_poll)} · Novos IDs: ${c.last_new_count}${c.last_error ? ` · Erro: ${escapeHTML(c.last_error)}` : ""}</small></span><span class="pill ${c.active && !c.last_error ? "good" : c.active ? "bad" : "warn"}">${c.active ? !running ? "Aguardando worker" : due(c)<=now ? "Pendente" : format(due(c)-now) : "Pausado"}</span></div>`).join("");
}
setInterval(renderCountdown, 1000);
setInterval(() => {if(["dashboard","youtube","activity","global","tg-private","tg-activity","tg-channels"].includes(state.view) && !$("#app").classList.contains("hidden") && !document.querySelector("dialog[open],.more-actions[open]")) refresh();}, 10000);
async function loadDiscord() {
  const [info, guilds, templates] = await Promise.all([api("/api/discord"),api("/api/guilds"),api("/api/templates")]);
  state.guilds = guilds; state.templates = templates;
  $("#discord-summary").textContent = `Application ID: ${info.application_id} · Seu Discord User ID: ${info.owner_user_id} · Token: ${info.token_configured ? "configurado" : "ausente"}`;
  $("#guild-list").innerHTML = guilds.length ? guilds.map(g => {
    const options = g.channels.filter(c => !g.destinations.some(d => d.channel_id === c.channel_id)).map(c => `<option value="${escapeHTML(c.channel_id)}">#${escapeHTML(c.name)} ${!c.can_send ? "(sem envio)" : !c.can_embed ? "(sem prévia)" : ""}</option>`).join("");
    const targets = g.destinations.map(d => `<div class="schedule-row" data-dest="${escapeHTML(d.channel_id)}"><span><strong>#${escapeHTML(d.name)}</strong><small>${d.can_send ? "Envio disponível" : "Sem permissão ou canal removido"}</small></span><span class="actions"><button class="outline small" data-dest-test>Testar</button><button class="danger small" data-dest-remove>Remover</button></span></div>`).join("") || `<p class="muted">Nenhum canal de avisos escolhido.</p>`;
    const templateOptions = templates.map(t => `<option value="${t.id}" ${g.template_id === t.id ? "selected" : ""}>${escapeHTML(t.name)}</option>`).join("");
    return `<article class="item" data-guild="${escapeHTML(g.guild_id)}"><div class="item-head"><div><h2>${escapeHTML(g.name)}</h2><small class="mono">${escapeHTML(g.guild_id)}</small></div><span class="pill ${g.active && g.present ? "good" : g.owner_verified ? "warn" : "bad"}">${g.active && g.present ? "Autorizado" : g.owner_verified ? "Aguardando ativação" : "Bloqueado"}</span></div><p>${g.present ? "Bot presente" : "Bot ausente"} · ${g.owner_verified ? "ID do proprietário verificado" : "Instalação não verificada no painel"}</p><h3>Destinos padrão do servidor</h3><p class="field-hint">Padrões preservados dos canais já cadastrados. Configure mensagens e destinos individuais em Canais e avisos. Destinos individuais cadastrados: ${g.custom_destination_count||0}.</p>${targets}<div class="inline-form destination-add"><label>Adicionar canal de avisos<select name="new-target">${options || '<option value="">Sem outros canais disponíveis</option>'}</select></label><button class="outline" data-dest-add ${options ? "" : "disabled"}>Adicionar canal</button></div><div class="grid-form"><label>Modelo padrão do servidor<select name="template">${templateOptions}</select></label><label class="check"><input type="checkbox" name="active" ${g.active ? "checked" : ""} ${!g.owner_verified || !g.present || (!g.destinations.length && !g.custom_destination_count) ? "disabled" : ""}> Servidor ativo</label><label class="check"><input type="checkbox" name="uploads" ${g.notify_uploads ? "checked" : ""}> Avisar vídeos e Shorts</label><label class="check"><input type="checkbox" name="scheduled" ${g.notify_scheduled ? "checked" : ""}> Avisar lives agendadas / ao vivo</label><label class="check"><input type="checkbox" name="everyone" ${g.mention_everyone ? "checked" : ""}> Permitir @everyone</label></div><div class="actions"><button class="primary" data-guild-save>Salvar servidor</button></div></article>`;
  }).join("") : `<div class="empty card">Nenhum servidor conectado. Use “Adicionar ao servidor” acima.</div>`;
}
async function loadYouTube() {
  state.channels = await api("/api/channel-editor");
  renderChannels();
}
const statusNames={sent:"Enviado",pending:"Na fila",sending:"Enviando",failed:"Falhou",uncertain:"Conferir envio",skipped:"Ignorado"};
function statusPill(status) {return `<span class="pill ${status==="sent"?"good":["failed","uncertain"].includes(status)?"bad":status==="skipped"?"neutral":"warn"}">${escapeHTML(statusNames[status]||status)}</span>`;}
function renderChannels() {
  const query=$("#channel-search").value.toLocaleLowerCase("pt-BR").trim(),filter=$("#channel-filter").value;
  const channels=state.channels.filter(c=>(!query || `${c.name} ${c.channel_id}`.toLocaleLowerCase("pt-BR").includes(query)) &&
    (filter==="all"||filter==="active"&&c.active||filter==="paused"&&!c.active||filter==="attention"&&(c.last_error||!c.destinations.length||c.destinations.some(r=>!r.can_send||!r.guild_active)||["failed","uncertain"].includes(c.last_delivery?.status))));
  $("#channel-count").textContent=`${channels.length} / ${state.channels.length} canais`;
  $("#youtube-list").innerHTML=channels.length ? channels.map(c=>{
    const destinations=c.destinations||[],live=destinations.filter(r=>r.active&&r.guild_active&&r.present&&r.owner_verified).length;
    const servers=[...new Set(destinations.map(r=>r.guild_name))];
    const portrait=/^https:\/\/(yt3\.ggpht\.com|yt3\.googleusercontent\.com)\//.test(c.thumbnail)?`<img class="channel-avatar" src="${escapeHTML(c.thumbnail)}" alt="" loading="lazy">`:`<span class="channel-avatar" aria-hidden="true">${escapeHTML(c.name.slice(0,2).toLocaleUpperCase("pt-BR"))}</span>`;
    return `<article class="channel-row" data-youtube="${escapeHTML(c.channel_id)}"><div class="channel-identity">${portrait}<div><strong class="channel-name">${escapeHTML(c.name)}</strong><small>${escapeHTML(c.channel_id)}</small></div></div><div class="channel-destinations"><strong>${destinations.length} destino${destinations.length===1?"":"s"} · ${servers.length} servidor${servers.length===1?"":"es"}</strong><span>${escapeHTML(servers.slice(0,2).join(" / "))}${servers.length>2?` +${servers.length-2}`:""}</span><small>${destinations.length?`${live} habilitado(s) para envio`:"Escolha os destinos em Editar avisos"}</small></div><div class="channel-status"><span class="pill ${!c.active?"neutral":c.last_error?"bad":"good"}">${!c.active?"Pausado":c.last_error?"Atenção":"Monitorando"}</span><small>${c.last_error?escapeHTML(c.last_error):`Última busca: ${date(c.last_poll)}`}</small>${c.last_delivery?`<small>Último aviso: ${escapeHTML(statusNames[c.last_delivery.status]||c.last_delivery.status)}</small>`:""}</div><div class="channel-actions"><button class="primary small" data-youtube-edit>Editar avisos ↗</button><details class="more-actions"><summary aria-label="Mais ações para ${escapeHTML(c.name)}">···</summary><div><button data-youtube-toggle>${c.active?"Pausar canal":"Retomar canal"}</button><button data-youtube-check ${c.active?"":"disabled"}>Verificar IDs agora</button><button class="danger" data-youtube-delete>Apagar canal</button></div></details></div></article>`;
  }).join("") : `<div class="empty"><strong>${state.channels.length?"Nenhum canal com esse filtro.":"Seu próximo aviso começa aqui."}</strong>${state.channels.length?"Tente outro nome ou filtro.":"Adicione um canal do YouTube para configurar suas mensagens e destinos."}</div>`;
}

function previewTemplate() {
  const values = {"{tipo}":"LIVE AGENDADA","{canal}":"Canal de exemplo","{titulo}":"Próxima live especial","{link}":"https://www.youtube.com/watch?v=exemplo","{live_id}":"exemplo12345","{data}":"25/09/2026 às 20:00","{hora}":"25/09/2026 às 20:00","{everyone}":"@everyone\n"};
  const substitute = text => Object.entries(values).reduce((s,[key,value]) => s.replaceAll(key,value),text || "");
  const content = substitute($("#template-content").value), title = substitute($("#template-title").value), description = substitute($("#template-description").value);
  const footer = substitute($("#template-footer").value), image = substitute($("#template-image").value);
  const youtube = $("#template-preview-mode").value === "youtube";
  const message = youtube && !content.split("\n").some(line => line.trim() === values["{link}"]) ? `${content}\n\n${values["{link}"]}` : content;
  $("#template-preview").innerHTML = youtube ? `${escapeHTML(message)}<p class="muted">▶ Prévia grande do YouTube aparece no Discord ao enviar.</p>` : `${escapeHTML(content)}${title ? `<h3>${escapeHTML(title)}</h3>` : ""}${description ? `<div>${escapeHTML(description)}</div>` : ""}${footer ? `<p class="muted">${escapeHTML(footer)}</p>` : ""}${image ? `<small>Imagem: ${escapeHTML(image)}</small>` : ""}`;
  $("#template-preview").style.borderLeftColor = $("#template-color").value;
  $("#template-lines").innerHTML = $("#template-content").value.split("\n").map((line,i) => `<div class="drag-line" draggable="true" data-line="${i}"><span aria-hidden="true">⠿</span><span>${escapeHTML(line || "(linha vazia)")}</span><button type="button" data-line-up aria-label="Mover linha para cima">↑</button><button type="button" data-line-down aria-label="Mover linha para baixo">↓</button></div>`).join("");
}
function selectTemplate() {
  const template = state.templates.find(t => String(t.id) === $("#template-select").value);
  if (!template) return;
  $("#template-name").value = template.name; $("#template-content").value = template.content;
  $("#template-preview-mode").value = template.preview_mode;
  $("#template-title").value = template.embed_title; $("#template-description").value = template.embed_description;
  $("#template-footer").value = template.embed_footer; $("#template-image").value = template.embed_image;
  $("#template-color").value = `#${template.embed_color.toString(16).padStart(6,"0")}`;
  previewTemplate();
}
async function loadTemplates(selected) {
  state.templates = await api("/api/templates");
  $("#template-select").innerHTML = state.templates.map(t => `<option value="${t.id}">${escapeHTML(t.name)}</option>`).join("");
  if (selected) $("#template-select").value = String(selected);
  selectTemplate();
}
async function loadApiKeys() {
  state.apiKeys = await api("/api/api-keys");
  $("#api-list").innerHTML = state.apiKeys.map(key => {
    const percent = Math.min(100, Math.round(key.calls / key.quota_limit * 100));
    const badge = key.current ? "Em uso" : key.retry_after > Date.now()/1000 ? "Em espera" : key.active ? "Próxima" : "Inativa";
    const summary = `<div class="item-head"><div><h2>${escapeHTML(key.name)}</h2><small>${escapeHTML(key.masked)} · ${key.project_id ? `Projeto ${escapeHTML(key.project_id)}` : "Projeto não informado"}</small></div><span class="pill ${key.current ? "good" : key.active ? "warn" : "bad"}">${badge}</span></div><p>Chamadas estimadas hoje: ${key.calls} / ${key.quota_limit} · Último uso: ${date(key.last_used)} ${key.last_error ? `· Erro: ${escapeHTML(key.last_error)}` : ""}${key.retry_after > Date.now()/1000 ? ` · Nova tentativa: ${date(key.retry_after)}` : ""}</p><progress max="100" value="${percent}" aria-label="Consumo estimado da cota">${percent}%</progress>`;
    if (key.id === 0) return `<article class="item">${summary}<p class="muted">Chave de reserva configurada no .env da VPS.</p><button class="outline small" data-api-test="0">Testar</button></article>`;
    return `<article class="item" data-api-id="${key.id}">${summary}<div class="grid-form"><label>Nome<input name="name" value="${escapeHTML(key.name)}" maxlength="80"></label><label>Projeto Google (identificador)<input name="project_id" value="${escapeHTML(key.project_id)}" maxlength="100"></label><label>Chave API (vazio mantém a atual)<input name="key" type="password" autocomplete="new-password" placeholder="${escapeHTML(key.masked)}"></label><label>Limite diário estimado<input name="quota_limit" type="number" min="100" value="${key.quota_limit}"></label><label>Ordem de reserva (menor primeiro)<input name="priority" type="number" min="1" value="${key.priority}"></label><label class="check"><input name="active" type="checkbox" ${key.active ? "checked" : ""}> Ativa</label></div><div class="actions"><button class="primary" data-api-save>Salvar</button><button class="outline" data-api-primary ${!key.configured ? "disabled" : ""}>Usar primeiro</button><button class="outline" data-api-test="${key.id}" ${!key.configured ? "disabled" : ""}>Testar</button><button class="danger" data-api-delete>Excluir</button></div></article>`;
  }).join("");
}
function renderActivity(data) {
  state.activity=data;renderDeliveries();
  $("#delivery-count").textContent=data.deliveries.length;
  $("#test-count").textContent=data.tests.length;
  $("#log-count").textContent=data.logs.length;
  $("#test-list").innerHTML=data.tests.length?data.tests.map(t=>`<div class="log"><small>${date(t.created_at)} · ${escapeHTML(t.guild_name||t.guild_id)} / #${escapeHTML(t.destination_name||t.channel_id)}</small>${statusPill(t.status)} ${escapeHTML(t.error||"")}</div>`).join(""):`<div class="empty">Nenhum teste enviado.</div>`;
  $("#log-list").innerHTML=data.logs.length?data.logs.map(l=>`<div class="log" data-level="${escapeHTML(l.level)}"><small>${date(l.at)} · ${escapeHTML(({info:"Informação",warning:"Atenção",error:"Erro"})[l.level]||l.level)} · ${escapeHTML(l.service)}</small>${escapeHTML(l.message)}</div>`).join(""):`<div class="empty">Sem registros no momento.</div>`;
}
function renderDeliveries() {
  if(!state.activity)return;
  const query=$("#delivery-search").value.toLocaleLowerCase("pt-BR"),filter=$("#delivery-filter").value;
  const deliveries=state.activity.deliveries.filter(d=>`${d.title} ${d.youtube_name} ${d.guild_name} ${d.destination_name}`.toLocaleLowerCase("pt-BR").includes(query)&&(filter==="all"||filter===d.status||filter==="pending"&&d.status==="sending"||filter==="attention"&&["failed","uncertain"].includes(d.status)));
  $("#delivery-list").innerHTML=deliveries.length?`<table><thead><tr><th>Publicação</th><th>Destino Discord</th><th>Resultado</th><th>Quando</th><th><span class="sr-only">Ação</span></th></tr></thead><tbody>${deliveries.map(d=>`<tr data-delivery="${d.id}"><td class="title"><strong>${escapeHTML(d.title)}</strong><small>${escapeHTML(d.youtube_name)}</small></td><td><strong>#${escapeHTML(d.destination_name)}</strong><small>${escapeHTML(d.guild_name)}</small></td><td>${statusPill(d.status)}<small>${escapeHTML(d.error||"")}</small></td><td>${date(d.created_at)}</td><td>${["failed","uncertain"].includes(d.status)?`<button class="outline small" data-retry>Reenviar</button>`:""}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Nenhuma entrega com esse filtro.</div>`;
}

function renderSettings(data) {
  $("#settings-form").elements.playlist_interval.value = data.playlist_interval;
  $("#settings-form").elements.timezone.value = data.timezone;
  state.settings=data;
  $("#settings-summary").innerHTML = `<p>Chave Google: <span class="pill ${data.google_key_configured ? "good" : "bad"}">${data.google_key_configured ? "configurada" : "ausente"}</span></p><p>Chamadas YouTube estimadas hoje: <strong>${data.quota_estimate}</strong></p><p>Detalhes consultados somente para IDs novos. A busca separada permanece desativada.</p>`;
}

$("#login-form").addEventListener("submit", async event => {
  event.preventDefault(); $("#login-error").textContent = "";
  const form = new FormData(event.currentTarget);
  try {
    const response = await fetch("/api/login", {method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:form.get("username"),password:form.get("password")})});
    const data = await response.json();
    if (!response.ok) throw Error(data.detail || "Falha no login");
    $("#login-form").reset(); showApp(await api("/api/session"));
  } catch (error) {$("#login-error").textContent = error.message;}
});
$("#logout").addEventListener("click", async () => {try {await api("/api/logout","POST"); showLogin();} catch (e) {toast(e.message,true);}});
$("#nav").addEventListener("click", e => {const button=e.target.closest("button[data-view]"); if(button) navigate(button.dataset.view);});
document.addEventListener("click", e => {if(e.target.closest("[data-refresh]")) refresh();const go=e.target.closest("[data-go]");if(go)navigate(go.dataset.go);});
window.addEventListener("hashchange",()=>navigate(location.hash.slice(1)));
$("#invite").addEventListener("click", async () => {try {const data=await api("/api/discord/install","POST"); location.href=data.url;} catch(e) {toast(e.message,true);}});
$("#guild-list").addEventListener("click", async e => {
  const item=e.target.closest("[data-guild]"); if(!item)return;
  const gid=item.dataset.guild, destination=e.target.closest("[data-dest]");
  try {
    if(e.target.closest("[data-dest-add]")) {
      const cid=item.querySelector('[name="new-target"]').value;
      if(!cid)return;
      await api(`/api/guilds/${encodeURIComponent(gid)}/destinations`,"POST",{channel_id:cid});
      toast("Canal de avisos adicionado");await loadDiscord();return;
    }
    if(destination) {
      const url=`/api/guilds/${encodeURIComponent(gid)}/destinations/${encodeURIComponent(destination.dataset.dest)}`;
      if(e.target.closest("[data-dest-test]")) {await api(`${url}/test`,"POST");toast("Teste enviado à fila deste canal");return;}
      if(e.target.closest("[data-dest-remove]")) {
        if(!confirm("Remover este canal de avisos? Avisos pendentes para ele serão cancelados."))return;
        await api(url,"DELETE");toast("Canal de avisos removido");await loadDiscord();return;
      }
    }
    if(e.target.closest("[data-guild-save]")) {
      const read=name=>item.querySelector(`[name="${name}"]`);
      await api(`/api/guilds/${encodeURIComponent(gid)}`,"PATCH",{template_id:Number(read("template").value),active:read("active").checked,notify_uploads:read("uploads").checked,notify_scheduled:read("scheduled").checked,mention_everyone:read("everyone").checked});
      toast("Servidor salvo");await loadDiscord();
    }
  }catch(error){toast(error.message,true);}
});
$("#channel-form").addEventListener("submit", async e => {
  e.preventDefault();const button=e.target.querySelector("button");button.disabled=true;$("#add-channel-error").textContent="";
  try {const info=await api("/api/youtube-channels","POST",{channel_id:e.target.elements.channel_id.value.trim()});e.target.reset();$("#add-channel-dialog").close();await loadYouTube();await openChannelEditor(info.channel_id);toast("Canal cadastrado. Escolha os destinos e a mensagem.");}
  catch(error){$("#add-channel-error").textContent=error.message;}
  finally{button.disabled=false;}
});
$("#open-add-channel").addEventListener("click",()=>{$("#add-channel-error").textContent="";$("#add-channel-dialog").showModal();});
$("[data-close-add]").addEventListener("click",()=>$("#add-channel-dialog").close());
$("#channel-search").addEventListener("input",renderChannels);$("#channel-filter").addEventListener("change",renderChannels);
$("#delivery-search").addEventListener("input",renderDeliveries);$("#delivery-filter").addEventListener("change",renderDeliveries);
$("#youtube-list").addEventListener("click", async e => {
  const item=e.target.closest("[data-youtube]"); if(!item)return;
  const channel=state.channels.find(c=>c.channel_id===item.dataset.youtube);
  try {
    const url=`/api/youtube-channels/${encodeURIComponent(channel.channel_id)}`;
    if(e.target.closest("[data-youtube-edit]")) {await openChannelEditor(channel.channel_id);}
    else if(e.target.closest("[data-youtube-toggle]")) {await api(url,"PATCH",{active:!channel.active});await loadYouTube();}
    else if(e.target.closest("[data-youtube-check]")) {
      const result=await api(`${url}/check`,"POST");
      toast(`${result.found} ID(s) na playlist, ${result.new} novo(s), ${result.queued} aviso(s) na fila.`);await loadYouTube();
    }else if(e.target.closest("[data-youtube-delete]")) {
      if(!confirm(`Remover ${channel.name} do Discord? Os destinos e avisos pendentes do Discord serão desativados. O Telegram permanece independente.`))return;
      await api(url,"DELETE");toast("Canal removido");await loadYouTube();
    }
  }catch(error){toast(error.message,true);}
});
$("#template-select").addEventListener("change",selectTemplate);
["#template-content","#template-title","#template-description","#template-footer","#template-image","#template-color","#template-preview-mode"].forEach(id=>$(id).addEventListener("input",previewTemplate));
$("#template-lines").addEventListener("dragstart", e => {const row=e.target.closest("[data-line]");if(!row)return;e.dataTransfer.setData("text/plain",row.dataset.line);e.dataTransfer.effectAllowed="move";});
$("#template-lines").addEventListener("dragover", e => {if(e.target.closest("[data-line]"))e.preventDefault();});
$("#template-lines").addEventListener("drop", e => {const row=e.target.closest("[data-line]");if(!row)return;e.preventDefault();const from=Number(e.dataTransfer.getData("text/plain")),to=Number(row.dataset.line),lines=$("#template-content").value.split("\n");if(!Number.isInteger(from)||from<0||from>=lines.length||to<0||to>=lines.length)return;lines.splice(to,0,lines.splice(from,1)[0]);$("#template-content").value=lines.join("\n");previewTemplate();});
const templateData=()=>({name:$("#template-name").value,content:$("#template-content").value,preview_mode:$("#template-preview-mode").value,embed_title:$("#template-title").value,embed_description:$("#template-description").value,embed_footer:$("#template-footer").value,embed_image:$("#template-image").value,embed_color:parseInt($("#template-color").value.slice(1),16)});
$("#template-save").addEventListener("click",async()=>{try{if(!confirm("Salvar este modelo? Os próximos avisos de todos os canais que usam este modelo serão atualizados."))return;await api(`/api/templates/${$("#template-select").value}`,"PATCH",templateData());toast("Modelo atualizado");await loadTemplates($("#template-select").value);}catch(error){toast(error.message,true);}});
$("#template-new").addEventListener("click",async()=>{try{const data=templateData();data.name=`Cópia de ${data.name}`.slice(0,80);const result=await api("/api/templates","POST",data);toast("Modelo criado");await loadTemplates(result.id);}catch(error){toast(error.message,true);}});
$("#api-add").addEventListener("click",async()=>{try{await api("/api/api-keys","POST",{name:`API ${String(state.apiKeys.length+1).padStart(2,"0")}`});await loadApiKeys();toast("Espaço para API criado");}catch(error){toast(error.message,true);}});
$("#api-list").addEventListener("click",async e=>{
  const item=e.target.closest("[data-api-id]");
  const test=e.target.closest("[data-api-test]");
  try {
    if(test) {await api(`/api/api-keys/${test.dataset.apiTest}/test`,"POST");toast("Chave validada");await loadApiKeys();return;}
    if(!item)return;
    const id=item.dataset.apiId, field=name=>item.querySelector(`[name="${name}"]`);
    const data={name:field("name").value,project_id:field("project_id").value,key:field("key").value,quota_limit:Number(field("quota_limit").value),priority:Number(field("priority").value),active:field("active").checked};
    if(e.target.closest("[data-api-save]")){await api(`/api/api-keys/${id}`,"PATCH",data);toast("Credencial salva");}
    else if(e.target.closest("[data-api-primary]")){await api(`/api/api-keys/${id}`,"PATCH",{...data,active:true,primary:true});toast("Chave principal alterada");}
    else if(e.target.closest("[data-api-delete]")){if(!confirm("Excluir esta credencial? O histórico de chamadas permanece."))return;await api(`/api/api-keys/${id}`,"DELETE");toast("Credencial excluída");}
    else return;
    await loadApiKeys();
  }catch(error){toast(error.message,true);}
});
$("#delivery-list").addEventListener("click",async e=>{const item=e.target.closest("[data-delivery]");if(!item||!e.target.closest("[data-retry]"))return;try{if(!confirm("Conferiu no Discord se este aviso já chegou? Reenviar pode duplicar uma mensagem com resultado incerto."))return;await api(`/api/deliveries/${item.dataset.delivery}/retry`,"POST");toast("Reenvio solicitado; confira antes se não chegou ao Discord");await refresh();}catch(error){toast(error.message,true);}});
$("#settings-form").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/settings","PATCH",{playlist_interval:Number(e.target.elements.playlist_interval.value),timezone:e.target.elements.timezone.value});toast("Configurações salvas");await refresh();}catch(error){toast(error.message,true);}});
function selectActivityTab(name, focus=false) {
  document.querySelectorAll("[data-activity-tab]").forEach(button => {
    const active=button.dataset.activityTab===name;
    button.classList.toggle("active",active);
    button.setAttribute("aria-selected",String(active));
    button.tabIndex=active?0:-1;
    if(active&&focus)button.focus();
  });
  document.querySelectorAll("[data-activity-panel]").forEach(panel=>panel.classList.toggle("hidden",panel.dataset.activityPanel!==name));
}
$(".activity-tabs").addEventListener("click",event=>{const button=event.target.closest("[data-activity-tab]");if(button)selectActivityTab(button.dataset.activityTab);});
$(".activity-tabs").addEventListener("keydown",event=>{
  if(!["ArrowLeft","ArrowRight","Home","End"].includes(event.key))return;
  const tabs=[...document.querySelectorAll("[data-activity-tab]")],index=tabs.indexOf(document.activeElement);
  if(index<0)return;
  event.preventDefault();
  const next=event.key==="Home"?0:event.key==="End"?tabs.length-1:(index+(event.key==="ArrowRight"?1:-1)+tabs.length)%tabs.length;
  selectActivityTab(tabs[next].dataset.activityTab,true);
});
for(const [selector,path,message,label] of [
  ["#clear-deliveries","/api/activity/deliveries","Limpar todas as entregas finalizadas deste histórico, incluindo falhas e envios incertos? Os filtros não limitam a limpeza. Entregas na fila ou em andamento continuam visíveis. A proteção contra avisos duplicados é mantida.","entrega(s) limpa(s) do histórico"],
  ["#clear-tests","/api/activity/tests","Limpar todos os testes finalizados deste histórico? Testes na fila ou em andamento continuam visíveis. As mensagens já enviadas no Discord permanecem.","teste(s) limpo(s) do histórico"],
  ["#clear-logs","/api/logs","Limpar todos os logs do sistema? Novos registros podem aparecer enquanto o monitor funciona. Entregas e testes permanecem nos seus próprios históricos.","log(s) removido(s)"]
]) $(selector).addEventListener("click",async()=>{
  if(!confirm(message))return;
  const button=$(selector);button.disabled=true;
  try{const result=await api(path,"DELETE");toast(`${result.removed} ${label}`);await refresh();}
  catch(error){toast(error.message,true);}
  finally{button.disabled=false;}
});
$("#template-lines").addEventListener("click",e=>{const row=e.target.closest("[data-line]");if(!row)return;const dir=e.target.closest("[data-line-up]")?-1:e.target.closest("[data-line-down]")?1:0;if(!dir)return;const lines=$("#template-content").value.split("\n"),i=Number(row.dataset.line),to=i+dir;if(to<0||to>=lines.length)return;[lines[i],lines[to]]=[lines[to],lines[i]];$("#template-content").value=lines.join("\n");previewTemplate();});
let quotaTimer;
async function updateQuotaPreview(){const interval=Number($("#settings-form").elements.playlist_interval.value);if(!Number.isInteger(interval)||interval<30||interval>86400){$("#quota-preview").textContent="Escolha um intervalo entre 30 e 86.400 segundos.";return;}try{const q=await api(`/api/quota-preview?interval=${interval}`);$("#quota-preview").innerHTML=`<div class="quota-number">${q.playlist_units_per_day.toLocaleString("pt-BR")}</div><strong>unidades de playlist por dia</strong><p>${q.channels} canal(is) ativo(s) · uma página por busca · intervalo de ${q.interval}s</p><div class="note">${escapeHTML(q.note)}</div>`;}catch(e){toast(e.message,true);}}
$("#settings-form").elements.playlist_interval.addEventListener("input",()=>{clearTimeout(quotaTimer);quotaTimer=setTimeout(updateQuotaPreview,300);});
$("#settings-form").addEventListener("click",e=>{const b=e.target.closest("[data-interval]");if(b){$("#settings-form").elements.playlist_interval.value=b.dataset.interval;updateQuotaPreview();}});
window.addEventListener("DOMContentLoaded",()=>api("/api/session").then(showApp).catch(showLogin));
