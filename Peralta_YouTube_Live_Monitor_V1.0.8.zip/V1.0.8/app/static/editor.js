"use strict";
let channelEdit=null, editorOpenSequence=0, previewSequence=0, previewTimer, testPollTimer;
const routeKey=r=>`${r.guild_id}/${r.channel_id}`;
const editorTemplateFields={name:"name",content:"content",preview_mode:"preview-mode",embed_title:"title",embed_description:"description",embed_footer:"footer",embed_image:"image",embed_color:"color"};
const findTemplate=id=>channelEdit?.templates.find(t=>Number(t.id)===Number(id))||channelEdit?.templates[0];
function selectedMessage(){if(!channelEdit)return null;return channelEdit.scope==="main"?channelEdit.main:channelEdit.routes.find(r=>routeKey(r)===channelEdit.scope)?.message;}
function activeScopeRoute(){return channelEdit?.routes.find(r=>routeKey(r)===channelEdit.scope);}
function markEditorDirty(){if(channelEdit){channelEdit.dirty=true;$("#editor-save-hint").textContent="Alterações ainda não salvas";$("#editor-error").textContent="";}}
function makeMessage(id,effective){return {mode:id?"existing":"inherit",sourceId:id||effective||1,template:null};}
async function openChannelEditor(channelId){
  const sequence=++editorOpenSequence;
  try{
    const [config,guilds,templates]=await Promise.all([api(`/api/youtube-channels/${encodeURIComponent(channelId)}/configuration`),api("/api/guilds"),api("/api/templates")]);
    if(sequence!==editorOpenSequence)return;
    channelEdit={...config,guilds,templates,dirty:false,step:0,scope:"main",main:makeMessage(config.channel.template_id,1),routes:config.destinations.map(r=>({...r,message:makeMessage(r.template_id,r.effective_template_id)}))};
    channelEdit.scope=channelEdit.routes[0]?routeKey(channelEdit.routes[0]):"main";
    $("#editor-title").textContent=config.channel.name;$("#editor-channel-id").textContent=config.channel.channel_id;
    $("#editor-active").checked=Boolean(config.channel.active);$("#editor-error").textContent="";$("#editor-test-result").textContent="";
    $("#editor-save-hint").textContent="Confira e salve ao concluir";
    renderGuildOptions();renderRoutes();renderMessageScopes();loadMessageFields();renderPreviewDestinations();setEditorStep(0);
    if(!$("#channel-editor").open)$("#channel-editor").showModal();document.body.classList.add("no-scroll");schedulePreview();
  }catch(e){toast(e.message,true);}
}
function closeEditor(){
  if(channelEdit?.saving)return;
  if(channelEdit?.dirty&&!confirm("Sair da edição e descartar as alterações ainda não salvas?"))return;
  ++previewSequence;++editorOpenSequence;clearTimeout(previewTimer);clearTimeout(testPollTimer);$("#channel-editor").close();document.body.classList.remove("no-scroll");channelEdit=null;
}
function renderGuildOptions(){
  const old=$("#route-guild").value;
  $("#route-guild").innerHTML=channelEdit.guilds.filter(g=>g.present&&g.owner_verified).map(g=>`<option value="${escapeHTML(g.guild_id)}">${escapeHTML(g.name)}${g.active?"":" (servidor pausado)"}</option>`).join("")||'<option value="">Autorize um servidor na aba Discord</option>';
  if([...$("#route-guild").options].some(o=>o.value===old))$("#route-guild").value=old;
  renderDestinationOptions();
}
function renderDestinationOptions(){
  const g=channelEdit?.guilds.find(g=>g.guild_id===$("#route-guild").value);
  const channels=(g?.channels||[]).filter(c=>c.can_view&&c.can_send&&!channelEdit.routes.some(r=>r.guild_id===g.guild_id&&r.channel_id===c.channel_id));
  $("#route-channel").innerHTML=channels.map(c=>`<option value="${escapeHTML(c.channel_id)}">#${escapeHTML(c.name)}</option>`).join("")||'<option value="">Nenhum destino disponível</option>';
  $("#route-add").disabled=!channels.length;
}
function renderRoutes(){
  $("#route-list").innerHTML=channelEdit.routes.length?channelEdit.routes.map((r,i)=>{
    const options=channelEdit.templates.map(t=>`<option value="${t.id}" ${r.message.mode==="existing"&&Number(r.message.sourceId)===t.id?"selected":""}>${escapeHTML(t.name)}</option>`).join("");
    const problems=[];if(!r.present)problems.push("Bot ausente");else if(!r.owner_verified)problems.push("Servidor não autorizado");else if(!r.guild_active)problems.push("Servidor pausado: ative na aba Discord");
    if(!r.can_view||!r.can_send)problems.push("Sem permissão de envio");else if(!r.can_embed)problems.push("Sem permissão de prévia (Embed Links)");
    return `<article class="route-item ${r.active?"":"paused"}" data-route-index="${i}"><div class="route-heading"><div><strong>#${escapeHTML(r.destination_name)}</strong><small>${escapeHTML(r.guild_name)}</small></div><button type="button" class="text-button" data-remove-route aria-label="Remover destino ${escapeHTML(r.destination_name)}">Remover</button></div><label class="check"><input type="checkbox" data-route-field="active" ${r.active?"checked":""}>${r.active?"Destino habilitado":"Destino pausado"}</label><label>Mensagem para este destino<select data-route-template><option value="inherit" ${r.message.mode==="inherit"?"selected":""}>Usar padrão deste canal</option>${r.message.mode==="copy"?'<option value="copy" selected>Mensagem personalizada (rascunho)</option>':""}${options}</select></label><button type="button" class="outline small" data-edit-route-message>Editar mensagem e estilo ↗</button><div class="route-options top-gap"><label class="check"><input type="checkbox" data-route-field="notify_uploads" ${r.notify_uploads?"checked":""}>Vídeos / Shorts</label><label class="check"><input type="checkbox" data-route-field="notify_scheduled" ${r.notify_scheduled?"checked":""}>Lives agendadas / ao vivo</label><label class="check"><input type="checkbox" data-route-field="mention_everyone" ${r.mention_everyone?"checked":""}>@everyone</label></div><p class="route-diagnostics ${problems.length?"problem":""}">${escapeHTML(problems.join(" · ")||"Permissões de envio disponíveis")}</p></article>`;
  }).join(""):'<div class="empty"><strong>Escolha o primeiro destino.</strong>Adicione os canais Discord que receberão os avisos deste canal do YouTube.</div>';
}
function renderMessageScopes(){
  const valid=channelEdit.scope==="main"||channelEdit.routes.some(r=>routeKey(r)===channelEdit.scope);
  if(!valid)channelEdit.scope=channelEdit.routes[0]?routeKey(channelEdit.routes[0]):"main";
  $("#message-scope").innerHTML=channelEdit.routes.map(r=>`<option value="${escapeHTML(routeKey(r))}">${escapeHTML(r.guild_name)} / #${escapeHTML(r.destination_name)}</option>`).join("")+'<option value="main">Padrão deste canal (para os destinos que o usam)</option>';
  $("#message-scope").value=channelEdit.scope;
}
function loadMessageFields(){
  const message=selectedMessage();if(!message)return;
  const destination=activeScopeRoute();
  $("#message-context").textContent=destination?`As escolhas abaixo valem para ${destination.guild_name} / #${destination.destination_name}.`:"Este padrão vale para os destinos que escolherem usá-lo.";
  $("#channel-template-mode").value=message.mode;
  $("#channel-template-mode").options[0].textContent=channelEdit.scope==="main"?"Manter o padrão de cada servidor":"Usar o padrão deste canal";
  $("#channel-template-source").innerHTML=channelEdit.templates.map(t=>`<option value="${t.id}">${escapeHTML(t.name)}</option>`).join("");
  $("#channel-template-source").value=String(message.sourceId);
  const template=message.template||findTemplate(message.sourceId);
  for(const [key,id]of Object.entries(editorTemplateFields))$("#channel-template-"+id).value=key==="embed_color"?`#${Number(template?.[key]||15086414).toString(16).padStart(6,"0")}`:template?.[key]||"";
  toggleMessageFields();
}
function toggleMessageFields(){
  const mode=selectedMessage()?.mode||"inherit";
  $("#channel-copy-fields").classList.toggle("hidden",mode!=="copy");$("#channel-copy-fields").disabled=mode!=="copy";
  $("#channel-source-wrap").classList.toggle("hidden",mode==="inherit");$("#load-source-template").classList.toggle("hidden",mode!=="copy");
  $("#channel-embed-fields").classList.toggle("hidden",$("#channel-template-preview-mode").value!=="custom");
}
function captureMessageFields(){
  const message=selectedMessage();if(!message)return;
  if(message.mode==="copy")message.template=Object.fromEntries(Object.entries(editorTemplateFields).map(([key,id])=>[key,key==="embed_color"?parseInt($("#channel-template-"+id).value.slice(1),16):$("#channel-template-"+id).value]));
}
function suggestedCopyName(){const r=activeScopeRoute();return (r?`${channelEdit.channel.name} — ${r.guild_name} / #${r.destination_name}`:channelEdit.channel.name).slice(0,80);}
function copySource(){const message=selectedMessage();message.template={...findTemplate(message.sourceId),name:suggestedCopyName()};message.mode="copy";loadMessageFields();markEditorDirty();renderRoutes();schedulePreview();}
function renderPreviewDestinations(){
  const current=$("#preview-destination").value;
  $("#preview-destination").innerHTML=channelEdit.routes.map(r=>`<option value="${escapeHTML(routeKey(r))}">${escapeHTML(r.guild_name)} / #${escapeHTML(r.destination_name)}</option>`).join("")||'<option value="">Exemplo sem destino</option>';
  if(channelEdit.routes.some(r=>routeKey(r)===current))$("#preview-destination").value=current;
  $("#send-preview-test").disabled=!channelEdit.routes.length;
}
function messagePayload(message){return {template_mode:message.mode,template_id:message.mode==="existing"?Number(message.sourceId):null,...(message.mode==="copy"?{template:message.template}:{})};}
function draftPayload(){captureMessageFields();return {revision:channelEdit.revision,active:$("#editor-active").checked,...messagePayload(channelEdit.main),destinations:channelEdit.routes.map(r=>({guild_id:r.guild_id,channel_id:r.channel_id,active:Boolean(r.active),notify_uploads:Boolean(r.notify_uploads),notify_scheduled:Boolean(r.notify_scheduled),mention_everyone:Boolean(r.mention_everyone),...messagePayload(r.message)}))};}
function previewPayload(){
  captureMessageFields();const r=channelEdit.routes.find(r=>routeKey(r)===$("#preview-destination").value);
  return {...messagePayload(channelEdit.main),guild_id:r?.guild_id||"",channel_id:r?.channel_id||"",mention_everyone:Boolean(r?.mention_everyone),destination_template_id:r?.message.mode==="existing"?Number(r.message.sourceId):null,destination_template_mode:r?.message.mode||"inherit",destination_template:r?.message.mode==="copy"?r.message.template:null};
}
function schedulePreview(){clearTimeout(previewTimer);previewTimer=setTimeout(updateEditorPreview,280);}
async function updateEditorPreview(){
  if(!channelEdit)return;const seq=++previewSequence;
  try{
    const result=await api(`/api/youtube-channels/${encodeURIComponent(channelEdit.channel.channel_id)}/preview`,"POST",previewPayload());
    if(seq!==previewSequence||!channelEdit)return;
    let html=escapeHTML(result.content);
    if(result.embed){const e=result.embed;html+=`<div class="preview-embed">${e.title?`<h3>${escapeHTML(e.title)}</h3>`:""}${e.description?`<p>${escapeHTML(e.description)}</p>`:""}${e.image?.url?`<div class="preview-mode-note">Imagem: ${escapeHTML(e.image.url)}</div>`:""}${e.footer?.text?`<small>${escapeHTML(e.footer.text)}</small>`:""}</div>`;}
    else if(result.preview_mode==="youtube")html+='<div class="preview-mode-note">▶ O Discord gera o cartão do vídeo a partir do link.</div>';
    $("#editor-preview").innerHTML=html;
    if(result.embed){$("#editor-preview .preview-embed").style.borderLeftColor=`#${Number(result.embed.color||15086414).toString(16).padStart(6,"0")}`;}
    $("#preview-note").textContent=result.sample?"Prévia ilustrativa com exemplo deste canal. O aviso real usa os dados da nova publicação.":"Prévia com a publicação mais recente já registrada. Nenhuma chamada extra ao YouTube.";
  }catch(e){if(seq===previewSequence&&channelEdit){$("#editor-preview").textContent=e.message;$("#preview-note").textContent="Complete a mensagem para visualizar.";}}
}
function messageLabel(message,route){
  if(message.mode==="copy")return `${message.template?.name||"Personalizado"} · ${message.template?.preview_mode==="custom"?"embed personalizado":"prévia YouTube"}`;
  if(message.mode==="existing") {const t=findTemplate(message.sourceId);return `${t?.name||"Modelo"} · ${t?.preview_mode==="custom"?"embed personalizado":"prévia YouTube"}`;}
  if(route&&channelEdit.main.mode!=="inherit")return messageLabel(channelEdit.main);
  const g=route&&channelEdit.guilds.find(g=>g.guild_id===route.guild_id),t=g&&findTemplate(g.template_id);
  return t?`${t.name} · padrão do servidor`:"Padrão de cada servidor";
}
function renderReview(){
  captureMessageFields();const routes=channelEdit.routes,removed=channelEdit.destinations.filter(old=>!routes.some(r=>routeKey(r)===routeKey(old)));
  const blocked=routes.filter(r=>r.active&&(!r.guild_active||!r.present||!r.owner_verified||!r.can_send));
  $("#edit-summary").innerHTML=`<div class="review-block"><strong>${escapeHTML(channelEdit.channel.name)}</strong><p>${routes.length} destino(s) em ${new Set(routes.map(r=>r.guild_id)).size} servidor(es). ${routes.filter(r=>r.active).length} habilitado(s).</p></div>${routes.map(r=>`<div class="review-block"><div class="review-target"><span><strong>${escapeHTML(r.guild_name)} / #${escapeHTML(r.destination_name)}</strong><small>${escapeHTML(messageLabel(r.message,r))}</small></span><span class="pill ${r.active?"good":"neutral"}">${r.active?"Habilitado":"Pausado"}</span></div><p>${[r.notify_uploads?"Vídeos e Shorts":null,r.notify_scheduled?"Lives agendadas / ao vivo":null].filter(Boolean).join(" · ")||"Nenhum tipo de publicação habilitado"} · ${r.mention_everyone?"Com @everyone":"Sem @everyone"}</p></div>`).join("")}${removed.length?`<div class="change-note">${removed.length} destino(s) removido(s) deste canal. Avisos pendentes para esses destinos serão cancelados.</div>`:""}${!routes.length?'<div class="change-note">Sem destinos, este canal pode ser monitorado, mas não enviará avisos ao Discord.</div>':""}${blocked.length?'<div class="change-note">Há destinos com servidor pausado, ausente ou sem permissão. Corrija na aba Discord para que recebam avisos.</div>':""}<p class="field-hint">Retomar um destino começa pelas novas publicações. Os avisos do período pausado não são reenviados automaticamente.</p>`;
}
function setEditorStep(step){
  if(!channelEdit)return;captureMessageFields();channelEdit.step=Math.max(0,Math.min(2,step));
  document.querySelectorAll("[data-panel]").forEach(n=>n.classList.toggle("hidden",Number(n.dataset.panel)!==channelEdit.step));
  document.querySelectorAll("[data-step]").forEach(n=>{n.classList.toggle("active",Number(n.dataset.step)===channelEdit.step);n.setAttribute("aria-selected",String(Number(n.dataset.step)===channelEdit.step));});
  $("#editor-back").classList.toggle("hidden",channelEdit.step===0);$("#editor-next").classList.toggle("hidden",channelEdit.step===2);$("#editor-save").classList.toggle("hidden",channelEdit.step!==2);$("#editor-next").textContent=channelEdit.step===0?"Próximo: mensagem →":"Revisar configurações →";
  if(channelEdit.step===2)renderReview();
  if(channelEdit.step===1){renderMessageScopes();loadMessageFields();if(channelEdit.scope!=="main")$("#preview-destination").value=channelEdit.scope;schedulePreview();}
  $(".editor-layout").scrollTop=0;
}
$("#close-editor").addEventListener("click",closeEditor);
$("#channel-editor").addEventListener("cancel",e=>{e.preventDefault();closeEditor();});
$("#editor-back").addEventListener("click",()=>setEditorStep(channelEdit.step-1));$("#editor-next").addEventListener("click",()=>setEditorStep(channelEdit.step+1));
$(".editor-tabs").addEventListener("click",e=>{const b=e.target.closest("[data-step]");if(b)setEditorStep(Number(b.dataset.step));});
$("#route-guild").addEventListener("change",renderDestinationOptions);
$("#route-add").addEventListener("click",()=>{
  const g=channelEdit.guilds.find(g=>g.guild_id===$("#route-guild").value),c=g?.channels.find(c=>c.channel_id===$("#route-channel").value);if(!g||!c)return;
  channelEdit.routes.push({guild_id:g.guild_id,channel_id:c.channel_id,guild_name:g.name,destination_name:c.name,active:1,guild_active:g.active,present:g.present,owner_verified:g.owner_verified,can_view:c.can_view,can_send:c.can_send,can_embed:c.can_embed,can_mention:c.can_mention,notify_uploads:g.notify_uploads,notify_scheduled:g.notify_scheduled,mention_everyone:g.mention_everyone&&c.can_mention?1:0,message:makeMessage(null,g.template_id)});
  if(channelEdit.routes.length===1)channelEdit.scope=routeKey(channelEdit.routes[0]);markEditorDirty();renderRoutes();renderDestinationOptions();renderMessageScopes();loadMessageFields();renderPreviewDestinations();schedulePreview();
});
$("#route-list").addEventListener("click",e=>{
  const row=e.target.closest("[data-route-index]");if(!row)return;const i=Number(row.dataset.routeIndex),r=channelEdit.routes[i];
  if(e.target.closest("[data-remove-route]")){captureMessageFields();channelEdit.routes.splice(i,1);markEditorDirty();renderRoutes();renderDestinationOptions();renderMessageScopes();loadMessageFields();renderPreviewDestinations();schedulePreview();}
  if(e.target.closest("[data-edit-route-message]")){captureMessageFields();channelEdit.scope=routeKey(r);loadMessageFields();setEditorStep(1);}
});
$("#route-list").addEventListener("change",e=>{
  const row=e.target.closest("[data-route-index]");if(!row)return;const r=channelEdit.routes[Number(row.dataset.routeIndex)];
  if(e.target.dataset.routeField){r[e.target.dataset.routeField]=e.target.checked?1:0;}
  else if(e.target.matches("[data-route-template]")){r.message.mode=e.target.value==="inherit"?"inherit":e.target.value==="copy"?"copy":"existing";if(r.message.mode==="existing")r.message.sourceId=Number(e.target.value);}
  markEditorDirty();renderRoutes();if(channelEdit.scope===routeKey(r))loadMessageFields();schedulePreview();
});
$("#message-scope").addEventListener("change",()=>{captureMessageFields();channelEdit.scope=$("#message-scope").value;loadMessageFields();if(channelEdit.scope!=="main")$("#preview-destination").value=channelEdit.scope;schedulePreview();});
$("#channel-template-mode").addEventListener("change",()=>{captureMessageFields();const message=selectedMessage();message.mode=$("#channel-template-mode").value;if(message.mode==="copy"&&!message.template)copySource();else{loadMessageFields();markEditorDirty();renderRoutes();schedulePreview();}});
$("#channel-template-source").addEventListener("change",()=>{const message=selectedMessage();message.sourceId=Number($("#channel-template-source").value);if(message.mode!=="copy"){loadMessageFields();markEditorDirty();renderRoutes();schedulePreview();}});
$("#load-source-template").addEventListener("click",()=>{if(selectedMessage().template&&!confirm("Substituir o rascunho deste destino pelo conteúdo do modelo selecionado?"))return;copySource();});
$("#channel-copy-fields").addEventListener("input",()=>{captureMessageFields();markEditorDirty();toggleMessageFields();schedulePreview();});
$(".variable-buttons").innerHTML=["{tipo}","{canal}","{titulo}","{link}","{data}","{everyone}"].map(v=>`<button type="button" data-variable="${v}">${v}</button>`).join("");
$(".variable-buttons").addEventListener("click",e=>{const b=e.target.closest("[data-variable]");if(!b)return;const t=$("#channel-template-content");t.setRangeText(b.dataset.variable,t.selectionStart,t.selectionEnd,"end");t.focus();captureMessageFields();markEditorDirty();schedulePreview();});
$("#editor-active").addEventListener("change",()=>{markEditorDirty();renderReview();});
$("#preview-destination").addEventListener("change",()=>{clearTimeout(testPollTimer);$("#editor-test-result").textContent="";schedulePreview();});
$("#editor-form").addEventListener("submit",async e=>{
  e.preventDefault();if(!channelEdit||channelEdit.saving)return;if(channelEdit.step!==2){setEditorStep(2);return;}
  const button=$("#editor-save");button.disabled=true;channelEdit.saving=true;$("#editor-error").textContent="";
  try{await api(`/api/youtube-channels/${encodeURIComponent(channelEdit.channel.channel_id)}/configuration`,"PUT",draftPayload());channelEdit.dirty=false;channelEdit.saving=false;closeEditor();await loadYouTube();toast("Configuração salva. Mensagens e destinos atualizados.");}
  catch(error){if(channelEdit){$("#editor-error").textContent=error.message;$("#editor-error").scrollIntoView({block:"nearest"});channelEdit.saving=false;}}
  finally{button.disabled=false;}
});
$("#send-preview-test").addEventListener("click",async()=>{
  if(!channelEdit)return;const data=previewPayload(),r=channelEdit.routes.find(r=>r.guild_id===data.guild_id&&r.channel_id===data.channel_id);if(!r)return;
  if(!confirm(`Enviar uma mensagem de teste em ${r.guild_name} / #${r.destination_name}? Este rascunho será enviado sem menções.`))return;
  const button=$("#send-preview-test");button.disabled=true;
  try{const result=await api(`/api/youtube-channels/${encodeURIComponent(channelEdit.channel.channel_id)}/test`,"POST",data);$("#editor-test-result").textContent="Teste na fila do bot…";watchTest(result.id,Date.now());}
  catch(e){$("#editor-test-result").textContent=e.message;}
  finally{button.disabled=false;}
});
async function watchTest(id,start){
  clearTimeout(testPollTimer);if(!channelEdit)return;
  try{const t=await api(`/api/test-requests/${id}`);if(!channelEdit)return;
    if(t&&["sent","failed"].includes(t.status)){$("#editor-test-result").textContent=t.status==="sent"?"Teste enviado. Confira o resultado no Discord.":`Teste falhou: ${t.error||"Veja os registros"}`;return;}
    if(Date.now()-start>60000){$("#editor-test-result").textContent="Teste aguardando o bot. Acompanhe em Entregas e logs.";return;}
    testPollTimer=setTimeout(()=>watchTest(id,start),2500);
  }catch(e){if(channelEdit)$("#editor-test-result").textContent=e.message;}
}
window.addEventListener("beforeunload",e=>{if(channelEdit?.dirty){e.preventDefault();e.returnValue="";}});
