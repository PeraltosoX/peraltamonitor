"use strict";
const TelegramUI = (() => {
  const names={global:"Busca global","tg-config":"Bot e administrador","tg-destinations":"Canais e grupos","tg-private":"Meu privado","tg-channels":"Canais e avisos · Telegram","tg-messages":"Modelos · Telegram","tg-activity":"Entregas e logs · Telegram"};
  const descriptions={global:"Uma busca por canal, compartilhada pelo Discord e Telegram.","tg-config":"Seu bot e sua conta autorizada, configurados pelo painel.","tg-destinations":"Gerencie os destinos das suas comunidades no Telegram.","tg-private":"Avisos diretos, exclusivos para o ID autorizado.","tg-channels":"Mensagens independentes para cada destino do Telegram.","tg-messages":"Crie modelos e personalize cada destino.","tg-activity":"Consulte e limpe o histórico do Telegram."};
  const t={config:null,destinations:[],channels:[],templates:[],editor:null,selected:null,dirty:false,history:"deliveries",activity:null};
  const esc=escapeHTML;
  const endpoint="/api/telegram";
  const empty=message=>`<div class="empty"><strong>${esc(message)}</strong></div>`;
  const kindName={private:"Privado autorizado",group:"Grupo",supergroup:"Grupo",channel:"Canal"};
  async function action(button,fn,errorNode){
    if(button?.disabled)return;
    if(button)button.disabled=true;
    if(errorNode)errorNode.textContent="";
    try{return await fn();}catch(e){if(errorNode)errorNode.textContent=e.message;else toast(e.message,true);}
    finally{if(button)button.disabled=false;}
  }
  function open(id){$(id).showModal();document.body.classList.add("no-scroll");}
  function closeDialog(id){if(id==="tg-editor"&&t.dirty&&!confirm("Descartar as alterações ainda não salvas?"))return;$("#"+id).close();document.body.classList.remove("no-scroll");}
  document.addEventListener("click",e=>{const b=e.target.closest("[data-tg-close]");if(b)closeDialog(b.dataset.tgClose);});
  ["tg-add-dialog","tg-editor"].forEach(id=>$("#"+id).addEventListener("cancel",e=>{e.preventDefault();closeDialog(id);}));
  function formMessage(prefix){return{content:$(prefix+"-content").value,parse_mode:$(prefix+"-format").value,preview:$(prefix+"-preview").checked,silent:$(prefix+"-silent").checked};}
  function fillMessage(prefix,msg){$(prefix+"-content").value=msg.content;$(prefix+"-format").value=msg.parse_mode;$(prefix+"-preview").checked=!!msg.preview;$(prefix+"-silent").checked=!!msg.silent;}
  const previewVersions=new Map();
  async function showPreview(node,message){
    const serial=(previewVersions.get(node)||0)+1;previewVersions.set(node,serial);
    try{const result=await api(endpoint+"/preview","POST",message);if(previewVersions.get(node)!==serial)return;node.innerHTML=result.html;node.querySelectorAll("a").forEach(a=>{a.target="_blank";a.rel="noopener noreferrer";});}
    catch(e){if(previewVersions.get(node)===serial)node.textContent=e.message;}
  }
  function botStatus(c){return `<span class="pill ${c.configured&&c.enabled?"good":"neutral"}">${c.configured?(c.enabled?"Ativado":"Desativado"):"Aguardando configuração"}</span><div class="tg-bot-identity">${esc(c.bot_name||"Conecte seu bot")}</div><p>${c.bot_username?"@"+esc(c.bot_username):"Valide o token para identificar o bot."}</p>${c.last_error?`<p class="error">${esc(c.last_error)}</p>`:""}<p class="field-hint">Última validação: ${date(c.last_checked)}${c.heartbeat?`<br>Serviço: ${esc(c.heartbeat.detail)} · ${date(c.heartbeat.at)}`:""}</p>`;}
  async function load(view){
    if(view==="global"){
      const channels=await api("/api/global-channels");
      $("#global-list").innerHTML=channels.length?channels.map(c=>`<article class="card card-body tg-global-row"><div><h3>${esc(c.name)}</h3><small class="mono">${esc(c.channel_id)}</small><div class="tg-platforms">${c.discord_enabled?`<span class="pill ${c.discord_active?"good":"neutral"}">Discord ${c.discord_active?"ativo":"pausado"}</span>`:""}${c.telegram_active!==null?`<span class="pill ${c.telegram_active?"good":"neutral"}">Telegram ${c.telegram_active?"ativo":"pausado"}</span>`:""}</div></div><div><strong>${c.active?"Busca ativa":"Busca pausada"}</strong><p>Última consulta: ${date(c.last_poll)}<br>Próxima busca: ${c.active?(c.next_poll<=Date.now()/1000?"Na fila":date(c.next_poll)):"Pausada"}</p>${c.last_error?`<p class="error">${esc(c.last_error)}</p>`:""}</div><button class="outline small" data-tg-global-check="${esc(c.channel_id)}" ${c.active?"":"disabled"}>Verificar agora</button></article>`).join(""):empty("Adicione um canal na seção Discord ou Telegram.");
    }else if(view==="tg-config"){
      const c=t.config=await api(endpoint+"/config"),f=$("#tg-config-form");
      f.elements.admin_id.value=c.admin_id;f.elements.admin_username.value=c.admin_username?"@"+c.admin_username:"";f.elements.token.value="";f.elements.enabled.checked=!!c.enabled;
      $("#tg-token-hint").textContent=c.configured?"Token protegido. Deixe em branco para manter o token atual.":"O token fica protegido e não é exibido depois de salvo.";
      $("#tg-bot-status").innerHTML=botStatus(c);
    }else if(view==="tg-destinations"){
      t.destinations=await api(endpoint+"/destinations");renderDestinations();
    }else if(view==="tg-private"){
      const [cfg,dests]=await Promise.all([api(endpoint+"/config"),api(endpoint+"/destinations")]);t.config=cfg;t.destinations=dests;
      const dest=dests.find(d=>d.kind==="private"&&d.chat_id===cfg.admin_id),ready=cfg.private_chat_id===cfg.admin_id&&cfg.admin_id&&dest?.verified;
      const link=/^[A-Za-z0-9_]{1,64}$/.test(cfg.bot_username)?`https://t.me/${cfg.bot_username}`:"";
      $("#tg-private-content").innerHTML=`<div class="card card-body tg-private-card"><span class="pill ${ready?"good":"warn"}">${ready?"Privado vinculado":"Aguardando sua mensagem"}</span><h2 class="tg-bot-identity">${cfg.admin_username?"@"+esc(cfg.admin_username):"Sua conta autorizada"}</h2><p>ID do administrador: <strong>${esc(cfg.admin_id||"Ainda não configurado")}</strong></p><p>${ready?"Sua identidade foi confirmada pelo ID. Escolha este destino em Canais e avisos do Telegram.":"Ative o Telegram em Bot e administrador. Depois abra seu bot e envie /start usando a conta do ID acima. A conexão aparece aqui automaticamente."}</p><div class="note">Somente esse ID pode vincular o privado e receber avisos. O @usuário é uma identificação; outras pessoas que iniciarem o bot não são cadastradas.</div>${cfg.last_error?`<p class="error">${esc(cfg.last_error)}</p>`:""}${ready&&(!cfg.enabled||!dest.active)?`<p class="error">${!cfg.enabled?"Telegram desativado em Bot e administrador.":"O destino privado está pausado."}</p>`:""}<div class="actions">${link?`<a class="platform-label" href="${link}" target="_blank" rel="noopener noreferrer">Abrir @${esc(cfg.bot_username)} ↗</a>`:`<button class="primary" data-go="tg-config">Configurar bot</button>`}${ready?`<button class="outline" data-go="tg-channels">Escolher canais e avisos</button><button class="outline" data-tg-dest-test="${dest.id}">Enviar teste</button><button class="outline" data-tg-dest-toggle="${dest.id}">${dest.active?"Pausar privado":"Retomar privado"}</button>`:""}</div></div>`;
    }else if(view==="tg-channels"){
      t.channels=await api(endpoint+"/channels");
      $("#tg-channel-list").innerHTML=t.channels.length?t.channels.map(c=>`<article class="card card-body tg-channel-row"><div><h2>${esc(c.name)}</h2><small>${esc(c.channel_id)}</small></div><div><span class="pill ${c.active?"good":"neutral"}">${c.active?"Avisos ativos":"Pausado"}</span><p>${c.destinations} destino(s)</p><small>Última busca: ${date(c.last_poll)}</small>${c.last_error?`<small class="error">${esc(c.last_error)}</small>`:""}</div><div class="actions"><button class="primary small" data-tg-edit="${esc(c.channel_id)}">Editar avisos ↗</button><button class="danger small" data-tg-remove-channel="${esc(c.channel_id)}">Remover</button></div></article>`).join(""):empty("Adicione o primeiro canal do YouTube para o Telegram.");
    }else if(view==="tg-messages"){
      t.templates=await api(endpoint+"/templates");const old=$("#tg-template-select").value;
      $("#tg-template-select").innerHTML=t.templates.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");
      if(t.templates.some(x=>String(x.id)===old))$("#tg-template-select").value=old;
      selectTemplate();
    }else if(view==="tg-activity"){
      t.activity=await api(endpoint+"/activity");renderHistory();
    }
  }
  function renderDestinations(){const dests=t.destinations.filter(d=>d.kind!=="private");$("#tg-destination-list").innerHTML=dests.length?dests.map(d=>`<article class="card card-body tg-dest-row"><div><h3>${esc(d.name)}</h3><p>${esc(kindName[d.kind])} · ${esc(d.chat_id)} ${d.username?"· @"+esc(d.username):""}</p><span class="pill ${!d.verified?"warn":d.active?"good":"neutral"}">${!d.verified?"Verifique o bot":d.active?"Pronto para avisos":"Pausado"}</span>${d.last_error?`<p class="error">${esc(d.last_error)}</p>`:""}</div><div class="actions"><button class="outline small" data-tg-dest-test="${d.id}">Testar</button><button class="outline small" data-tg-dest-verify="${d.id}">Verificar</button><button class="outline small" data-tg-dest-toggle="${d.id}">${d.active?"Pausar":"Retomar"}</button><button class="danger small" data-tg-dest-remove="${d.id}">Remover</button></div></article>`).join(""):empty("Nenhum canal ou grupo cadastrado.");}
  $("#tg-config-form").addEventListener("submit",e=>{e.preventDefault();const f=e.target;action(f.querySelector('button[type="submit"]'),async()=>{
    const changingOwner=t.config?.admin_id&&t.config.admin_id!==f.elements.admin_id.value.trim();
    if(changingOwner&&!confirm("Trocar o ID autorizado? O privado anterior será desvinculado e o novo administrador precisará iniciar o bot."))return;
    const c=await api(endpoint+"/config","PUT",{revision:t.config.revision,admin_id:f.elements.admin_id.value,admin_username:f.elements.admin_username.value,token:f.elements.token.value,enabled:f.elements.enabled.checked});
    f.elements.token.value="";t.config=c;toast("Bot validado e configuração salva.");await load("tg-config");
  },$("#tg-config-error"));});
  $("#tg-destination-form").addEventListener("submit",e=>{e.preventDefault();const f=e.target;action(f.querySelector("button"),async()=>{await api(endpoint+"/destinations","POST",{chat_id:f.elements.chat_id.value});f.reset();toast("Destino verificado. Agora escolha os avisos para ele.");await load("tg-destinations");});});
  document.addEventListener("click",e=>{
    const b=e.target.closest("[data-tg-dest-test],[data-tg-dest-toggle],[data-tg-dest-verify],[data-tg-dest-remove],[data-tg-global-check],[data-tg-edit],[data-tg-remove-channel]");if(!b)return;
    action(b,async()=>{
      if(b.dataset.tgGlobalCheck){const r=await api(`/api/youtube-channels/${encodeURIComponent(b.dataset.tgGlobalCheck)}/check`,"POST");toast(`${r.new} publicação(ões) nova(s), ${r.queued} aviso(s) na fila.`);await load("global");return;}
      if(b.dataset.tgEdit){await openEditor(b.dataset.tgEdit);return;}
      if(b.dataset.tgRemoveChannel){if(!confirm("Remover este canal dos avisos do Telegram? As configurações do Discord permanecem independentes."))return;await api(endpoint+"/channels/"+encodeURIComponent(b.dataset.tgRemoveChannel),"DELETE");await load("tg-channels");return;}
      const did=Number(b.dataset.tgDestTest||b.dataset.tgDestToggle||b.dataset.tgDestVerify||b.dataset.tgDestRemove),d=t.destinations.find(x=>x.id===did);
      if(!d)throw Error("Atualize a lista de destinos.");
      if(b.dataset.tgDestTest){if(!confirm(`Enviar uma mensagem real de teste para ${d.name}?`))return;await api(endpoint+"/tests","POST",{destination_id:did,content:"Conexão pronta! Os próximos avisos chegam por aqui.\n{link}",silent:true});toast("Teste na fila. Acompanhe em Entregas e logs do Telegram.");}
      else if(b.dataset.tgDestToggle){await api(endpoint+"/destinations/"+did,"PATCH",{active:!d.active});toast(d.active?"Destino pausado.":"Destino retomado para novas publicações.");}
      else if(b.dataset.tgDestVerify){await api(endpoint+"/destinations","POST",{chat_id:d.chat_id});toast("Bot e permissões verificados.");}
      else if(b.dataset.tgDestRemove){if(!confirm(`Remover ${d.name} e seus avisos pendentes do Telegram?`))return;await api(endpoint+"/destinations/"+did,"DELETE");}
      await load(state.view);
    });
  });
  $("#tg-add-channel").addEventListener("click",e=>action(e.currentTarget,async()=>{
    const channels=await api("/api/global-channels");$("#tg-existing-channel").innerHTML='<option value="">Escolher canal…</option>'+channels.map(c=>`<option value="${esc(c.channel_id)}">${esc(c.name)}</option>`).join("");
    $("#tg-channel-form").reset();$("#tg-add-error").textContent="";open("#tg-add-dialog");
  }));
  $("#tg-existing-channel").addEventListener("change",e=>$("#tg-channel-form").elements.channel_id.value=e.target.value);
  $("#tg-channel-form").addEventListener("submit",e=>{e.preventDefault();action(e.target.querySelector("button"),async()=>{
    const result=await api(endpoint+"/channels","POST",{channel_id:e.target.elements.channel_id.value});closeDialog("tg-add-dialog");await load("tg-channels");await openEditor(result.channel.channel_id);
  },$("#tg-add-error"));});
  async function openEditor(cid){
    const [editor,dests,templates]=await Promise.all([api(endpoint+"/channels/"+encodeURIComponent(cid)),api(endpoint+"/destinations"),api(endpoint+"/templates")]);
    t.editor=editor;t.destinations=dests;t.templates=templates;t.selected=editor.destinations[0]?.destination_id??null;t.dirty=false;
    $("#tg-editor-title").textContent=editor.channel.name;$("#tg-editor-id").textContent=cid;$("#tg-channel-active").checked=!!editor.channel.active;$("#tg-editor-error").textContent="";
    $("#tg-route-template").innerHTML=templates.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");renderRoutes();fillRoute();open("#tg-editor");
  }
  function selectedRoute(){return t.editor?.destinations.find(x=>x.destination_id===t.selected);}
  function flushRoute(){const r=selectedRoute();if(r)Object.assign(r,formMessage("#tg-route"),{notify_uploads:$("#tg-route-uploads").checked,notify_scheduled:$("#tg-route-scheduled").checked});}
  function renderRoutes(){
    const routes=t.editor.destinations,available=t.destinations.filter(d=>!routes.some(r=>r.destination_id===d.id)&&d.verified);
    $("#tg-route-add-select").innerHTML=available.length?available.map(d=>`<option value="${d.id}">${esc(d.name)} · ${esc(kindName[d.kind])}</option>`).join(""):'<option value="">Cadastre ou verifique um destino</option>';
    $("#tg-route-add").disabled=!available.length;
    $("#tg-route-list").innerHTML=routes.length?routes.map(r=>`<div class="tg-route-card ${r.destination_id===t.selected?"selected":""}"><button type="button" data-tg-select-route="${r.destination_id}" aria-pressed="${r.destination_id===t.selected}">${esc(r.name)} <small>· ${esc(kindName[r.kind])}</small></button><div class="actions"><label class="check"><input type="checkbox" data-tg-route-active="${r.destination_id}" ${r.active?"checked":""}>Avisos ativos</label><button type="button" class="text-button small" data-tg-remove-route="${r.destination_id}">Remover</button></div>${!r.verified||r.destination_active===0?'<p class="error">Destino pausado ou aguardando verificação.</p>':""}</div>`).join(""):'<p class="field-hint">Nenhum destino escolhido. Cadastre um canal, grupo ou vincule seu privado e adicione aqui.</p>';
  }
  function fillRoute(){const r=selectedRoute();$("#tg-route-fields").disabled=!r;$("#tg-message-target").textContent=r?`${r.name} · ${kindName[r.kind]}`:"Adicione ou selecione um destino";
    if(!r){$("#tg-route-content").value="";$("#tg-editor-preview").textContent="Sua mensagem aparecerá aqui.";return;}
    fillMessage("#tg-route",r);$("#tg-route-uploads").checked=!!r.notify_uploads;$("#tg-route-scheduled").checked=!!r.notify_scheduled;routePreview();
  }
  function routePreview(){if(selectedRoute())showPreview($("#tg-editor-preview"),{...formMessage("#tg-route"),channel_id:t.editor.channel.channel_id});}
  $("#tg-route-add").addEventListener("click",()=>{const d=t.destinations.find(x=>x.id===Number($("#tg-route-add-select").value));if(!d)return;flushRoute();const model=t.templates[0];t.editor.destinations.push({...model,...d,destination_id:d.id,destination_active:d.active,active:true,notify_uploads:true,notify_scheduled:true});t.selected=d.id;t.dirty=true;renderRoutes();fillRoute();});
  $("#tg-route-list").addEventListener("click",e=>{const select=e.target.closest("[data-tg-select-route]"),remove=e.target.closest("[data-tg-remove-route]");if(select){flushRoute();t.selected=Number(select.dataset.tgSelectRoute);renderRoutes();fillRoute();}else if(remove){flushRoute();const did=Number(remove.dataset.tgRemoveRoute);t.editor.destinations=t.editor.destinations.filter(r=>r.destination_id!==did);if(t.selected===did)t.selected=t.editor.destinations[0]?.destination_id??null;t.dirty=true;renderRoutes();fillRoute();}});
  $("#tg-route-list").addEventListener("change",e=>{if(e.target.dataset.tgRouteActive){const r=t.editor.destinations.find(x=>x.destination_id===Number(e.target.dataset.tgRouteActive));r.active=e.target.checked;t.dirty=true;}});
  let previewTimer;
  $("#tg-editor-form").addEventListener("input",()=>{t.dirty=true;clearTimeout(previewTimer);previewTimer=setTimeout(routePreview,250);});
  $("#tg-apply-template").addEventListener("click",()=>{const model=t.templates.find(x=>x.id===Number($("#tg-route-template").value));if(model&&selectedRoute()){fillMessage("#tg-route",model);flushRoute();t.dirty=true;routePreview();}});
  $("#tg-editor-form").addEventListener("submit",e=>{e.preventDefault();action(e.target.querySelector('button[type="submit"]'),async()=>{flushRoute();await api(endpoint+"/channels/"+encodeURIComponent(t.editor.channel.channel_id),"PUT",{revision:t.editor.revision,active:$("#tg-channel-active").checked,destinations:t.editor.destinations.map(r=>({destination_id:r.destination_id,active:!!r.active,content:r.content,parse_mode:r.parse_mode,preview:!!r.preview,silent:!!r.silent,notify_uploads:!!r.notify_uploads,notify_scheduled:!!r.notify_scheduled}))});t.dirty=false;closeDialog("tg-editor");toast("Mensagens e destinos do Telegram salvos.");await load("tg-channels");},$("#tg-editor-error"));});
  $("#tg-test-draft").addEventListener("click",e=>action(e.currentTarget,async()=>{const r=selectedRoute();if(!r||!confirm(`Enviar esta mensagem de teste para ${r.name}? O rascunho será usado mesmo antes de salvar.`))return;await api(endpoint+"/tests","POST",{...formMessage("#tg-route"),destination_id:r.destination_id,channel_id:t.editor.channel.channel_id});toast("Teste na fila. Veja o resultado em Entregas e logs do Telegram.");},$("#tg-editor-error")));
  function selectTemplate(){const model=t.templates.find(x=>x.id===Number($("#tg-template-select").value));if(!model)return;$("#tg-template-name").value=model.name;fillMessage("#tg-template",model);templatePreview();}
  function templatePreview(){showPreview($("#tg-template-render"),formMessage("#tg-template"));}
  $("#tg-template-select").addEventListener("change",selectTemplate);
  let templateTimer;$("#tg-template-form").addEventListener("input",()=>{clearTimeout(templateTimer);templateTimer=setTimeout(templatePreview,250);});
  async function saveTemplate(copy){const data={...formMessage("#tg-template"),name:$("#tg-template-name").value};if(copy)data.name=(data.name+" · cópia").slice(0,80);const result=await api(endpoint+"/templates"+(copy?"":"/"+$("#tg-template-select").value),copy?"POST":"PATCH",data);toast("Modelo salvo.");await load("tg-messages");if(copy){$("#tg-template-select").value=result.id;selectTemplate();}}
  $("#tg-template-form").addEventListener("submit",e=>{e.preventDefault();action(e.target.querySelector("button.primary"),()=>saveTemplate(false));});
  $("#tg-template-copy").addEventListener("click",e=>action(e.currentTarget,()=>saveTemplate(true)));
  function renderHistory(){const labels={deliveries:"Entregas recentes",tests:"Testes por destino",logs:"Logs do Telegram"};$("#tg-history-title").textContent=labels[t.history];$("#tg-clear-history").textContent=t.history==="logs"?"Limpar logs":t.history==="tests"?"Limpar testes":"Limpar entregas";$("#tg-activity-tabs").querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",b.dataset.tgHistory===t.history));const rows=t.activity?.[t.history]||[];
    $("#tg-history-list").innerHTML=rows.length?rows.map(r=>t.history==="logs"?`<div class="tg-history-row"><div><small>${date(r.at)} · ${esc(r.level)}</small><p>${esc(r.message)}</p></div></div>`:`<div class="tg-history-row"><div><strong>${esc(r.destination_name)}</strong><p>${esc(r.title||"Teste de conexão e mensagem")}${r.channel_name?` · ${esc(r.channel_name)}`:""}</p><small>${date(r.created_at)} · ${r.attempts} tentativa(s)</small>${r.error?`<p class="error">${esc(r.error)}</p>`:""}</div><div class="actions">${statusPill(r.status)}${["failed","uncertain"].includes(r.status)?`<button class="outline small" data-tg-retry="${r.id}">Tentar novamente</button>`:""}</div></div>`).join(""):empty("Nenhum registro neste histórico.");
  }
  $("#tg-activity-tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tg-history]");if(b){t.history=b.dataset.tgHistory;renderHistory();}});
  $("#tg-clear-history").addEventListener("click",e=>action(e.currentTarget,async()=>{if(!confirm("Limpar todos os registros finalizados deste histórico? Os envios na fila permanecem. Mensagens já recebidas no Telegram não são apagadas."))return;const r=await api(endpoint+"/activity/"+t.history,"DELETE");toast(`${r.cleared} registro(s) limpo(s).`);await load("tg-activity");}));
  $("#tg-history-list").addEventListener("click",e=>{const b=e.target.closest("[data-tg-retry]");if(b)action(b,async()=>{if(!confirm("Confira o Telegram antes de reenviar: uma entrega incerta pode já ter chegado. Deseja tentar novamente?"))return;await api(endpoint+"/deliveries/"+b.dataset.tgRetry+"/retry","POST",{confirm_uncertain:true});await load("tg-activity");});});
  return{names,descriptions,load};
})();
