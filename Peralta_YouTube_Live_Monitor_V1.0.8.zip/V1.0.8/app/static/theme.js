/* Apply the saved theme before the stylesheet paints. No external resources. */
"use strict";
(() => {
  const key = "peralta-monitor-theme";
  const root = document.documentElement;
  let saved;
  try { saved = localStorage.getItem(key); } catch (_) {}
  function apply(theme) {
    root.dataset.theme = theme === "light" ? "light" : "dark";
    const dark = root.dataset.theme === "dark";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#0b1120" : "#f3f6fb");
    document.querySelectorAll("[data-theme-toggle]").forEach(button => {
      button.setAttribute("aria-label", dark ? "Ativar modo claro" : "Ativar modo escuro");
      button.title = dark ? "Mudar para modo claro" : "Mudar para modo escuro";
      button.querySelector("[data-theme-label]").textContent = dark ? "Modo claro" : "Modo escuro";
    });
  }
  apply(saved);
  document.addEventListener("DOMContentLoaded", () => {
    apply(root.dataset.theme);
    document.querySelectorAll("[data-theme-toggle]").forEach(button => button.addEventListener("click", () => {
      const theme = root.dataset.theme === "dark" ? "light" : "dark";
      apply(theme);
      try { localStorage.setItem(key, theme); } catch (_) {}
    }));
  });
  window.addEventListener("storage", event => { if (event.key === key) apply(event.newValue); });
})();
