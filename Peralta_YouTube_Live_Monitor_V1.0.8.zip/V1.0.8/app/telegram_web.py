"""Authenticated panel endpoints for Telegram. Discord editors remain separate."""
import json
import re
import time
from contextlib import closing

from fastapi import APIRouter, Depends, HTTPException, Request

from . import api_keys, db, telegram as tg, youtube
from .channel_editor import boolean
from .telegram_store import refresh_monitoring


def fail(message, code=400):
    raise HTTPException(code, message)


def fields(data):
    try:
        return tg.message_fields(data)
    except (ValueError, TypeError) as exc:
        fail(str(exc))


def channel_config(cid, con=None):
    if con is None:
        with closing(db.connect()) as conn:
            return channel_config(cid, conn)
    row = con.execute('SELECT y.channel_id,y.name,y.thumbnail,y.last_poll,y.last_error,t.active,t.revision '
                      'FROM telegram_channels t JOIN youtube_channels y ON y.channel_id=t.youtube_channel_id '
                      'WHERE t.youtube_channel_id=?', (cid,)).fetchone()
    if not row:
        fail('Canal não cadastrado no Telegram', 404)
    return {'channel': dict(row), 'destinations': tg.destinations(con, cid), 'revision': row['revision']}


def cancel(con, clause='1=1', args=(), reason='Configuração Telegram alterada'):
    con.execute("UPDATE telegram_deliveries SET status='skipped',error=?,updated_at=? WHERE status='pending' AND " + clause,
                (reason, db.ts(), *args))


async def verify_destination(chat_id, cfg):
    try:
        chat = await tg.call(tg.token_of(cfg), 'getChat', {'chat_id': chat_id})
        if not isinstance(chat, dict) or chat.get('type') not in ('channel', 'group', 'supergroup'):
            fail('Para o privado, abra Meu privado e inicie o bot com a conta do administrador.')
        member = await tg.call(tg.token_of(cfg), 'getChatMember', {'chat_id': chat['id'], 'user_id': cfg['bot_id']})
        if member.get('status') not in ('administrator', 'creator'):
            fail('Adicione o bot como administrador deste canal ou grupo.')
        if chat['type'] == 'channel' and member.get('status') != 'creator' and not member.get('can_post_messages'):
            fail('Ative a permissão de publicar mensagens para o bot neste canal.')
        return {'chat_id': str(chat['id']), 'kind': chat['type'], 'name': str(chat.get('title') or chat['id'])[:120],
                'username': str(chat.get('username') or '')[:64]}
    except tg.TelegramError as exc:
        fail(str(exc))


def sample_video(cid=None):
    video = db.one('SELECT v.*,y.name AS channel_name FROM videos v JOIN youtube_channels y ON y.channel_id=v.channel_id '
                   'WHERE v.channel_id=? ORDER BY v.first_seen DESC LIMIT 1', (cid,)) if cid else None
    channel = db.one('SELECT name FROM youtube_channels WHERE channel_id=?', (cid,)) if cid else None
    return video or {'video_id': 'EXEMPLO', 'title': 'Prévia de uma nova publicação',
                     'channel_name': channel['name'] if channel else 'Meu canal', 'kind': 'upload',
                     'url': 'https://www.youtube.com/watch?v=EXEMPLO'}


def preview(data):
    try:
        return tg.render(fields(data), sample_video(data.get('channel_id')))
    except ValueError as exc:
        fail(str(exc))


def save_channel(cid, data):
    with db.transaction() as con:
        old = channel_config(cid, con)
        if data.get('revision') != old['revision']:
            fail('O canal mudou. Reabra a edição para carregar a configuração atual.', 409)
        active = boolean(data, 'active', old['channel']['active'])
        raw = data.get('destinations')
        if not isinstance(raw, list) or len(raw) > 100:
            fail('Escolha até 100 destinos por canal.')
        cfg = dict(con.execute('SELECT * FROM telegram_config WHERE id=1').fetchone())
        previous = {r['destination_id']: r for r in old['destinations']}
        seen, prepared = set(), []
        for item in raw:
            if not isinstance(item, dict):
                fail('Destino inválido')
            try:
                did = int(item.get('destination_id'))
            except (ValueError, TypeError):
                fail('Destino inválido')
            if did in seen:
                fail('Destino repetido')
            seen.add(did)
            dest = con.execute('SELECT * FROM telegram_destinations WHERE id=?', (did,)).fetchone()
            if not dest:
                fail('Destino removido. Reabra a edição.')
            enabled = boolean(item, 'active', True)
            before = previous.get(did)
            enabling = enabled and (not before or not before['active'] or (active and not old['channel']['active']))
            # Existing broken targets remain editable; a newly enabled route must be verified.
            if enabling and (not dest['verified'] or dest['bot_id'] != cfg['bot_id'] or
                             (dest['kind'] == 'private' and not (dest['chat_id'] == cfg['admin_id'] == cfg['private_chat_id']))):
                fail('Verifique o destino ou inicie o privado autorizado antes de ativá-lo.')
            after = time.time() if enabling or not before else before['notify_after']
            message = fields(item)
            prepared.append((cid, did, enabled, message['content'], message['parse_mode'], message['preview'],
                             message['silent'], boolean(item, 'notify_uploads', True),
                             boolean(item, 'notify_scheduled', True), after))
        con.execute('DELETE FROM telegram_routes WHERE youtube_channel_id=?', (cid,))
        con.executemany('INSERT INTO telegram_routes(youtube_channel_id,destination_id,active,content,parse_mode,preview,'
                        'silent,notify_uploads,notify_scheduled,notify_after) VALUES(?,?,?,?,?,?,?,?,?,?)', prepared)
        con.execute('UPDATE telegram_channels SET active=?,revision=revision+1 WHERE youtube_channel_id=?', (active, cid))
        cancel(con, 'youtube_channel_id=? AND (?=0 OR destination_id NOT IN '
                    '(SELECT destination_id FROM telegram_routes WHERE youtube_channel_id=? AND active=1))', (cid, active, cid))
        refresh_monitoring(con, cid)
        result = channel_config(cid, con)
    db.log('telegram', 'info', f'Avisos de {cid} salvos: {len(prepared)} destino(s)')
    return result


def build_router(auth, body):
    router = APIRouter(dependencies=[Depends(auth)])

    @router.get('/api/global-channels')
    def global_channels():
        rows = db.rows('SELECT y.channel_id,y.name,y.thumbnail,y.active,y.last_poll,y.last_error,y.discord_enabled,'
                       'y.discord_active,t.active AS telegram_active FROM youtube_channels y LEFT JOIN telegram_channels t '
                       'ON t.youtube_channel_id=y.channel_id WHERE y.removed=0 ORDER BY y.name')
        interval = int(db.setting('playlist_interval', '300'))
        return [{**r, 'next_poll': (r['last_poll'] + interval if r['last_poll'] else db.ts()) if r['active'] else None} for r in rows]

    @router.get('/api/telegram/config')
    def get_config():
        return tg.public_config()

    @router.put('/api/telegram/config')
    async def set_config(request: Request):
        data = await body(request)
        old = tg.config()
        if data.get('revision') != old['revision']:
            fail('Configuração alterada. Atualize a página antes de salvar.', 409)
        admin = str(data.get('admin_id', '')).strip()
        username = str(data.get('admin_username', '')).strip().lstrip('@')
        token = str(data.get('token', '')).strip()
        enabled = boolean(data, 'enabled', old['enabled'])
        if not re.fullmatch(r'[1-9][0-9]{0,19}', admin):
            fail('Informe o ID numérico positivo do administrador do Telegram.')
        if username and not re.fullmatch(r'[A-Za-z0-9_]{1,32}', username):
            fail('Informe seu usuário do Telegram, com ou sem @; deixe vazio se não tiver usuário.')
        if token and not re.fullmatch(r'[0-9]{4,20}:[A-Za-z0-9_-]{20,150}', token):
            fail('Formato de token inválido. Copie o token completo fornecido pelo BotFather.')
        if not token and not old['encrypted_token']:
            fail('Informe o token do bot do Telegram.')
        try:
            credential = token or tg.token_of(old)
            identity = await tg.call(credential, 'getMe')
            if not isinstance(identity, dict) or not identity.get('is_bot') or not identity.get('username'):
                fail('O Telegram não confirmou a identidade do bot.')
            webhook = await tg.call(credential, 'getWebhookInfo')
            if webhook.get('url'):
                fail('Este bot usa webhook em outro serviço. Use um bot exclusivo para o monitor ou desative esse webhook no serviço de origem.')
        except tg.TelegramError as exc:
            fail(str(exc))
        changed_bot = str(identity['id']) != old['bot_id']
        changed_owner = admin != old['admin_id']
        with db.transaction() as con:
            current = con.execute('SELECT revision FROM telegram_config WHERE id=1').fetchone()
            if current['revision'] != old['revision']:
                fail('Configuração alterada durante a validação. Atualize a página.', 409)
            if changed_bot or not enabled:
                cancel(con)
            if changed_bot:
                con.execute("UPDATE telegram_destinations SET verified=0,last_error='Verifique o destino com o novo bot'")
            if changed_owner or changed_bot:
                cancel(con, "destination_id IN (SELECT id FROM telegram_destinations WHERE kind='private')")
                con.execute("UPDATE telegram_destinations SET verified=0 WHERE kind='private'")
                con.execute("UPDATE telegram_config SET private_chat_id='',private_verified_at=NULL WHERE id=1")
            if enabled and not old['enabled']:
                con.execute('UPDATE telegram_routes SET notify_after=?', (time.time(),))
            con.execute('UPDATE telegram_config SET encrypted_token=?,admin_id=?,admin_username=?,bot_id=?,bot_username=?,'
                        "bot_name=?,enabled=?,revision=revision+1,last_error='',last_checked=?,update_offset=? WHERE id=1",
                        (api_keys.encrypt(credential), admin, username, str(identity['id']), str(identity['username'])[:64],
                         str(identity.get('first_name') or '')[:100], enabled, db.ts(), 0 if changed_bot else old['update_offset']))
        db.log('telegram', 'info', 'Bot e administrador configurados pelo painel')
        return tg.public_config()

    @router.get('/api/telegram/destinations')
    def get_destinations():
        return db.rows('SELECT * FROM telegram_destinations ORDER BY kind,name')

    @router.post('/api/telegram/destinations')
    async def add_destination(request: Request):
        data, cfg = await body(request), tg.config()
        if not cfg['encrypted_token']:
            fail('Configure primeiro o bot e o administrador.')
        chat_id = str(data.get('chat_id', '')).strip()
        if not re.fullmatch(r'-[0-9]{1,20}|@[A-Za-z0-9_]{5,32}', chat_id):
            fail('Informe o ID negativo do canal/grupo ou o @usuário público.')
        target = await verify_destination(chat_id, cfg)
        with db.transaction() as con:
            current = con.execute('SELECT revision FROM telegram_config WHERE id=1').fetchone()
            if current['revision'] != cfg['revision']:
                fail('Bot alterado durante a validação. Tente novamente.', 409)
            old = con.execute('SELECT * FROM telegram_destinations WHERE chat_id=?', (target['chat_id'],)).fetchone()
            cutoff = old['notify_after'] if old and old['verified'] and old['bot_id'] == cfg['bot_id'] else time.time()
            con.execute('INSERT INTO telegram_destinations(chat_id,kind,name,username,bot_id,verified,notify_after,created_at) '
                        'VALUES(?,?,?,?,?,1,?,?) ON CONFLICT(chat_id) DO UPDATE SET kind=excluded.kind,name=excluded.name,'
                        "username=excluded.username,bot_id=excluded.bot_id,verified=1,notify_after=excluded.notify_after,last_error=''",
                        (target['chat_id'], target['kind'], target['name'], target['username'], cfg['bot_id'], cutoff, db.ts()))
        return db.one('SELECT * FROM telegram_destinations WHERE chat_id=?', (target['chat_id'],))

    @router.patch('/api/telegram/destinations/{did}')
    async def toggle_destination(did: int, request: Request):
        data = await body(request)
        active = boolean(data, 'active')
        with db.transaction() as con:
            dest = con.execute('SELECT * FROM telegram_destinations WHERE id=?', (did,)).fetchone()
            if not dest:
                fail('Destino não encontrado', 404)
            if active and not dest['verified']:
                fail('Verifique o destino antes de ativar.')
            con.execute('UPDATE telegram_destinations SET active=?,notify_after=CASE WHEN ?=1 AND active=0 THEN ? ELSE notify_after END WHERE id=?',
                        (active, active, time.time(), did))
            if not active:
                cancel(con, 'destination_id=?', (did,))
        return {'ok': True}

    @router.delete('/api/telegram/destinations/{did}')
    def remove_destination(did: int):
        with db.transaction() as con:
            dest = con.execute('SELECT * FROM telegram_destinations WHERE id=?', (did,)).fetchone()
            if not dest:
                fail('Destino não encontrado', 404)
            if dest['kind'] == 'private':
                fail('Para interromper o privado, pause o destino ou altere o administrador.')
            cancel(con, 'destination_id=?', (did,))
            con.execute('UPDATE telegram_channels SET revision=revision+1 WHERE youtube_channel_id IN '
                        '(SELECT youtube_channel_id FROM telegram_routes WHERE destination_id=?)', (did,))
            con.execute('DELETE FROM telegram_routes WHERE destination_id=?', (did,))
            con.execute('DELETE FROM telegram_destinations WHERE id=?', (did,))
        return {'ok': True}

    @router.get('/api/telegram/channels')
    def get_channels():
        return db.rows('SELECT y.channel_id,y.name,y.thumbnail,y.last_poll,y.last_error,t.active,t.revision,'
                       '(SELECT COUNT(*) FROM telegram_routes r WHERE r.youtube_channel_id=y.channel_id) AS destinations '
                       'FROM telegram_channels t JOIN youtube_channels y ON y.channel_id=t.youtube_channel_id ORDER BY y.name')

    @router.post('/api/telegram/channels')
    async def add_channel(request: Request):
        data = await body(request)
        cid = str(data.get('channel_id', '')).strip()
        if not re.fullmatch(r'UC[A-Za-z0-9_-]{22}', cid):
            fail('Informe um Channel ID UC válido (24 caracteres).')
        try:
            await youtube.register_channel(cid, platform='telegram')
        except youtube.YouTubeError as exc:
            fail(str(exc))
        return channel_config(cid)

    @router.get('/api/telegram/channels/{cid}')
    def get_channel(cid: str):
        return channel_config(cid)

    @router.put('/api/telegram/channels/{cid}')
    async def put_channel(cid: str, request: Request):
        return save_channel(cid, await body(request))

    @router.delete('/api/telegram/channels/{cid}')
    def remove_channel(cid: str):
        with db.transaction() as con:
            channel_config(cid, con)
            cancel(con, 'youtube_channel_id=?', (cid,))
            con.execute('DELETE FROM telegram_routes WHERE youtube_channel_id=?', (cid,))
            con.execute('DELETE FROM telegram_channels WHERE youtube_channel_id=?', (cid,))
            refresh_monitoring(con, cid)
        return {'ok': True}

    @router.get('/api/telegram/templates')
    def get_templates():
        return db.rows('SELECT * FROM telegram_templates ORDER BY id')

    @router.post('/api/telegram/templates')
    async def create_template(request: Request):
        data = await body(request)
        message = fields(data)
        name = str(data.get('name', '')).strip()
        if not name or len(name) > 80:
            fail('Informe um nome de até 80 caracteres.')
        with db.transaction() as con:
            cur = con.execute('INSERT INTO telegram_templates(name,content,parse_mode,preview,silent) VALUES(?,?,?,?,?)',
                              (name, message['content'], message['parse_mode'], message['preview'], message['silent']))
            return {'id': cur.lastrowid}

    @router.patch('/api/telegram/templates/{tid}')
    async def edit_template(tid: int, request: Request):
        data = await body(request)
        message = fields(data)
        name = str(data.get('name', '')).strip()
        if not name or len(name) > 80:
            fail('Informe um nome de até 80 caracteres.')
        if not db.write('UPDATE telegram_templates SET name=?,content=?,parse_mode=?,preview=?,silent=? WHERE id=?',
                        (name, message['content'], message['parse_mode'], message['preview'], message['silent'], tid)):
            fail('Modelo não encontrado', 404)
        return {'ok': True}

    @router.post('/api/telegram/preview')
    async def message_preview(request: Request):
        return preview(await body(request))

    @router.post('/api/telegram/tests')
    async def send_test(request: Request):
        data = await body(request)
        rendered = preview(data)
        # A test is explicit, independent of whether a YouTube source is paused.
        with db.transaction() as con:
            cfg = dict(con.execute('SELECT * FROM telegram_config WHERE id=1').fetchone())
            dest = con.execute('SELECT * FROM telegram_destinations WHERE id=?', (str(data.get('destination_id', '')),)).fetchone()
            if not dest or not tg.eligible(cfg, dict(dest)):
                fail('Ative o Telegram e escolha um destino verificado e autorizado.')
            rendered['payload']['text'] = '[TESTE DO PAINEL]\n' + rendered['payload']['text']
            # Reserve space for the test prefix within Telegram's limit.
            if len(rendered['text'].encode('utf-16-le')) // 2 > 4077:
                fail('Encurte a mensagem para enviar o teste.')
            cur = con.execute('INSERT INTO telegram_deliveries(destination_id,recipient_chat_id,bot_id,payload,next_try,created_at,updated_at) '
                              'VALUES(?,?,?,?,?,?,?)', (dest['id'], dest['chat_id'], cfg['bot_id'], json.dumps(rendered['payload']), db.ts(), db.ts(), db.ts()))
            return {'id': cur.lastrowid, 'status': 'pending'}

    @router.get('/api/telegram/activity')
    def activity():
        base = ('SELECT q.id,q.video_id,q.status,q.attempts,q.next_try,q.message_id,q.error,q.created_at,'
                "COALESCE(d.name,q.recipient_chat_id) AS destination_name,v.title,y.name AS channel_name "
                'FROM telegram_deliveries q LEFT JOIN telegram_destinations d ON d.id=q.destination_id '
                'LEFT JOIN videos v ON v.video_id=q.video_id LEFT JOIN youtube_channels y ON y.channel_id=q.youtube_channel_id '
                'WHERE q.history_hidden=0 AND ')
        return {'deliveries': db.rows(base + 'q.video_id IS NOT NULL ORDER BY q.id DESC LIMIT 100'),
                'tests': db.rows(base + 'q.video_id IS NULL ORDER BY q.id DESC LIMIT 100'),
                'logs': db.rows("SELECT * FROM logs WHERE service='telegram' ORDER BY id DESC LIMIT 100")}

    @router.delete('/api/telegram/activity/{kind}')
    def clear_activity(kind: str):
        if kind == 'logs':
            n = db.write("DELETE FROM logs WHERE service='telegram'")
        elif kind in ('tests', 'deliveries'):
            clause = 'video_id IS NULL' if kind == 'tests' else 'video_id IS NOT NULL'
            n = db.write("UPDATE telegram_deliveries SET history_hidden=1 WHERE history_hidden=0 AND status NOT IN ('pending','sending') AND " + clause)
        else:
            fail('Histórico inválido', 404)
        return {'ok': True, 'cleared': n}

    @router.post('/api/telegram/deliveries/{did}/retry')
    async def retry(did: int, request: Request):
        data = await body(request)
        item = db.one('SELECT * FROM telegram_deliveries WHERE id=?', (did,))
        if not item or item['status'] not in ('failed', 'uncertain'):
            fail('Este envio não está disponível para nova tentativa.')
        if item['status'] == 'uncertain' and data.get('confirm_uncertain') is not True:
            fail('Confirme antes: um envio incerto pode já ter chegado ao destino.')
        try:
            context = tg.delivery_context(item)
        except (ValueError, tg.TelegramError):
            context = None
        if not context:
            fail('O destino ou a autorização mudou. Envie um novo teste com a configuração atual.')
        n = db.write("UPDATE telegram_deliveries SET status='pending',attempts=0,next_try=?,error='',history_hidden=0,updated_at=? "
                     "WHERE id=? AND status IN ('failed','uncertain')", (db.ts(), db.ts(), did))
        return {'ok': bool(n)}

    return router
