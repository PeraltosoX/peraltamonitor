"""Backup consistente do SQLite em execução: python -m scripts.backup DESTINO.sqlite3"""
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

from app.config import DB_PATH


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python -m scripts.backup /data/backup/monitor-AAAAMMDD.sqlite3")
    target = Path(sys.argv[1]).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target == DB_PATH.resolve():
        raise SystemExit("Destino deve ser diferente do banco em uso")
    if not DB_PATH.is_file():
        raise SystemExit("Banco de origem não encontrado; backup cancelado")
    if target.exists():
        raise SystemExit("Já existe um arquivo neste destino; escolha outro nome para preservar o backup")
    with closing(sqlite3.connect(DB_PATH.resolve().as_uri() + "?mode=ro", uri=True)) as source, closing(sqlite3.connect(target)) as backup:
        source.backup(backup)
        if backup.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise SystemExit("Falha de integridade no backup; não prossiga com a atualização")
    target.chmod(0o600)
    print(f"Backup: {target}")


if __name__ == "__main__":
    main()
