CREATE TABLE api_credentials (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, project_id TEXT NOT NULL DEFAULT '',
            encrypted_key TEXT, last4 TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 0,
            primary_flag INTEGER NOT NULL DEFAULT 0, quota_limit INTEGER NOT NULL DEFAULT 10000,
            priority INTEGER NOT NULL DEFAULT 100, retry_after INTEGER NOT NULL DEFAULT 0,
            last_used INTEGER, last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
        );

CREATE TABLE api_key_usage (
            day TEXT NOT NULL, credential_id INTEGER NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL, PRIMARY KEY(day, credential_id)
        );

CREATE TABLE api_usage (
            day TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
        );

CREATE TABLE channel_destinations (youtube_channel_id TEXT NOT NULL, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, template_id INTEGER, notify_uploads INTEGER, notify_scheduled INTEGER, mention_everyone INTEGER, notify_after REAL NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, PRIMARY KEY(youtube_channel_id,guild_id,channel_id), FOREIGN KEY(youtube_channel_id) REFERENCES youtube_channels(channel_id), FOREIGN KEY(guild_id) REFERENCES guilds(guild_id));

CREATE TABLE "deliveries" (id INTEGER PRIMARY KEY AUTOINCREMENT, video_id TEXT NOT NULL, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_try INTEGER NOT NULL, message_id TEXT, error TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, UNIQUE(video_id,guild_id,channel_id,kind));

CREATE TABLE discord_channels (
            channel_id TEXT PRIMARY KEY, guild_id TEXT NOT NULL, name TEXT NOT NULL,
            can_view INTEGER NOT NULL, can_send INTEGER NOT NULL, can_embed INTEGER NOT NULL,
            can_mention INTEGER NOT NULL, last_seen INTEGER NOT NULL,
            FOREIGN KEY(guild_id) REFERENCES guilds(guild_id)
        );

CREATE TABLE guild_destinations (
            guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, created_at INTEGER NOT NULL,
            PRIMARY KEY(guild_id,channel_id), FOREIGN KEY(guild_id) REFERENCES guilds(guild_id)
        );

CREATE TABLE guilds (
            guild_id TEXT PRIMARY KEY, name TEXT NOT NULL, present INTEGER NOT NULL DEFAULT 1,
            active INTEGER NOT NULL DEFAULT 0, owner_verified INTEGER NOT NULL DEFAULT 0,
            notify_uploads INTEGER NOT NULL DEFAULT 1,
            notify_scheduled INTEGER NOT NULL DEFAULT 1, mention_everyone INTEGER NOT NULL DEFAULT 0,
            target_channel_id TEXT, template_id INTEGER NOT NULL DEFAULT 1, last_seen INTEGER NOT NULL
        );

CREATE TABLE logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
            service TEXT NOT NULL, level TEXT NOT NULL, message TEXT NOT NULL
        );

CREATE TABLE oauth_states (
            state_hash TEXT PRIMARY KEY, session_id TEXT NOT NULL, expires_at INTEGER NOT NULL
        );

CREATE TABLE pending_video_ids (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, received_at INTEGER NOT NULL
        );

CREATE TABLE search_key_usage (
            day TEXT NOT NULL, credential_id INTEGER NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL, PRIMARY KEY(day, credential_id)
        );

CREATE TABLE search_usage (
            day TEXT PRIMARY KEY, calls INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
        );

CREATE TABLE seen_video_ids (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, first_seen INTEGER NOT NULL,
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );

CREATE TABLE service_heartbeats (
            service TEXT PRIMARY KEY, at INTEGER NOT NULL, detail TEXT NOT NULL DEFAULT ''
        );

CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE subscriptions (
            guild_id TEXT NOT NULL, channel_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
            notify_after REAL NOT NULL DEFAULT 0,
            PRIMARY KEY(guild_id, channel_id),
            FOREIGN KEY(guild_id) REFERENCES guilds(guild_id),
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );

CREATE TABLE templates (
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, content TEXT NOT NULL,
            embed_title TEXT NOT NULL DEFAULT '', embed_description TEXT NOT NULL DEFAULT '',
            embed_footer TEXT NOT NULL DEFAULT '', embed_image TEXT NOT NULL DEFAULT '',
            embed_color INTEGER NOT NULL DEFAULT 15086414,
            preview_mode TEXT NOT NULL DEFAULT 'youtube'
        , owner_channel_id TEXT);

CREATE TABLE test_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending', message_id TEXT, error TEXT,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        , payload TEXT, youtube_channel_id TEXT);

CREATE TABLE videos (
            video_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, title TEXT NOT NULL,
            url TEXT NOT NULL, thumbnail TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL,
            live_state TEXT NOT NULL, scheduled_at TEXT, published_at TEXT,
            seeded INTEGER NOT NULL DEFAULT 0, first_seen INTEGER NOT NULL,
            last_seen INTEGER NOT NULL,
            FOREIGN KEY(channel_id) REFERENCES youtube_channels(channel_id)
        );

CREATE TABLE youtube_channels (
            channel_id TEXT PRIMARY KEY, name TEXT NOT NULL, uploads_id TEXT NOT NULL,
            thumbnail TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
            baseline_done INTEGER NOT NULL DEFAULT 0, last_poll INTEGER,
            last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
        , last_upcoming_search INTEGER, ids_baseline_done INTEGER NOT NULL DEFAULT 0, removed INTEGER NOT NULL DEFAULT 0, last_new_count INTEGER NOT NULL DEFAULT 0, monitor_after REAL NOT NULL DEFAULT 0, routing_custom INTEGER NOT NULL DEFAULT 0, template_id INTEGER, config_revision INTEGER NOT NULL DEFAULT 0);

CREATE INDEX deliveries_due ON deliveries(status,next_try);

CREATE INDEX logs_at ON logs(at DESC);

CREATE INDEX seen_channel ON seen_video_ids(channel_id);

CREATE INDEX videos_channel ON videos(channel_id, first_seen DESC);
