"""Clearing a display must preserve the delivery ledger and live queues."""
import unittest
from datetime import datetime, timezone

import test_core as core
from fastapi.testclient import TestClient
from app import db, security, web, youtube


class ActivityHistoryTests(unittest.TestCase):
    def setUp(self):
        core.CoreTests.setUp(self)
        db.write("DELETE FROM logs")
        db.write("UPDATE youtube_channels SET baseline_done=1,ids_baseline_done=1")
        self.client = TestClient(web.app, base_url=core.ORIGIN)
        self.addCleanup(self.client.close)
        token = security.sign_session()
        self.client.cookies.set("plm_session", token, domain="peraltamonitor.peraltaultrachat.shop")
        self.headers = {"Origin": core.ORIGIN, "X-CSRF-Token": security.csrf_token(security.read_session(token))}

    def delivery(self, number, status):
        item = core.video(f"hist{number:07}", published=datetime.now(timezone.utc).isoformat())
        self.assertEqual(youtube.store_videos(core.CID, [item]), (1, 1))
        db.write("UPDATE deliveries SET status=? WHERE video_id=?", (status, item["id"]))
        return item

    def test_clear_deliveries_preserves_dedupe_counts_other_history_and_new_events(self):
        items = [self.delivery(n, status) for n, status in enumerate(
            ("sent", "failed", "uncertain", "skipped", "pending", "sending"))]
        db.log("worker", "info", "Keep this system log")
        db.write("INSERT INTO test_requests(guild_id,channel_id,status,created_at,updated_at) "
                 "VALUES('g','d','sent',1,1)")
        config = db.rows("SELECT * FROM youtube_channels")
        result = self.client.delete("/api/activity/deliveries", headers=self.headers)
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()["removed"], 4)
        data = self.client.get("/api/activity").json()
        self.assertEqual({d["status"] for d in data["deliveries"]}, {"pending", "sending"})
        self.assertEqual(len(data["tests"]), 1)
        self.assertEqual(len(data["logs"]), 1)
        self.assertEqual(self.client.get("/api/dashboard").json()["deliveries"], 1)
        self.assertEqual(db.rows("SELECT * FROM youtube_channels"), config)
        self.assertEqual(db.one("SELECT count(*) AS n FROM deliveries")["n"], 6)
        self.assertEqual(db.one("SELECT count(*) AS n FROM seen_video_ids")["n"], 6)
        self.assertEqual(youtube.store_videos(core.CID, items), (0, 0))
        self.assertEqual(self.client.delete("/api/activity/deliveries", headers=self.headers).json()["removed"], 0)
        db.init_db()  # Reloading the application does not bring cleared rows back.
        self.assertEqual(len(self.client.get("/api/activity").json()["deliveries"]), 2)
        self.delivery(9, "sent")
        self.assertEqual(len(self.client.get("/api/activity").json()["deliveries"]), 3)

    def test_pending_delivery_still_appears_when_it_finishes_after_clear(self):
        item = self.delivery(1, "pending")
        self.client.delete("/api/activity/deliveries", headers=self.headers)
        db.write("UPDATE deliveries SET status='sent' WHERE video_id=?", (item["id"],))
        data = self.client.get("/api/activity").json()["deliveries"]
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["status"], "sent")

    def test_clear_tests_preserves_queue_and_individual_status_without_payload(self):
        self.delivery(1, "sent")
        for status in ("sent", "failed", "pending", "sending"):
            db.write("INSERT INTO test_requests(guild_id,channel_id,status,payload,created_at,updated_at) "
                     "VALUES('g','d',?,'private draft',1,1)", (status,))
        sent_id = db.one("SELECT id FROM test_requests WHERE status='sent'")["id"]
        result = self.client.delete("/api/activity/tests", headers=self.headers)
        self.assertEqual(result.json()["removed"], 2)
        data = self.client.get("/api/activity").json()
        self.assertEqual({t["status"] for t in data["tests"]}, {"pending", "sending"})
        self.assertEqual(len(data["deliveries"]), 1)
        status = self.client.get(f"/api/test-requests/{sent_id}").json()
        self.assertEqual(status["status"], "sent")
        self.assertNotIn("payload", status)
        db.write("UPDATE test_requests SET status='sent' WHERE status='pending'")
        self.assertEqual(len(self.client.get("/api/activity").json()["tests"]), 2)
        self.assertEqual(self.client.get("/api/test-requests/999999").status_code, 404)

    def test_explicit_retry_restores_a_cleared_failure_to_the_queue_view(self):
        self.delivery(1, "failed")
        delivery_id = db.one("SELECT id FROM deliveries")["id"]
        self.client.delete("/api/activity/deliveries", headers=self.headers)
        self.assertEqual(self.client.get("/api/activity").json()["deliveries"], [])
        result = self.client.post(f"/api/deliveries/{delivery_id}/retry", headers=self.headers)
        self.assertEqual(result.status_code, 200)
        self.assertEqual(self.client.get("/api/activity").json()["deliveries"][0]["status"], "pending")

    def test_each_clear_action_requires_login_and_csrf(self):
        for path in ("/api/activity/deliveries", "/api/activity/tests", "/api/logs"):
            self.assertEqual(self.client.delete(path).status_code, 403)
            with TestClient(web.app, base_url=core.ORIGIN) as anonymous:
                self.assertEqual(anonymous.delete(path).status_code, 401)
        with TestClient(web.app, base_url=core.ORIGIN) as anonymous:
            self.assertEqual(anonymous.get("/api/test-requests/1").status_code, 401)
