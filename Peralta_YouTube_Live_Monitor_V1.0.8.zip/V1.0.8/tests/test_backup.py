import contextlib
import io
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import test_core as core
from scripts import backup


class BackupTests(unittest.TestCase):
    def test_backup_preserves_data_and_refuses_overwriting(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'source.sqlite3';target=Path(folder)/'copy.sqlite3'
            with sqlite3.connect(source) as con:
                con.execute('CREATE TABLE history(message TEXT)')
                con.execute("INSERT INTO history VALUES('preservado')")
            with patch.object(backup,'DB_PATH',source),patch('sys.argv',['backup',str(target)]),contextlib.redirect_stdout(io.StringIO()):
                backup.main()
                with sqlite3.connect(target) as con:
                    self.assertEqual(con.execute('SELECT message FROM history').fetchone()[0],'preservado')
                    self.assertEqual(con.execute('PRAGMA integrity_check').fetchone()[0],'ok')
                self.assertEqual(target.stat().st_mode & 0o777,0o600)
                with self.assertRaises(SystemExit):backup.main()

    def test_missing_database_does_not_create_empty_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'missing.sqlite3';target=Path(folder)/'backup.sqlite3'
            with patch.object(backup,'DB_PATH',source),patch('sys.argv',['backup',str(target)]):
                with self.assertRaises(SystemExit):backup.main()
            self.assertFalse(source.exists());self.assertFalse(target.exists())
