"""Regression tests for per-channel/per-destination configuration; no network."""
import asyncio
import copy
import json
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import patch

import test_core as core
from app import db, routing, channel_editor, youtube, bot, security, web
from fastapi.testclient import TestClient

G1 = '222222222222222222'
D1 = '333333333333333333'
G2 = '444444444444444444'
D2 = '555555555555555555'
OTHER = 'UC' + 'b' * 22


def fresh_video(vid, cid=core.CID, state='upcoming', age=0):
    value = core.video(vid, state, scheduled='2026-10-01T20:00:00Z',
                       published=(datetime.now(timezone.utc) + timedelta(seconds=age)).isoformat())
    value['snippet']['channelId'] = cid
    return value


class EditorTests(unittest.TestCase):
    def setUp(self):
        core.CoreTests.setUp(self)
        db.write('DELETE FROM templates WHERE id<>1')
        db.write("UPDATE templates SET name='Padrão',content='{everyone}{canal}: {titulo}\n{link}',"
                 "preview_mode='youtube',owner_channel_id=NULL WHERE id=1")
        db.write('UPDATE youtube_channels SET baseline_done=1,ids_baseline_done=1,monitor_after=1234')
        db.write("INSERT INTO guilds(guild_id,name,present,active,owner_verified,target_channel_id,last_seen) "
                 "VALUES(?, 'Servidor B',1,1,1,?,?)", (G2,D2,db.ts()))
        for gid,did in ((G1,D1),(G2,D2)):
            db.write('INSERT INTO discord_channels(channel_id,guild_id,name,can_view,can_send,can_embed,can_mention,last_seen) '
                     'VALUES(?,?,?,1,1,1,1,?)',(did,gid,'avisos',db.ts()))
        db.write('INSERT INTO guild_destinations(guild_id,channel_id,created_at) VALUES(?,?,?)',(G2,D2,db.ts()))
        db.write('INSERT INTO subscriptions(guild_id,channel_id,notify_after) VALUES(?,?,0)',(G2,core.CID))
        self.client = TestClient(web.app,base_url=core.ORIGIN)
        token=security.sign_session()
        self.client.cookies.set('plm_session',token,domain='peraltamonitor.peraltaultrachat.shop')
        self.headers={'Origin':core.ORIGIN,'X-CSRF-Token':security.csrf_token(security.read_session(token))}

    def tearDown(self):
        self.client.close()

    def draft(self,cid=core.CID):
        result=self.client.get(f'/api/youtube-channels/{cid}/configuration')
        self.assertEqual(result.status_code,200,result.text)
        c=result.json()
        return {'revision':c['revision'],'active':bool(c['channel']['active']),
                'template_mode':'existing' if c['channel']['template_id'] else 'inherit',
                'template_id':c['channel']['template_id'],
                'destinations':[{k:r[k] for k in ('guild_id','channel_id','active','template_id',
                                  'notify_uploads','notify_scheduled','mention_everyone')}
                                for r in c['destinations']]}

    def save(self,data,cid=core.CID):
        return self.client.put(f'/api/youtube-channels/{cid}/configuration',headers=self.headers,json=data)

    def test_unchanged_save_keeps_cutoffs_known_ids_pending_and_other_channels(self):
        db.write('INSERT INTO youtube_channels(channel_id,name,uploads_id,baseline_done,created_at) VALUES(?,?,?,1,?)',
                 (OTHER,'Outro','UUother',db.ts()))
        db.write('INSERT INTO subscriptions(guild_id,channel_id,notify_after) VALUES(?,?,987)',(G1,OTHER))
        youtube.store_videos(core.CID,[fresh_video('keep0000001')])
        before={t:db.rows(f'SELECT * FROM {t}') for t in ('deliveries','subscriptions','seen_video_ids','guilds')}
        data=self.draft();self.assertEqual(len(data['destinations']),2)
        response=self.save(data);self.assertEqual(response.status_code,200,response.text)
        for t,rows in before.items(): self.assertEqual(db.rows(f'SELECT * FROM {t}'),rows,t)
        self.assertEqual(db.one('SELECT monitor_after FROM youtube_channels WHERE channel_id=?',(core.CID,))['monitor_after'],1234)
        self.assertEqual(db.one('SELECT routing_custom FROM youtube_channels WHERE channel_id=?',(OTHER,))['routing_custom'],0)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('keep0000001')]),(0,0))

    def test_each_server_uses_its_own_copied_text_and_style(self):
        original=db.one('SELECT * FROM templates WHERE id=1')
        draft=self.draft()
        for r in draft['destinations']:
            letter='A' if r['guild_id']==G1 else 'B'
            r['template_mode']='copy'
            r['template']={**original,'name':f'Canal — {letter}','content':f'Mensagem {letter}: {{titulo}}\n{{link}}',
                           'preview_mode':'youtube' if letter=='A' else 'custom','embed_title':'Estilo B'}
        response=self.save(draft);self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(db.one('SELECT * FROM templates WHERE id=1'),original)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('different01')]),(1,2))
        sent={}
        class Destination:
            def __init__(self,id):self.id=id
            async def send(self,**kwargs):sent[self.id]=kwargs;return SimpleNamespace(id=42)
        client=bot.MonitorBot()
        async def destination(gid,did):return Destination(did),SimpleNamespace(embed_links=True,mention_everyone=True)
        client.get_destination=destination
        for item in db.rows('SELECT id FROM deliveries'):asyncio.run(client.send_delivery(item))
        self.assertIn('Mensagem A',sent[D1]['content']);self.assertNotIn('embed',sent[D1])
        self.assertIn('Mensagem B',sent[D2]['content']);self.assertEqual(sent[D2]['embed'].title,'Estilo B')
        self.assertTrue(all(d['status']=='sent' for d in db.rows('SELECT status FROM deliveries')))

    def test_new_destination_on_one_channel_does_not_expand_other_legacy_channels(self):
        extra='666666666666666666'
        db.write('INSERT INTO youtube_channels(channel_id,name,uploads_id,baseline_done,created_at) VALUES(?,?,?,1,?)',
                 (OTHER,'Outro','UUother',db.ts()))
        db.write('INSERT INTO subscriptions(guild_id,channel_id,notify_after) VALUES(?,?,0)',(G1,OTHER))
        db.write('INSERT INTO discord_channels(channel_id,guild_id,name,can_view,can_send,can_embed,can_mention,last_seen) '
                 'VALUES(?,?,?,1,1,1,1,?)',(extra,G1,'exclusivo',db.ts()))
        draft=self.draft()
        draft['destinations'].append({**next(r for r in draft['destinations'] if r['guild_id']==G1),'channel_id':extra})
        self.assertEqual(self.save(draft).status_code,200)
        self.assertEqual({r['channel_id'] for r in routing.configuration(OTHER)['destinations']},{D1})
        self.assertEqual(youtube.store_videos(OTHER,[fresh_video('otherdest01',cid=OTHER)]),(1,1))
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('specific001',age=1)]),(1,3))
        removed=self.client.delete(f'/api/guilds/{G1}/destinations/{D1}',headers=self.headers)
        self.assertEqual(removed.status_code,200,removed.text)
        self.assertEqual(db.one('SELECT active FROM guilds WHERE guild_id=?',(G1,))['active'],1)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('specific002',age=2)]),(1,2))

    def test_pause_one_destination_does_not_cancel_others_and_resume_has_new_cutoff(self):
        youtube.store_videos(core.CID,[fresh_video('pause000001')])
        draft=self.draft()
        next(r for r in draft['destinations'] if r['channel_id']==D1)['active']=False
        response=self.save(draft);self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(db.one('SELECT status FROM deliveries WHERE channel_id=?',(D1,))['status'],'skipped')
        self.assertEqual(db.one('SELECT status FROM deliveries WHERE channel_id=?',(D2,))['status'],'pending')
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('pause000002')]),(1,1))
        draft=self.draft();next(r for r in draft['destinations'] if r['channel_id']==D1)['active']=True
        self.assertEqual(self.save(draft).status_code,200)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('pause000003',age=-20)]),(1,1))
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('pause000004',age=1)]),(1,2))

    def test_invalid_save_rolls_back_copy_and_rejects_stale_revision(self):
        draft=self.draft();old=copy.deepcopy(draft)
        draft['template_mode']='copy';draft['template']={**db.one('SELECT * FROM templates WHERE id=1'),'name':'Cópia'}
        draft['destinations'][0]['channel_id']='999999999999999999'
        self.assertEqual(self.save(draft).status_code,400)
        self.assertEqual(db.one('SELECT COUNT(*) AS n FROM templates')['n'],1)
        self.assertEqual(self.draft(),old)
        self.assertEqual(self.save(old).status_code,200)
        self.assertEqual(self.save(old).status_code,409)

    def test_shared_copy_never_overwrites_a_model_used_elsewhere(self):
        template=db.one('SELECT * FROM templates WHERE id=1')
        draft=self.draft();draft['template_mode']='copy';draft['template']={**template,'name':'Canal','content':'Inicial {link}'}
        self.assertEqual(self.save(draft).status_code,200)
        tid=db.one('SELECT template_id FROM youtube_channels WHERE channel_id=?',(core.CID,))['template_id']
        db.write('INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at,template_id) VALUES(?,?,?,?,?)',
                 (OTHER,'Outro','UUother',db.ts(),tid))
        draft=self.draft();draft['template_mode']='copy';draft['template']={**template,'name':'Canal','content':'Alterado {link}'}
        self.assertEqual(self.save(draft).status_code,200)
        self.assertEqual(db.one('SELECT content FROM templates WHERE id=?',(tid,))['content'],'Inicial {link}')
        self.assertNotEqual(db.one('SELECT template_id FROM youtube_channels WHERE channel_id=?',(core.CID,))['template_id'],tid)

    def test_test_message_uses_draft_style_and_suppresses_all_mentions(self):
        template={**db.one('SELECT * FROM templates WHERE id=1'),'name':'Teste','content':'@everyone @here {everyone} mensagem {link}',
                  'preview_mode':'custom','embed_title':'Prévia exclusiva'}
        data={'guild_id':G1,'channel_id':D1,'template_mode':'inherit',
              'destination_template_mode':'copy','destination_template':template,'mention_everyone':True}
        response=self.client.post(f'/api/youtube-channels/{core.CID}/test',headers=self.headers,json=data)
        self.assertEqual(response.status_code,200,response.text)
        item=db.one('SELECT * FROM test_requests WHERE id=?',(response.json()['id'],))
        sent=[]
        class Destination:
            async def send(self,**kwargs):sent.append(kwargs);return SimpleNamespace(id=123)
        client=bot.MonitorBot()
        async def destination(gid,did):return Destination(),SimpleNamespace(embed_links=True)
        client.get_destination=destination;asyncio.run(client.send_test(item))
        self.assertNotIn('@everyone',sent[0]['content']);self.assertNotIn('@here',sent[0]['content'])
        self.assertFalse(sent[0]['allowed_mentions'].everyone);self.assertFalse(sent[0]['allowed_mentions'].users)
        self.assertFalse(sent[0]['allowed_mentions'].roles);self.assertEqual(sent[0]['embed'].title,'Prévia exclusiva')
        self.assertEqual(db.one('SELECT COUNT(*) AS n FROM templates')['n'],1)
        db.write('UPDATE guilds SET owner_verified=0 WHERE guild_id=?',(G1,))
        response=self.client.post(f'/api/youtube-channels/{core.CID}/test',headers=self.headers,json=data)
        self.assertEqual(response.status_code,400)

    def test_preserved_paused_association_does_not_resume_on_save(self):
        db.write('UPDATE subscriptions SET active=0 WHERE guild_id=?',(G1,))
        self.assertEqual(self.save(self.draft()).status_code,200)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('pausedassoc')]),(1,1))
        self.assertEqual(db.one('SELECT channel_id FROM deliveries')['channel_id'],D2)

    def test_default_server_edit_stays_live_for_unedited_channels(self):
        draft=self.draft()
        db.write('UPDATE guilds SET notify_scheduled=0 WHERE guild_id=?',(G1,))
        self.assertEqual(self.save(draft).status_code,409)
        self.assertEqual(youtube.store_videos(core.CID,[fresh_video('oldsettings')]),(1,1))
        self.assertEqual(db.one('SELECT channel_id FROM deliveries')['channel_id'],D2)

    def test_quota_is_by_youtube_channel_not_number_of_destinations(self):
        r=self.client.get('/api/quota-preview?interval=300');self.assertEqual(r.status_code,200)
        self.assertEqual(r.json()['playlist_units_per_day'],288)
        self.assertEqual(self.client.get('/api/quota-preview?interval=29').status_code,400)
        db.write('UPDATE youtube_channels SET active=0')
        self.assertEqual(self.client.get('/api/quota-preview?interval=300').json()['playlist_units_per_day'],0)

    def test_editor_endpoints_need_session_and_csrf(self):
        with TestClient(web.app,base_url=core.ORIGIN) as client:
            self.assertEqual(client.get('/api/channel-editor').status_code,401)
            self.assertEqual(client.get(f'/api/youtube-channels/{core.CID}/configuration').status_code,401)
        self.assertEqual(self.client.put(f'/api/youtube-channels/{core.CID}/configuration',json=self.draft()).status_code,403)

    def test_legacy_removal_cancels_only_that_destination_after_customization(self):
        self.assertEqual(self.save(self.draft()).status_code,200)
        youtube.store_videos(core.CID,[fresh_video('custom00001')])
        r=self.client.delete(f'/api/guilds/{G1}/destinations/{D1}',headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(len(self.draft()['destinations']),1)
        self.assertEqual(db.one('SELECT status FROM deliveries WHERE channel_id=?',(D1,))['status'],'skipped')
        self.assertEqual(db.one('SELECT status FROM deliveries WHERE channel_id=?',(D2,))['status'],'pending')
