"""Upgrade a real V1.0.5 schema with representative data, without external APIs."""
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import test_core as core
from app import db,api_keys,routing


class UpgradeTests(unittest.TestCase):
    def test_v105_upgrade_is_additive_and_idempotent(self):
        self.check_upgrade('schema_v105.sql')

    def test_v106_upgrade_preserves_custom_destination_messages_and_history(self):
        self.check_upgrade('schema_v106.sql', custom=True)

    def test_v107_upgrade_preserves_all_data_and_can_run_twice(self):
        self.check_upgrade('schema_v107.sql', custom=True)

    def check_upgrade(self, fixture, custom=False):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'monitor.sqlite3'
            secret=api_keys.encrypt('fixture-key-1234')
            with sqlite3.connect(path) as con:
                con.executescript((Path(__file__).parent/'fixtures'/fixture).read_text())
                con.execute("INSERT INTO templates(id,name,content) VALUES(1,'Meu modelo','Mensagem original {link}')")
                con.execute("INSERT INTO guilds(guild_id,name,active,present,owner_verified,target_channel_id,last_seen) "
                            "VALUES('g','Servidor',1,1,1,'d',1)")
                con.execute("INSERT INTO discord_channels(channel_id,guild_id,name,can_view,can_send,can_embed,can_mention,last_seen) "
                            "VALUES('d','g','avisos',1,1,1,1,1)")
                con.execute("INSERT INTO guild_destinations VALUES('g','d',1)")
                con.execute("INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at,monitor_after,baseline_done,ids_baseline_done,last_poll) "
                            "VALUES('y','Canal','UUy',1,10.25,1,1,100)")
                con.execute("INSERT INTO subscriptions VALUES('g','y',1,11.5)")
                con.execute("INSERT INTO videos(video_id,channel_id,title,url,kind,live_state,first_seen,last_seen) "
                            "VALUES('v','y','Agendada','https://youtube.com/watch?v=v','scheduled','upcoming',12,12)")
                con.execute("INSERT INTO seen_video_ids VALUES('v','y',12)")
                con.execute("INSERT INTO deliveries(video_id,guild_id,channel_id,kind,status,next_try,created_at,updated_at,message_id) "
                            "VALUES('v','g','d','announcement','sent',12,12,12,'message123')")
                con.execute("INSERT INTO api_credentials(id,name,encrypted_key,last4,active,primary_flag,created_at) VALUES(1,'Minha API',?,'1234',1,1,1)",(secret,))
                con.execute("INSERT INTO api_key_usage VALUES('2026-09-26',1,200,12)")
                con.execute("INSERT INTO api_usage VALUES('2026-09-26',200,12)")
                con.execute("INSERT INTO logs VALUES(1,12,'worker','info','Histórico preservado')")
                con.execute("INSERT INTO settings VALUES('playlist_interval','120')")
                con.execute("INSERT INTO settings VALUES('timezone','America/Sao_Paulo')")
                if custom:
                    con.execute("UPDATE youtube_channels SET routing_custom=1,template_id=1,config_revision=7")
                    con.execute("UPDATE templates SET owner_channel_id='y',preview_mode='custom'")
                    con.execute("INSERT INTO channel_destinations(youtube_channel_id,guild_id,channel_id,template_id,"
                                "notify_uploads,notify_scheduled,mention_everyone,notify_after,created_at) "
                                "VALUES('y','g','d',1,1,0,0,11.5,1)")
                    con.execute("INSERT INTO test_requests(guild_id,channel_id,status,payload,youtube_channel_id,created_at,updated_at) "
                                "VALUES('g','d','sent','{\"content\":\"rascunho preservado\"}','y',12,12)")
                con.commit()
                tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
                columns={t:[r[1] for r in con.execute(f'PRAGMA table_info({t})')] for t in tables}
                before={t:con.execute(f'SELECT * FROM {t}').fetchall() for t in tables}
            with patch.object(db,'DATA_DIR',Path(folder)),patch.object(db,'DB_PATH',path):
                db.init_db();db.init_db()
                with sqlite3.connect(path) as con:
                    for t in tables:
                        if t=='settings':continue
                        after=con.execute('SELECT '+','.join(columns[t])+f' FROM {t}').fetchall()
                        self.assertEqual(after,before[t],t)
                self.assertEqual(db.setting('playlist_interval'),'120')
                self.assertEqual(db.one('SELECT encrypted_key FROM api_credentials')['encrypted_key'],secret)
                self.assertEqual(api_keys.decrypt(secret),'fixture-key-1234')
                c=routing.configuration('y')
                self.assertEqual(c['channel']['monitor_after'],10.25)
                self.assertEqual(c['destinations'][0]['notify_after'],11.5)
                self.assertEqual(c['destinations'][0]['effective_template_id'],1)
                self.assertEqual(db.one('PRAGMA integrity_check')['integrity_check'],'ok')
