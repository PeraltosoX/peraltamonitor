# Atualizar da V1.0.8 para a V1.0.9

Este é o padrão de **oito passos separados** de atualização do Peralta YouTube Live Monitor. Execute como root, um bloco por vez, na ordem. Se algum bloco falhar, pare nessa etapa e confira a mensagem.

Antes do passo 1, envie **Peralta_YouTube_Live_Monitor_V1.0.9.zip** para a raiz da branch `main` do mesmo repositório, **PeraltosoX/peraltamonitor**. O ZIP entregue não é publicado automaticamente no GitHub. Um repositório privado exige um download autenticado; também é possível copiar o ZIP diretamente para o caminho `/tmp` usado abaixo.

Os comandos consideram **V1.0.8 instalada** em `/opt/peralta-live-monitor/releases/V1.0.8`. Se sua instalação ainda é V1.0.5, V1.0.6 ou V1.0.7, altere **somente as referências à pasta de origem V1.0.8 nos passos 2 e 4** para a versão realmente instalada. A V1.0.9 aceita essas quatro origens. A versão de destino, o nome do ZIP, o backup e a verificação de saúde continuam em V1.0.9.

Mantenha o **mesmo `.env`, a mesma `APP_SECRET` e a mesma pasta `data`**. A atualização preserva os dados e acrescenta a autorização de pessoas e a fila de respostas ao /start. O Telegram já configurado permanece com o mesmo token, administrador e destinos. Instalações anteriores à V1.0.8 ainda precisam configurar o Telegram pelo painel. O ícone, domínio, porta 8081 e serviços `web`, `worker` e `bot` continuam sendo os existentes. O Telegram funciona dentro do worker, sem quarto serviço.

1. **Baixar o arquivo do GitHub**

   ```bash
   (
   set -e
   curl -fL --retry 3 \
     -o /tmp/Peralta_YouTube_Live_Monitor_V1.0.9.zip \
     https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.0.9.zip
   )
   ```

2. **Conferir o ZIP e extrair a nova versão**

   ```bash
   (
   set -e

   test -s /opt/peralta-live-monitor/.env
   test -s /opt/peralta-live-monitor/data/monitor.sqlite3
   test -s /opt/peralta-live-monitor/releases/V1.0.8/compose.yaml

   if test -e /opt/peralta-live-monitor/releases/V1.0.9; then
     echo "A pasta V1.0.9 já existe. Confira se a atualização já foi feita."
     exit 1
   fi

   unzip -tq /tmp/Peralta_YouTube_Live_Monitor_V1.0.9.zip

   unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.0.9.zip \
     -d /opt/peralta-live-monitor/releases
   )
   ```

3. **Construir a imagem nova**

   Nesta etapa, o sistema antigo continua funcionando. Aguardar a construção terminar.

   ```bash
   (
   set -e
   cd /opt/peralta-live-monitor/releases/V1.0.9
   docker compose build web
   )
   ```

4. **Parar os serviços e fazer backup**

   A partir daqui, o monitoramento fica parado até a conclusão das etapas seguintes. O bloco guarda as configurações e faz uma cópia consistente do banco.

   ```bash
   (
   set -e
   cd /opt/peralta-live-monitor/releases/V1.0.8

   test -s ../../.env
   test -s ../../data/monitor.sqlite3

   PLM_BACKUP_NAME="antes-V1.0.9-$(date +%Y%m%d-%H%M%S)"

   mkdir -p ../../data/backup
   mkdir -m 700 "../../data/backup/$PLM_BACKUP_NAME"

   cp -p ../../.env "../../data/backup/$PLM_BACKUP_NAME/config.env"
   chmod 600 "../../data/backup/$PLM_BACKUP_NAME/config.env"

   docker compose stop -t 60 worker bot web

   cd ../V1.0.9

   docker compose run --rm --no-deps -T web python -m scripts.backup \
     "/data/backup/$PLM_BACKUP_NAME/monitor.sqlite3"

   printf '\nBackup concluído: /opt/peralta-live-monitor/data/backup/%s\n' \
     "$PLM_BACKUP_NAME"
   )
   ```

   Só avançar depois de aparecer **“Backup concluído”**.

5. **Iniciar o painel da V1.0.9**

   ```bash
   (
   set -e
   cd /opt/peralta-live-monitor/releases/V1.0.9
   docker compose up -d --no-build --no-deps web
   )
   ```

6. **Aguardar o painel e confirmar a versão**

   Este bloco inclui a correção para repetir a consulta quando houver uma falha temporária de conexão.

   ```bash
   (
   set -Eeuo pipefail
   cd /opt/peralta-live-monitor/releases/V1.0.9

   trap 'docker compose ps -a; docker compose logs --tail=60 web' ERR

   echo "Aguardando o painel ficar pronto..."

   curl --noproxy '*' --retry 90 --retry-all-errors --retry-delay 2 \
     --retry-max-time 180 --connect-timeout 2 --max-time 5 \
     -fsS -o /dev/null http://127.0.0.1:8081/health

   docker compose exec -T web python - <<'PY'
   import json
   import urllib.request

   with urllib.request.urlopen(
       "http://127.0.0.1:8081/health", timeout=10
   ) as response:
       result = json.load(response)

   if result.get("status") != "ok" or result.get("version") != "1.0.9":
       raise SystemExit("ERRO: versão ou estado inesperado: " + repr(result))

   print("Painel V1.0.9 pronto. Pode iniciar o worker e o bot.")
   PY
   )
   ```

   Só avançar quando aparecer **“Painel V1.0.9 pronto”**.

7. **Iniciar o worker e o bot**

   ```bash
   (
   set -e
   cd /opt/peralta-live-monitor/releases/V1.0.9
   docker compose up -d --no-build worker bot
   )
   ```

8. **Conferir os três serviços e os logs**

   ```bash
   (
   set -e
   cd /opt/peralta-live-monitor/releases/V1.0.9

   docker compose ps -a
   docker compose logs --tail=30 web worker bot
   )
   ```

Depois, abrir [o painel do monitor](https://peraltamonitor.peraltaultrachat.shop) e conferir o worker e o bot na **Visão geral**. Se aparecer o visual antigo, pressionar **Ctrl + F5**.

## Conferência após os oito passos

- Confira **V1.0.9** no rodapé e os serviços na Visão geral.
- Confira os canais e mensagens existentes na seção **Discord → Canais e avisos**. A antiga aba Associações foi incorporada a essa edição.
- Seu privado atual aparece em **Telegram → Pessoas autorizadas**, identificado como administrador. Os avisos e as pausas existentes são mantidos.
- Para adicionar pessoas ou habilitar Telegram, siga [CONFIGURAR_TELEGRAM.md](CONFIGURAR_TELEGRAM.md). Nenhuma credencial do Telegram precisa ser inserida no terminal.
- O passo 6 verifica o painel e a versão. A saúde do worker, a conexão do Discord e as permissões reais de envio são verificadas depois do passo 7, pelos logs e pelo painel.

## Se houver falha

Preserve a pasta anterior e o backup. O passo 6 repete falhas temporárias de conexão (`--retry-all-errors`) e, se não conseguir, mostra os logs do painel. Não refaça o `.env`, a `APP_SECRET` ou o banco.

Antes de iniciar a nova versão, é possível retomar os serviços da pasta anterior com `docker compose up -d --no-build`. Depois que a V1.0.9 começar a gravar e enviar, não restaure automaticamente uma cópia antiga: ela não contém as alterações e os envios posteriores. Preserve o banco atual e pare todos os serviços antes de qualquer restauração para evitar perdas e avisos repetidos.
