# Configurar Telegram na V1.0.9

Toda a configuração do Telegram é feita no painel. O Discord mantém sua própria seção. As APIs do YouTube e o intervalo de busca continuam compartilhados.

## Bot e administrador

Abra **Telegram → Bot e administrador** e preencha:

| Campo | O que informar |
| --- | --- |
| ID do administrador do Telegram | Seu ID numérico de usuário no Telegram, positivo. É diferente do ID do Discord e do ID negativo de um grupo/canal. |
| Usuário do administrador | Seu `@usuário`, se tiver. Este campo ajuda na identificação; a autorização usa o ID numérico. |
| Token do bot | O token gerado pelo [BotFather](https://t.me/BotFather) para seu bot. |

Marque **Ativar notificações do Telegram** e clique em **Validar e salvar configuração**. O painel mostra o nome e o @usuário do bot confirmado pelo Telegram. O token é cifrado com a `APP_SECRET` da instalação e não volta nas respostas do painel. Ao editar, deixe o token em branco para mantê-lo.

Use um bot exclusivo para este monitor. Se o token já tem um webhook em outro serviço, o painel avisa e não altera esse webhook. Se outro serviço estiver consumindo as atualizações do mesmo bot, o erro aparece na conexão.

## Pessoas autorizadas no privado

Seu administrador atual continua cadastrado e aparece com o selo **Administrador** em **Telegram → Pessoas autorizadas**. Funciona sem criar canal ou grupo Telegram.

1. Configure o bot e seu ID em **Bot e administrador**.
2. Em **Pessoas autorizadas**, use **Abrir @seubot** e envie `/start` pela conta correspondente.
3. O bot responde na conversa privada com **o nome da pessoa, seu @usuário do Telegram, seu ID do Telegram e a situação de autorização**. Se não tiver @usuário, mostra “Não definido”.
4. Para permitir outra pessoa, cadastre no painel o **ID numérico** que ela recebeu no `/start`. Nome de identificação e @usuário são auxiliares; o ID determina a autorização. Receber avisos não concede login no painel nem poderes administrativos.
5. A pessoa envia `/start` **depois de ser autorizada** para confirmar o vínculo. Até lá, o painel mostra **Aguardando /start**. É possível preparar seus canais e mensagens enquanto aguarda; os envios permanecem bloqueados.
6. Em **Telegram → Canais e avisos**, adicione essa pessoa como destino, escolha os tipos de publicação, personalize a mensagem e salve na etapa **Revisar**. Cada pessoa pode receber canais e textos diferentes.

Uma pessoa desconhecida recebe apenas suas próprias informações e a indicação **Aguardando autorização do administrador**. Iniciar o bot não a cadastra para notificações. A identidade vem do remetente real da conversa privada, não de nomes, @usuários, mensagens encaminhadas ou IDs digitados no texto. O `/start` com essas informações existe somente no bot Telegram; nada muda no bot Discord.

Cada pessoa tem ações para testar, pausar/retomar, editar o nome e remover. O teste exige conexão confirmada e destino ativo. Pausar cancela avisos pendentes; retomar considera publicações novas. Remover exclui seus vínculos e cancela pendências, mantendo o histórico de envios e os demais destinos. O administrador pode ser pausado; para trocá-lo, use **Bot e administrador**.

Trocar o administrador revoga os avisos do administrador anterior e exige que o novo inicie o bot. Outras pessoas autorizadas continuam cadastradas. Trocar o bot exige confirmar novamente os destinos e iniciar o novo bot nas conversas privadas. Um envio já em andamento pode terminar antes da mudança.

A resposta ao `/start` usa uma fila própria, sem entrar em “Entregas recentes” nem “Testes por destino”. Atualizações repetidas são ignoradas; comandos repetidos muito rapidamente são limitados. Em falha de conexão confirmadamente anterior ao envio ou limite temporário, há novas tentativas limitadas. Um resultado incerto não é reenviado automaticamente: a pessoa pode enviar `/start` novamente.

## Canais e grupos

1. Adicione o bot ao canal/grupo como administrador. Para canais, permita **publicar mensagens**.
2. Abra **Telegram → Canais e grupos**.
3. Informe o ID negativo do chat, por exemplo `-100…`, ou o `@usuário` público do canal/grupo. Não use links de convite.
4. Clique em **Verificar e adicionar**. O painel confirma o chat e as permissões do bot.
5. Escolha esse destino na edição de **Telegram → Canais e avisos**.

Cada destino tem ações de teste, verificação, pausa/retomada e remoção. Se as permissões mudarem, o resultado dos envios explica a falha. Depois de corrigir, use **Verificar** e teste novamente. Se um grupo mudar de ID ao ser convertido em supergrupo, cadastre e verifique o novo ID e selecione o novo destino.

## YouTube, mensagens e modelos

Em **Adicionar canal YouTube**, você pode escolher um canal já cadastrado no monitor ou informar um novo Channel ID `UC…`. Escolher um canal existente reaproveita a mesma busca e os mesmos IDs conhecidos. Um novo canal registra as publicações existentes como conhecidas, sem enviá-las.

O editor tem três etapas: **Destinos**, **Mensagem** e **Revisar**. Adicione os destinos na primeira, selecione um por vez na segunda e confira tudo antes de salvar na terceira. Cada canal, grupo e pessoa pode ter texto, formato, prévia de link, envio sem som e tipos de publicação próprios. Os rascunhos são mantidos ao trocar de destino; clique em **Salvar configuração** para aplicar.

As variáveis disponíveis são `{tipo}`, `{canal}`, `{titulo}`, `{link}`, `{data}`, `{hora}` e `{live_id}`. Data/hora representam o horário da live quando houver. O link do YouTube é incluído automaticamente se faltar na mensagem.

O formato **Texto simples** não interpreta marcação. **HTML do Telegram** aceita negrito, itálico, sublinhado, riscado, código, citação e links HTTPS: `b`, `strong`, `i`, `em`, `u`, `s`, `code`, `pre`, `blockquote`, `a`. Para links, use `<a href="https://…">texto</a>`. O painel valida a marcação e escapa os dados do vídeo. O modelo tem limite de 3.000 caracteres; a mensagem pronta respeita o limite de 4.096 do Telegram.

**Modelos de mensagem** guarda bases reutilizáveis. Aplicar um modelo copia seus campos para o destino escolhido. Editar o modelo depois não modifica automaticamente os destinos já personalizados. A prévia usa os dados de uma publicação conhecida ou um exemplo, sem nova chamada à API YouTube. A aparência final e a prévia do link são produzidas pelo Telegram.

## Testes, filas e históricos

**Enviar teste neste destino** pede confirmação e coloca o rascunho na fila, com indicação de teste. Ele envia uma mensagem real após o worker processar. Consulte o resultado em **Telegram → Entregas e logs → Testes por destino**.

As abas de entregas e testes têm filtros por **destino/pessoa** e **situação do envio**, com páginas de até 100 resultados. O filtro é aplicado antes desse limite. “Ver registros anteriores” abre a próxima página; “Voltar aos mais recentes” retorna ao início. Logs são registros do serviço, sem filtro por destinatário. Um destino pausado mantém a situação dos envios anteriores.

As abas de entregas, testes e logs têm botões próprios para limpar. A limpeza abrange todos os registros finalizados daquela categoria, independentemente do filtro selecionado; a confirmação informa isso. A limpeza retira os envios finalizados da exibição, preserva a fila e mantém o registro que evita duplicações. Não apaga mensagens recebidas no Telegram.

Falhas de conexão que confirmam que o envio não começou e limites temporários são tentados novamente, com espera e limite de tentativas. Um timeout depois de iniciar o envio, uma resposta incerta ou um reinício durante o envio deixam o estado **Conferir envio**. Confira o chat antes de usar **Tentar novamente**, porque a mensagem pode já ter chegado.

O Telegram roda no serviço `worker`, junto da busca YouTube, em tarefas separadas. Uma falha do Telegram não bloqueia a fila do Discord. Pausar ou remover os avisos de uma plataforma mantém os da outra. Retomar um destino ou canal considera novas publicações a partir da retomada, sem recuperar o período pausado.

Referências: [Telegram Bot API](https://core.telegram.org/bots/api) e [funcionamento dos bots](https://core.telegram.org/bots#how-do-bots-work).
