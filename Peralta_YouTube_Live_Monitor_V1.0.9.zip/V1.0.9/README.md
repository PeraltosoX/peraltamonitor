# Peralta YouTube Live Monitor — V1.0.9

A V1.0.9 corrige a classificação de lives com metadados de início, usa o nome **Live programada** e permite **várias pessoas autorizadas no privado do Telegram**. O `/start` do bot Telegram responde com nome, @usuário, ID e situação de autorização de quem o enviou. Discord e Telegram continuam separados e compartilham a busca de cada canal YouTube.

O menu mantém a mesma organização, sem grupos recolhíveis. A aba “Meu privado” passa a se chamar **Pessoas autorizadas**. O layout do ChatFlow Peralta 3.0.3 permanece em vermelho e azul, com modo claro/escuro salvo. A aba **Associações foi retirada**: configure os destinos em **Canais e avisos**, na seção de cada plataforma. Os vínculos existentes continuam funcionando.

O ícone original foi preservado. O projeto continua com `web`, `worker` e `bot`, porta local **8081**, projeto Compose `peralta_live_monitor` e banco em `/opt/peralta-live-monitor/data`. O domínio e o Caddy existentes continuam sendo usados.

**Para atualizar uma instalação existente, siga [ATUALIZAR_SEM_PERDER_DADOS.md](ATUALIZAR_SEM_PERDER_DADOS.md).** Não substitua o `.env` pela `.env.example`. A `APP_SECRET` existente precisa ser mantida para abrir as chaves cifradas.

## Layout e temas

O menu lateral, o cabeçalho compacto, os painéis arredondados e a família de fonte sem serifa seguem a referência do ChatFlow Peralta. O ícone continua sendo o original deste monitor.

No canto superior, use o botão **Modo claro / Modo escuro**. No celular ele aparece com o ícone de sol ou lua. A escolha vale para todo o painel, inclusive a tela de login e os editores, e fica salva neste navegador. Na primeira abertura, o tema é escuro; limpar os dados do navegador também remove essa preferência. O tema não altera as cores dos embeds enviados ao Discord.

O painel suspende as consultas automáticas e a contagem visual quando a aba fica oculta. Ao voltar, atualiza os dados; o worker continua buscando e enviando avisos. As listas atualizam os elementos alterados sem recriar controles iguais.

Os dois editores seguem **Destinos → Mensagem → Revisar**, com o destino destacado ao lado da edição e da prévia. Canais ativos sem destino elegível mostram **Sem destino pronto**.

No celular, o botão de menu abre as mesmas áreas do painel. Em **Entregas e logs**, escolha a aba do histórico desejado. No editor de mensagens, o servidor e o canal selecionados aparecem em um bloco destacado para deixar claro qual destino está sendo configurado.

## Configurar os avisos do Discord

1. Abra **Canais e avisos** e clique em **Adicionar canal**. Informe o Channel ID `UC…`, como na versão anterior. O cadastro leva diretamente à edição.
2. Em **Destinos**, escolha o servidor e o canal Discord. Adicione quantos destinos precisar, inclusive vários no mesmo servidor.
3. Em cada destino, clique em **Editar mensagem e estilo**. Em **Servidor e canal que você está editando**, confirme o servidor/canal desejado.
4. Escolha **Usar modelo existente** ou **Personalizar para este destino**. Uma cópia recebe, por padrão, o nome do canal YouTube, do servidor e do destino; o nome também pode ser editado.
5. Defina a mensagem e o estilo: prévia nativa do YouTube ou embed personalizado com título, descrição, rodapé, imagem e cor. Cada destino tem suas próprias opções de vídeos/Shorts, lives e `@everyone`.
6. Troque de destino na prévia para conferir cada mensagem. **Enviar teste neste destino** coloca uma mensagem real na fila do bot, com todas as menções bloqueadas. Você confirma o destino antes do teste. A prévia não chama a API YouTube e o teste não salva o rascunho.
7. Abra **Revisar**, confira todos os destinos, modelos e estados e clique em **Salvar configuração**. O conjunto é salvo em uma única transação.

Exemplo: um canal YouTube pode enviar texto curto com prévia do YouTube ao servidor A, um embed personalizado ao servidor B e outro modelo ao servidor C. Destinos de um mesmo servidor também podem usar estilos diferentes.

O **Padrão deste canal** é opcional: permite reutilizar uma mensagem nos destinos que escolherem esse padrão. A configuração específica do destino tem prioridade. Se nenhum modelo do canal/destino for escolhido, continua valendo o padrão daquele servidor.

## Cópias e modelos compartilhados

- **Personalizar para este destino** preserva o modelo de origem. Se uma cópia for compartilhada posteriormente, uma nova personalização do canal cria outra cópia para não modificar os outros usos.
- A aba **Modelos** reúne todos os modelos, incluindo as cópias por canal/destino. Sua edição direta é uma edição compartilhada e pede confirmação antes de salvar.
- O editor de modelos mantém variáveis, modo YouTube/embed e reordenação de linhas por arraste; as setas também permitem reordenar por teclado ou toque.
- Ao trocar entre servidores no editor, os rascunhos são mantidos até salvar ou descartá-los. Fechar uma edição com alterações pede confirmação.

## Pausas, remoções e histórico

Cada destino pode ser pausado sem pausar os outros. Salve para aplicar a pausa. Avisos ainda pendentes desse destino são marcados como ignorados, com o motivo registrado; entregas enviadas e IDs conhecidos permanecem no banco. Um envio que já esteja em andamento pode terminar antes da pausa.

Retomar um destino começa pelas novas publicações após a retomada. Não há reenvio automático do período pausado. Remover um destino na edição afeta somente aquele canal YouTube. Remover um destino padrão na aba Discord é uma ação do servidor e cancela pendências daquele destino.

A aba **Entregas e logs** mostra o canal YouTube, servidor, canal Discord, resultado e motivo da falha. Há filtros por texto e estado. O reenvio manual continua disponível para falhas/resultados incertos, com confirmação para evitar duplicar um aviso que já tenha chegado.

### Limpar cada histórico

Cada aba tem seu próprio botão e pede confirmação antes de limpar:

| Botão | Efeito |
| --- | --- |
| Limpar entregas | Retira do histórico todas as entregas finalizadas: enviadas, com falha, incertas e ignoradas. Mantém as que estão na fila ou em envio. |
| Limpar testes | Retira do histórico todos os testes enviados ou com falha. Mantém os que estão na fila ou em envio. |
| Limpar logs | Apaga os registros da área selecionada. Os logs próprios do Telegram são limpos na seção Telegram. Novos eventos podem aparecer enquanto o monitor funciona. |

A limpeza de entregas e testes é persistente, inclusive após recarregar o painel. Ela abrange o histórico inteiro daquela categoria; filtros e limites de 100/20 itens não restringem a limpeza. Ao terminar um envio que estava pendente, seu resultado continua visível.

Limpar não apaga mensagens no Discord ou Telegram, não modifica canais, modelos ou chaves e não zera o total de avisos enviados. O banco mantém os registros de entregas necessários para impedir duplicações; somente a exibição desses registros finalizados é limpa. Os IDs conhecidos são preservados. O resultado de um teste aberto no editor continua acessível mesmo se outra aba limpar o histórico de testes.

## Telegram e busca global

Consulte [CONFIGURAR_TELEGRAM.md](CONFIGURAR_TELEGRAM.md) para configurar o bot e o administrador pelo painel, conectar canais/grupos ou usar somente o privado, personalizar mensagens e testar um destino.

O menu mostra a seção Discord acima da seção Telegram. **Busca global**, **APIs do YouTube** e **Configurações** são compartilhadas. Adicionar um YouTube já cadastrado na outra plataforma reaproveita os metadados, IDs conhecidos e a busca existente. O monitoramento permanece ativo enquanto pelo menos uma plataforma mantém esse canal ativo.

Pausar ou remover um canal do Discord afeta seus avisos no Discord; fazer isso no Telegram afeta os avisos no Telegram. Cada plataforma mantém sua própria fila e controle de envios. Pausas e reativações de destinos começam a considerar publicações novas a partir da ativação. Um envio já iniciado pode concluir antes de uma mudança.

## Compatibilidade com as versões anteriores

A migração de V1.0.5, V1.0.6, V1.0.7 ou V1.0.8 é aditiva: acrescenta estruturas do Telegram e estados separados para as plataformas. Preserva canais, modelos, mensagens personalizadas, credenciais cifradas, intervalos, histórico, cotas e marcos de monitoramento. Na V1.0.8, a configuração Telegram existente permanece intacta; o administrador atual é autorizado automaticamente, preservando sua pausa, seus destinos e suas mensagens. Em origens anteriores à V1.0.8, Telegram começa desativado.

Canais antigos continuam usando os vínculos e destinos padrão existentes. O editor em **Discord → Canais e avisos** mostra essas escolhas. Salvar ali transforma apenas aquele canal em uma lista própria de destinos. A retirada da aba Associações não apaga os registros nem exige cadastrar novamente seus canais.

Se um servidor está pausado, seus destinos individuais também aguardam ativação em **Discord → Servidores**. Os editores detectam alterações concorrentes e pedem para reabrir a edição antes de sobrescrever escolhas mais recentes.

## Classificação das lives

Antes, um vídeo com `liveBroadcastContent=none` podia ser tratado como upload mesmo contendo `scheduledStartTime` ou `actualStartTime`. A V1.0.9 verifica os horários em `liveStreamingDetails` além do sinalizador: fim → encerrada; início efetivo → ao vivo; início programado → programada. Lives encerradas continuam sem gerar aviso novo. O texto de `{tipo}` para a categoria programada passa a ser **LIVE PROGRAMADA**, incluindo prévias e testes.

A correção aproveita a resposta de `videos.list` que já era consultada. Não aumenta a frequência nem reconsulta IDs antigos. Avisos já enviados não são reescritos ou reenviados; textos digitados manualmente pelo usuário em modelos permanecem intactos. Se o YouTube não fornecer nenhum sinal de transmissão, o título sozinho não é usado para adivinhar a categoria. Um caso específico ainda divergente precisa do link/ID e dos dados retornados para investigação.

Referência dos campos: [Videos — YouTube Data API](https://developers.google.com/youtube/v3/docs/videos#liveStreamingDetails).

## Monitoramento e consumo

- O worker continua independente da página aberta no navegador.
- `playlistItems.list` descobre IDs, até 50 por página, no intervalo global escolhido (padrão 300 segundos; mínimo 30). Páginas adicionais são consultadas apenas quando necessárias, até cinco por rodada.
- Apenas IDs desconhecidos e elegíveis vão para `videos.list`, em lotes de até 50. Sem ID novo, não há consulta a `videos.list`. Falhas deixam o ID disponível para nova tentativa.
- IDs antigos e histórico permanecem conhecidos. Uma publicação produz um aviso por destino. A mudança posterior de programada para ao vivo não gera outro aviso nem consulta recorrente de IDs antigos.
- Shorts continuam incluídos em vídeos; a API pública usada não fornece um indicador confiável de Shorts separado.
- `search.list` e WebSub continuam desativados. Uma live programada é encontrada quando seu ID aparece na playlist pública consultada; o instante da descoberta depende do YouTube.
- A troca para a próxima chave ativa em caso de falha/limite continua funcionando, com a mesma configuração.

Em **Configurações**, a estimativa mostra `canais ativos × 86.400 ÷ intervalo`, arredondada para cima, considerando uma página por verificação. Cada chamada de playlist e de detalhes custa uma unidade. Páginas adicionais, lotes de IDs novos, cadastros, testes de chaves e novas tentativas somam consumo. O ciclo do worker também pode alongar o intervalo real quando há muitos canais ou lentidão.

A estimativa não soma cotas de chaves: chaves do mesmo projeto Google compartilham a cota. A contagem local não substitui a medição oficial do Google Cloud. Referências: [playlistItems.list](https://developers.google.com/youtube/v3/docs/playlistItems/list), [videos.list](https://developers.google.com/youtube/v3/docs/videos/list) e [custos da API](https://developers.google.com/youtube/v3/determine_quota_cost).

## Estrutura e configuração

```text
/opt/peralta-live-monitor/
  .env
  data/
    monitor.sqlite3
    backup/
  releases/
    V1.0.5/
    V1.0.6/
    V1.0.7/
    V1.0.8/
    V1.0.9/
```

Para uma instalação nova, use a `.env.example` como referência. Em uma atualização, mantenha o `.env` existente com seu domínio, credenciais Discord, login do painel e `APP_SECRET`. A API YouTube pode continuar cadastrada no painel ou na variável `YOUTUBE_API_KEY`, conforme a instalação atual.

A instalação do bot continua exigindo seu Discord User ID autorizado. No Developer Portal: Public Bot desligado, Require OAuth2 Code Grant ligado, instalação em servidor habilitada e redirect correspondente ao domínio configurado, por exemplo `https://peraltamonitor.peraltaultrachat.shop/auth/discord/callback`. O bot precisa visualizar e enviar no destino; Embed Links habilita as prévias e Mention Everyone permite as menções quando escolhidas.

O Caddy existente continua apontando o domínio para `127.0.0.1:8081`. Não é preciso alterar serviços que usem outras portas, como o Auto Server.

## Validação

Execute os testes com Python 3.12 e as dependências de `requirements.txt`:

```bash
python -m unittest discover -s tests -v
```

A entrega foi verificada com **71 testes automatizados**, incluindo limpeza dos históricos sem interferir nas filas e na deduplicação, além de testes de migração das bases V1.0.5, V1.0.6, V1.0.7 e V1.0.8, preservação das chaves cifradas e do histórico, deduplicação, permissões, modelos por servidor, isolamento entre canais, pausas e testes sem menções. Os testes novos cobrem horários de início/fim de lives com sinalizador ausente ou defasado, autorização de várias pessoas por ID, resposta ao /start sem autorização automática, paginação e filtros, troca de bot/administrador, filas separadas, busca única, HTML seguro, limites temporários e envios incertos do Telegram. O painel foi exercitado no navegador em computador, tablet e celular, incluindo salvar e reabrir mensagens distintas para três destinos do Telegram.

As verificações usam dados de teste e envios simulados. A instalação na VPS e o envio com suas contas reais devem ser conferidos após a atualização. Veja também [VALIDACAO.md](VALIDACAO.md) e [CHANGELOG.md](CHANGELOG.md).
