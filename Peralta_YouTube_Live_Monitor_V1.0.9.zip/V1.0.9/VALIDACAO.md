# Validação da V1.0.9

Verificação local em 03/10/2026, com Python 3.12, bancos temporários, FastAPI TestClient, Chromium e transporte Telegram simulado. Nenhuma conta real foi usada para enviar mensagens.

## Testes automatizados

**71 testes aprovados** pelo comando:

```bash
python -m unittest discover -s tests -v
```

| Área | Verificação |
| --- | --- |
| Migração | Esquemas V1.0.5, V1.0.6, V1.0.7 e V1.0.8; migração repetida duas vezes e comparação dos campos/registros anteriores. Preservação de modelos, credenciais cifradas, histórico, cotas, vínculos e marcos de monitoramento; integridade SQLite. |
| Telegram existente | Token, administrador, privado já confirmado, pausa, mensagens, destinos, fila, offset de atualizações e revisões preservados na migração da V1.0.8. |
| Classificação | Horário programado com sinalizador `none`; início efetivo sem sinalizador; horários e sinalizadores defasados; fim tem prioridade; upload comum não depende do título. Lives encerradas não geram avisos e uma publicação continua única por destino. |
| Busca compartilhada | Um canal YouTube alimenta Discord e Telegram sem repetir consulta de detalhes para ID conhecido. Cadastro na segunda plataforma reaproveita metadados e marcos. |
| Pessoas autorizadas | Cadastro exige sessão e CSRF e usa ID positivo válido. Pessoa ainda sem /start pode ter mensagem preparada, mas não recebe testes/avisos. Remoção cancela pendências e não autoriza novo ingresso pelo /start. Nome/@usuário não substituem ID. |
| Resposta ao /start | Nome, @usuário ou “Não definido”, ID e situação do próprio remetente. Desconhecido não ganha autorização nem recebe dados de outras pessoas. Atualizações repetidas não reenviam a resposta; limite temporário permite tentativas limitadas; envio incerto não duplica automaticamente. |
| Controle de acesso | Mensagens encaminhadas, remetente/chat incompatíveis e grupos não confirmam privado. Troca de administrador revoga o anterior e mantém outras pessoas; troca de bot exige nova confirmação. Token não aparece em respostas/erros do painel. |
| Histórico | Filtros SQL por destino e situação antes do limite de 100; paginação sem repetição entre páginas. Limpeza mantém pendências e deduplicação. Histórico Discord e Telegram independente. |
| Compatibilidade | Modelos por servidor/destino, HTML seguro, backup, revisões de edição, pausas, retomadas, fila e política de envios incertos das versões anteriores. |

## Interface

- 14 telas verificadas em Chromium, com temas claro/escuro e larguras de 1440, 768 e 390 pixels.
- Nenhum erro JavaScript e nenhuma requisição a serviços externos na execução de QA.
- Salvar/reabrir três mensagens independentes para canal, grupo e administrador Telegram; modelo-base não altera os textos já salvos.
- Cadastro de pessoa aguardando /start, pausa/retomada, preparação de aviso individual, edição do nome e remoção pelo painel.
- Telegram em três etapas; destino destacado na edição e prévia; revisão e botão de salvar acessíveis no celular.
- Discord mantém suas etapas e sincroniza a prévia com a edição do destino individual.
- Filtros por situação e limpeza de testes preservando a fila; temas persistem após recarregar.
- Atualização de listas conserva controles e foco. Aba oculta não dispara a atualização automática; voltar à aba atualiza os dados. O monitoramento de backend não depende da página.
- Nenhum transbordamento horizontal observado nas telas e diálogos verificados.

## Pacote e comandos

Sintaxe Python e JavaScript conferida. Os oito blocos Bash do guia foram extraídos e validados com `bash -n`. ZIP com diretório raiz `V1.0.9/`, sem banco privado, `.env` real, credenciais reais ou caches Python. Ícone e favicon idênticos aos da V1.0.8.

O guia conserva a sequência: baixar, extrair, construir, parar/fazer backup, iniciar web, verificar saúde/versão, iniciar worker/bot, conferir logs. A espera HTTP mantém `--retry-all-errors`; a etapa de saúde exige versão **1.0.9** antes de iniciar os processos de envio.

## Limites da verificação

A VPS não foi acessada; o ZIP não foi publicado no GitHub e os comandos Docker de atualização não foram executados no servidor do usuário. Instalação, token, permissões e entrega nas contas reais precisam ser conferidos após atualizar.

A falha de classificação foi reproduzida a partir do código e de respostas representativas da API. Não foi fornecido um link de live afetada para confirmar seu caso exato. A correção usa metadados já consultados, vale para novas descobertas e não reescreve mensagens anteriores nem reconsulta todo o histórico. Se o YouTube omitir todos os sinais de transmissão, o programa não tenta determinar o tipo só pelo título.
