"""Telegram transport and delivery worker. No tokens or raw HTTP errors leave this module."""
import asyncio
import html
import json
import re
import time
from datetime import datetime
from html.parser import HTMLParser
from zoneinfo import ZoneInfo

import httpx

from . import api_keys, db
from .telegram_store import DEFAULT_MESSAGE


class TelegramError(Exception):
    def __init__(self, message, code=0, retry_after=0, uncertain=False):
        super().__init__(message)
        self.code, self.retry_after, self.uncertain = code, retry_after, uncertain


async def call(token, method, payload=None, sending=False):
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(20, connect=8), follow_redirects=False) as client:
            response = await client.post(f"https://api.telegram.org/bot{token}/{method}", json=payload or {})
    except (httpx.ConnectError, httpx.ConnectTimeout):
        raise TelegramError("Telegram indisponível na conexão; nova tentativa em breve.", retry_after=30) from None
    except httpx.HTTPError:
        raise TelegramError("Resposta do Telegram não confirmada.", retry_after=30, uncertain=sending) from None
    try:
        data = response.json()
    except (ValueError, TypeError):
        raise TelegramError("Resposta inválida do Telegram.", uncertain=sending) from None
    if not isinstance(data, dict):
        raise TelegramError("Resposta inválida do Telegram.", uncertain=sending)
    if response.status_code == 200 and data.get("ok") is True:
        return data.get("result")
    try:
        code = int(data.get("error_code") or response.status_code)
        delay = max(1, min(86400, int((data.get("parameters") or {}).get("retry_after") or 30)))
    except (ValueError, TypeError, AttributeError):
        raise TelegramError("Resposta inválida do Telegram.", uncertain=sending) from None
    messages = {400: "Destino ou mensagem inválida; confira os dados e as permissões do bot.",
                401: "Token do bot inválido. Atualize a credencial no painel.",
                403: "Bot bloqueado, removido ou sem permissão para enviar neste destino.",
                409: "Este token está recebendo atualizações em outro serviço. Use um bot exclusivo para este monitor.",
                429: "Limite temporário do Telegram; aguardando a próxima tentativa."}
    raise TelegramError(messages.get(code, f"Telegram indisponível (HTTP {code})."), code,
                        delay if code == 429 or code >= 500 else 0, sending and code >= 500)


def config():
    return db.one("SELECT * FROM telegram_config WHERE id=1")


def token_of(cfg):
    try:
        return api_keys.decrypt(cfg["encrypted_token"])
    except Exception:
        raise TelegramError("Token não pode ser aberto; confira a APP_SECRET original.") from None


def public_config():
    cfg = config()
    return {k: cfg[k] for k in ("admin_id", "admin_username", "bot_id", "bot_username", "bot_name",
            "enabled", "private_chat_id", "private_verified_at", "revision", "last_error", "last_checked")} | {
            "configured": bool(cfg["encrypted_token"]),
            "heartbeat": db.one("SELECT at,detail FROM service_heartbeats WHERE service='telegram'")}


class SafeHTML(HTMLParser):
    tags = {"b", "strong", "i", "em", "u", "s", "code", "pre", "blockquote", "a"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.parts, self.text = [], [], []

    def handle_starttag(self, tag, attrs):
        if tag not in self.tags or (tag != "a" and attrs):
            raise ValueError("Use apenas negrito, itálico, sublinhado, riscado, código, citação e links HTTPS.")
        suffix = ""
        if tag == "a":
            if len(attrs) != 1 or attrs[0][0] != "href" or not (attrs[0][1] or "").startswith("https://"):
                raise ValueError("Os links HTML devem usar apenas href com endereço HTTPS.")
            suffix = ' href="' + html.escape(attrs[0][1], quote=True) + '"'
        self.stack.append(tag)
        self.parts.append(f"<{tag}{suffix}>")

    def handle_endtag(self, tag):
        if not self.stack or self.stack.pop() != tag:
            raise ValueError("Confira a abertura e o fechamento das tags HTML.")
        self.parts.append(f"</{tag}>")

    def handle_data(self, value):
        self.text.append(value)
        self.parts.append(html.escape(value))

    def handle_comment(self, value):
        raise ValueError("Comentários HTML não são aceitos.")

    def handle_decl(self, value):
        raise ValueError("Declarações HTML não são aceitas.")


def clean_html(value):
    parser = SafeHTML()
    parser.feed(value)
    parser.close()
    if parser.stack:
        raise ValueError("Feche todas as tags HTML da mensagem.")
    return "".join(parser.parts), "".join(parser.text)


def message_fields(data):
    content = str(data.get("content", DEFAULT_MESSAGE)).strip()
    mode = data.get("parse_mode", "plain")
    if not content or len(content) > 3000 or mode not in ("plain", "HTML"):
        raise ValueError("Informe uma mensagem de até 3.000 caracteres e um formato válido.")
    if mode == "HTML":
        content, _ = clean_html(content)
    return {"content": content, "parse_mode": mode,
            "preview": int(bool(data.get("preview", True))), "silent": int(bool(data.get("silent", False)))}


def render(template, video):
    stamp = ""
    if video.get("scheduled_at"):
        try:
            stamp = datetime.fromisoformat(video["scheduled_at"].replace("Z", "+00:00")).astimezone(
                ZoneInfo(db.setting("timezone", "America/Sao_Paulo"))).strftime("%d/%m/%Y às %H:%M")
        except (ValueError, KeyError):
            stamp = "Horário a confirmar"
    values = {"tipo": {"scheduled": "LIVE PROGRAMADA", "live": "LIVE AO VIVO", "upload": "NOVO VÍDEO"}.get(video.get("kind"), "NOVO VÍDEO"),
              "canal": video.get("channel_name", "Canal"), "titulo": video.get("title", "Nova publicação"),
              "link": video.get("url", ""), "live_id": video.get("video_id", ""), "data": stamp, "hora": stamp}
    is_html = template.get("parse_mode") == "HTML"
    content = re.sub(r"\{(tipo|canal|titulo|link|live_id|data|hora)\}",
                     lambda m: html.escape(str(values[m[1]])) if is_html else str(values[m[1]]), template["content"])
    if values["link"] and values["link"] not in content:
        content += "\n\n" + (html.escape(values["link"]) if is_html else values["link"])
    if is_html:
        content, plain = clean_html(content)
    else:
        plain = content
    if len(plain.encode("utf-16-le")) // 2 > 4096:
        raise ValueError("A mensagem pronta ultrapassa 4.096 caracteres. Encurte o modelo.")
    payload = {"text": content, "disable_notification": bool(template.get("silent")),
               "link_preview_options": {"is_disabled": not bool(template.get("preview", 1))}}
    if is_html:
        payload["parse_mode"] = "HTML"
    return {"payload": payload, "text": plain, "html": content if is_html else html.escape(content)}


def destinations(con, cid):
    return [dict(r) for r in con.execute("SELECT r.*,d.chat_id,d.kind,d.name,d.username,d.bot_id,"
        "d.active AS destination_active,d.verified,d.authorized,d.last_error,MAX(r.notify_after,d.notify_after) AS cutoff "
        "FROM telegram_routes r JOIN telegram_destinations d ON d.id=r.destination_id "
        "WHERE r.youtube_channel_id=? ORDER BY d.kind,d.name", (cid,))]


def eligible(cfg, dest):
    if not cfg["enabled"] or not cfg["encrypted_token"] or dest["bot_id"] != cfg["bot_id"]:
        return False
    if not dest.get("active", 1) or not dest.get("destination_active", 1) or not dest["verified"]:
        return False
    if dest["kind"] == "private":
        return bool(dest.get('authorized') and
                    (dest['chat_id'] != cfg['admin_id'] or dest['chat_id'] == cfg['private_chat_id']))
    return dest["kind"] in ("group", "supergroup", "channel")


def queue_video(con, channel_id, video, published):
    channel = con.execute("SELECT active FROM telegram_channels WHERE youtube_channel_id=?", (channel_id,)).fetchone()
    if not channel or not channel["active"] or published is None:
        return 0
    cfg = dict(con.execute("SELECT * FROM telegram_config WHERE id=1").fetchone())
    count = 0
    for dest in destinations(con, channel_id):
        if not eligible(cfg, dest) or published <= dest["cutoff"]:
            continue
        if not dest["notify_uploads" if video["kind"] == "upload" else "notify_scheduled"]:
            continue
        count += con.execute("INSERT OR IGNORE INTO telegram_deliveries(video_id,youtube_channel_id,destination_id,"
            "recipient_chat_id,bot_id,next_try,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
            (video["video_id"], channel_id, dest["destination_id"], dest["chat_id"], cfg["bot_id"], db.ts(), db.ts(), db.ts())).rowcount
    return count


def process_updates(updates, snapshot):
    """Only panel-authorized IDs become destinations; /start can identify anyone."""
    with db.transaction() as con:
        cfg = dict(con.execute("SELECT * FROM telegram_config WHERE id=1").fetchone())
        if cfg["revision"] != snapshot["revision"] or not cfg["enabled"]:
            return
        offset = cfg["update_offset"]
        for update in updates:
            uid = int(update.get("update_id", -1))
            if uid < offset:
                continue
            offset = uid + 1
            msg = update.get("message") or {}
            chat, sender = msg.get("chat") or {}, msg.get("from") or {}
            person_id = str(sender.get('id', ''))
            if (chat.get("type") != "private" or sender.get("is_bot") or
                not re.fullmatch(r'[1-9][0-9]{0,15}', person_id) or str(chat.get('id', '')) != person_id or
                not (msg.get("text") or "").strip() or
                any(msg.get(k) for k in ('forward_origin', 'forward_from', 'forward_from_chat', 'via_bot'))):
                continue
            now = db.ts()
            username = str(sender.get("username") or "")[:64]
            display_name = ' '.join(str(sender.get(k) or '') for k in ('first_name', 'last_name')).strip()[:160] or 'Não informado'
            # Backward compatibility: the administrator always has an allowlist row.
            from .telegram_store import ensure_owner
            ensure_owner(con, cfg)
            person = con.execute("SELECT * FROM telegram_destinations WHERE kind='private' AND chat_id=? AND authorized=1", (person_id,)).fetchone()
            if person:
                if person_id == cfg['admin_id']:
                    con.execute("UPDATE telegram_config SET private_chat_id=?,private_verified_at=?,last_error='' WHERE id=1", (person_id, now))
                con.execute("UPDATE telegram_destinations SET notify_after=CASE WHEN verified=0 OR bot_id<>? THEN ? ELSE notify_after END,"
                            "verified=1,username=?,last_error='',bot_id=? WHERE id=?",
                            (cfg['bot_id'], time.time(), username, cfg['bot_id'], person['id']))
            command = (msg.get('text') or '').split()[0].lower()
            if command in ('/start', '/start@' + cfg['bot_username'].lower()):
                # One bounded, durable greeting slot per person and bot. Offsets and
                # queue commit together; rapid repeated /start does not flood sends.
                con.execute("INSERT INTO telegram_greetings(bot_id,chat_id,display_name,username,update_id,next_try,updated_at) "
                            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(bot_id,chat_id) DO UPDATE SET display_name=excluded.display_name,"
                            "username=excluded.username,update_id=excluded.update_id,status='pending',attempts=0,"
                            "next_try=excluded.next_try,updated_at=excluded.updated_at WHERE telegram_greetings.status<>'sending' "
                            "AND telegram_greetings.updated_at<=?",
                            (cfg['bot_id'], person_id, display_name, username, uid, now, now, now - 5))
        con.execute("UPDATE telegram_config SET update_offset=? WHERE id=1", (offset,))


def greeting_text(item, cfg):
    person = db.one("SELECT authorized,active FROM telegram_destinations WHERE kind='private' AND chat_id=?", (item['chat_id'],))
    authorized = bool(person and person['authorized'])
    status = ('Administrador · autorizado' if item['chat_id'] == cfg['admin_id'] else 'Autorizado a receber notificações') if authorized else 'Aguardando autorização do administrador'
    if authorized and not person['active']:
        status += ' · notificações pausadas'
    return (f"Olá, {item['display_name']}!\n\n"
            f"Nome: {item['display_name']}\n"
            f"Usuário do Telegram: {'@' + item['username'] if item['username'] else 'Não definido'}\n"
            f"ID do Telegram: {item['chat_id']}\n"
            f"Situação: {status}\n\n" +
            ('Os avisos dependem dos canais e destinos configurados no painel.' if authorized else
             'Envie seu ID ao administrador para solicitar autorização. O /start não libera notificações automaticamente.'))


async def send_greetings():
    for item in db.rows("SELECT * FROM telegram_greetings WHERE status='pending' AND next_try<=? ORDER BY next_try LIMIT 5", (db.ts(),)):
        cfg = config()
        if not cfg['enabled']:
            return
        key = (item['bot_id'], item['chat_id'], item['update_id'])
        if item['bot_id'] != cfg['bot_id'] or db.ts() - item['updated_at'] > 86400:
            db.write("DELETE FROM telegram_greetings WHERE bot_id=? AND chat_id=? AND update_id=?", key)
            continue
        if not db.write("UPDATE telegram_greetings SET status='sending',attempts=attempts+1 WHERE bot_id=? AND chat_id=? AND update_id=? AND status='pending'", key):
            continue
        status, delay = 'sent', 0
        try:
            result = await call(token_of(cfg), 'sendMessage', {'chat_id': item['chat_id'], 'text': greeting_text(item, cfg)}, sending=True)
            if not isinstance(result, dict) or 'message_id' not in result:
                status = 'uncertain'
        except TelegramError as exc:
            status = 'uncertain' if exc.uncertain else 'pending' if exc.retry_after and item['attempts'] < 5 else 'failed'
            delay = exc.retry_after or 30
            db.log('telegram', 'warning', 'Resposta ao /start: ' + str(exc))
        except Exception:
            status = 'uncertain'
            db.log('telegram', 'error', 'Resposta ao /start não confirmada; a pessoa pode iniciar novamente')
        db.write("UPDATE telegram_greetings SET status=?,next_try=? WHERE bot_id=? AND chat_id=? AND update_id=? AND status='sending'", (status, db.ts() + delay, *key))
    db.write("DELETE FROM telegram_greetings WHERE updated_at<? AND status<>'sending'", (db.ts() - 7 * 86400,))


def delivery_context(item):
    cfg = config()
    dest = db.one("SELECT * FROM telegram_destinations WHERE id=?", (item["destination_id"],))
    if not dest or not eligible(cfg, dest) or dest["chat_id"] != item["recipient_chat_id"] or cfg["bot_id"] != item["bot_id"]:
        return None
    if item["video_id"]:
        channel = db.one("SELECT active FROM telegram_channels WHERE youtube_channel_id=?", (item["youtube_channel_id"],))
        route = db.one("SELECT * FROM telegram_routes WHERE youtube_channel_id=? AND destination_id=? AND active=1",
                       (item["youtube_channel_id"], item["destination_id"]))
        video = db.one("SELECT v.*,y.name AS channel_name FROM videos v JOIN youtube_channels y ON y.channel_id=v.channel_id WHERE v.video_id=?", (item["video_id"],))
        from .youtube import published_timestamp
        if (not channel or not channel["active"] or not route or not video or
            not route["notify_uploads" if video["kind"] == "upload" else "notify_scheduled"] or
            (published_timestamp(video["published_at"]) or 0) <= max(route["notify_after"], dest["notify_after"])):
            return None
        payload = render(route, video)["payload"]
    else:
        payload = json.loads(item["payload"])
    return cfg, {**payload, "chat_id": dest["chat_id"]}


async def send_one(item):
    try:
        context = delivery_context(item)
        if not context:
            db.write("UPDATE telegram_deliveries SET status='skipped',error='Destino ou autorização alterada',updated_at=? WHERE id=? AND status='sending'", (db.ts(), item["id"]))
            return
        cfg, payload = context
        result = await call(token_of(cfg), "sendMessage", payload, sending=True)
        if not isinstance(result, dict) or "message_id" not in result:
            raise TelegramError("Telegram não confirmou o identificador da mensagem.", uncertain=True)
        db.write("UPDATE telegram_deliveries SET status='sent',message_id=?,error='',updated_at=? WHERE id=? AND status='sending'",
                 (str(result["message_id"]), db.ts(), item["id"]))
        db.write("UPDATE telegram_destinations SET last_error='' WHERE id=?", (item["destination_id"],))
        db.log('telegram', 'info', f"Entrega {item['id']} confirmada no destino {item['destination_id']}")
    except TelegramError as exc:
        status = "uncertain" if exc.uncertain else "pending" if exc.retry_after and item["attempts"] < 6 else "failed"
        db.write("UPDATE telegram_deliveries SET status=?,error=?,next_try=?,updated_at=? WHERE id=? AND status='sending'",
                 (status, str(exc), db.ts() + (exc.retry_after or 30), db.ts(), item["id"]))
        db.write("UPDATE telegram_destinations SET last_error=? WHERE id=?", (str(exc), item["destination_id"]))
        db.log('telegram', 'warning', f"Entrega {item['id']}: {str(exc)}")
    except Exception as exc:
        reason = str(exc) if isinstance(exc, ValueError) else "Falha interna ao preparar a mensagem Telegram"
        db.write("UPDATE telegram_deliveries SET status='failed',error=?,updated_at=? WHERE id=? AND status='sending'", (reason[:220], db.ts(), item["id"]))


async def send_pending():
    for item in db.rows("SELECT * FROM telegram_deliveries WHERE status='pending' AND next_try<=? ORDER BY id LIMIT 10", (db.ts(),)):
        if db.write("UPDATE telegram_deliveries SET status='sending',attempts=attempts+1,updated_at=? WHERE id=? AND status='pending'", (db.ts(), item["id"])):
            item["attempts"] += 1
            await send_one(item)
            await asyncio.sleep(0.08)


async def receive_loop():
    while True:
        try:
            cfg = config()
            if cfg["enabled"] and cfg["encrypted_token"]:
                updates = await call(token_of(cfg), "getUpdates", {"offset": cfg["update_offset"], "timeout": 5,
                                      "allowed_updates": ["message"]})
                process_updates(updates or [], cfg)
                db.write("UPDATE telegram_config SET last_error='' WHERE id=1 AND revision=?", (cfg["revision"],))
            else:
                await asyncio.sleep(3)
        except TelegramError as exc:
            db.write("UPDATE telegram_config SET last_error=? WHERE id=1", (str(exc),))
            await asyncio.sleep(max(5, min(60, exc.retry_after or 15)))
        except Exception:
            db.log("telegram", "error", "Falha ao verificar a conexão Telegram; nova tentativa em breve")
            await asyncio.sleep(10)
        await asyncio.sleep(1)


async def sender_loop():
    # A crash during a POST has unknown outcome. Never automatically duplicate it.
    db.write("UPDATE telegram_deliveries SET status='uncertain',error='Processo reiniciado durante envio',updated_at=? WHERE status='sending'", (db.ts(),))
    db.write("UPDATE telegram_greetings SET status='uncertain' WHERE status='sending'")
    while True:
        try:
            cfg = config()
            db.heartbeat("telegram", "Processando avisos" if cfg["enabled"] else "Desativado no painel")
            if cfg["enabled"]:
                await send_pending()
                await send_greetings()
        except Exception:
            db.log("telegram", "error", "Falha na fila Telegram; nova tentativa em breve")
        await asyncio.sleep(3)


async def run():
    await asyncio.gather(receive_loop(), sender_loop())
