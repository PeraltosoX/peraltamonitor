"""Additive Telegram schema and the shared YouTube monitoring switch."""

DEFAULT_MESSAGE = "🔴 {tipo}: {canal}\n{titulo}\n{link}\n{data}"


def migrate(con):
    con.execute("BEGIN IMMEDIATE")
    try:
        columns = {r["name"] for r in con.execute("PRAGMA table_info(youtube_channels)")}
        if "discord_enabled" not in columns:
            con.execute("ALTER TABLE youtube_channels ADD COLUMN discord_enabled INTEGER NOT NULL DEFAULT 1")
            con.execute("UPDATE youtube_channels SET discord_enabled=0 WHERE removed=1")
        if "discord_active" not in columns:
            con.execute("ALTER TABLE youtube_channels ADD COLUMN discord_active INTEGER NOT NULL DEFAULT 1")
            con.execute("UPDATE youtube_channels SET discord_active=active")
        statements = [
            """CREATE TABLE IF NOT EXISTS telegram_config (
                id INTEGER PRIMARY KEY CHECK(id=1), encrypted_token TEXT,
                admin_id TEXT NOT NULL DEFAULT '', admin_username TEXT NOT NULL DEFAULT '',
                bot_id TEXT NOT NULL DEFAULT '', bot_username TEXT NOT NULL DEFAULT '',
                bot_name TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 0,
                private_chat_id TEXT NOT NULL DEFAULT '', private_verified_at INTEGER,
                update_offset INTEGER NOT NULL DEFAULT 0, revision INTEGER NOT NULL DEFAULT 0,
                last_error TEXT NOT NULL DEFAULT '', last_checked INTEGER)""",
            """CREATE TABLE IF NOT EXISTS telegram_destinations (
                id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL, name TEXT NOT NULL, username TEXT NOT NULL DEFAULT '',
                bot_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
                verified INTEGER NOT NULL DEFAULT 0, notify_after REAL NOT NULL,
                last_error TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL)""",
            """CREATE TABLE IF NOT EXISTS telegram_channels (
                youtube_channel_id TEXT PRIMARY KEY REFERENCES youtube_channels(channel_id),
                active INTEGER NOT NULL DEFAULT 1, revision INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL)""",
            """CREATE TABLE IF NOT EXISTS telegram_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                content TEXT NOT NULL, parse_mode TEXT NOT NULL DEFAULT 'plain',
                preview INTEGER NOT NULL DEFAULT 1, silent INTEGER NOT NULL DEFAULT 0)""",
            """CREATE TABLE IF NOT EXISTS telegram_routes (
                youtube_channel_id TEXT NOT NULL REFERENCES telegram_channels(youtube_channel_id),
                destination_id INTEGER NOT NULL REFERENCES telegram_destinations(id),
                active INTEGER NOT NULL DEFAULT 1, content TEXT NOT NULL,
                parse_mode TEXT NOT NULL DEFAULT 'plain', preview INTEGER NOT NULL DEFAULT 1,
                silent INTEGER NOT NULL DEFAULT 0, notify_uploads INTEGER NOT NULL DEFAULT 1,
                notify_scheduled INTEGER NOT NULL DEFAULT 1, notify_after REAL NOT NULL,
                PRIMARY KEY(youtube_channel_id,destination_id))""",
            """CREATE TABLE IF NOT EXISTS telegram_deliveries (
                id INTEGER PRIMARY KEY AUTOINCREMENT, video_id TEXT,
                youtube_channel_id TEXT, destination_id INTEGER NOT NULL,
                recipient_chat_id TEXT NOT NULL, bot_id TEXT NOT NULL,
                payload TEXT, status TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0, next_try INTEGER NOT NULL,
                message_id TEXT, error TEXT NOT NULL DEFAULT '',
                history_hidden INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
                UNIQUE(video_id,destination_id))""",
            "CREATE INDEX IF NOT EXISTS telegram_delivery_due ON telegram_deliveries(status,next_try)",
            "CREATE INDEX IF NOT EXISTS telegram_history ON telegram_deliveries(history_hidden,id DESC)",
        ]
        for sql in statements:
            con.execute(sql)
        con.execute("INSERT OR IGNORE INTO telegram_config(id) VALUES(1)")
        con.execute("INSERT OR IGNORE INTO telegram_templates(id,name,content) VALUES(1,'Padrão Telegram',?)",
                    (DEFAULT_MESSAGE,))
        dest_columns = {r['name'] for r in con.execute('PRAGMA table_info(telegram_destinations)')}
        if 'authorized' not in dest_columns:
            con.execute('ALTER TABLE telegram_destinations ADD COLUMN authorized INTEGER NOT NULL DEFAULT 0')
            con.execute("UPDATE telegram_destinations SET authorized=1 WHERE kind='private' AND chat_id="
                        "(SELECT admin_id FROM telegram_config WHERE id=1)")
        con.execute("""CREATE TABLE IF NOT EXISTS telegram_greetings (
            bot_id TEXT NOT NULL, chat_id TEXT NOT NULL, display_name TEXT NOT NULL,
            username TEXT NOT NULL, update_id INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0,
            next_try INTEGER NOT NULL, updated_at INTEGER NOT NULL,
            PRIMARY KEY(bot_id,chat_id))""")
        cfg = dict(con.execute('SELECT * FROM telegram_config WHERE id=1').fetchone())
        ensure_owner(con, cfg)
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version','109')")
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise


def ensure_owner(con, cfg):
    """Keep the original private destination, routes, pause and cutoff intact."""
    if not cfg['admin_id'] or not cfg['bot_id']:
        return
    import time
    now = time.time()
    verified = int(cfg['private_chat_id'] == cfg['admin_id'])
    con.execute("INSERT INTO telegram_destinations(chat_id,kind,name,username,bot_id,verified,"
                "authorized,notify_after,created_at) VALUES(?,'private','Administrador',?,?,?,1,?,?) "
                "ON CONFLICT(chat_id) DO UPDATE SET authorized=1",
                (cfg['admin_id'], cfg['admin_username'], cfg['bot_id'], verified, now, int(now)))


def refresh_monitoring(con, channel_id):
    """A platform's pause never stops a channel still used by the other."""
    con.execute("UPDATE youtube_channels SET active=CASE WHEN "
                "(discord_enabled=1 AND discord_active=1) OR EXISTS "
                "(SELECT 1 FROM telegram_channels t WHERE t.youtube_channel_id=youtube_channels.channel_id AND t.active=1) "
                "THEN 1 ELSE 0 END, removed=CASE WHEN discord_enabled=1 OR EXISTS "
                "(SELECT 1 FROM telegram_channels t WHERE t.youtube_channel_id=youtube_channels.channel_id) "
                "THEN 0 ELSE 1 END WHERE channel_id=?", (channel_id,))


def attach(con, channel_id, platform, now):
    if platform == "telegram":
        con.execute("INSERT OR IGNORE INTO telegram_channels(youtube_channel_id,created_at) VALUES(?,?)", (channel_id, now))
    else:
        con.execute("UPDATE youtube_channels SET discord_active=CASE WHEN discord_enabled=0 THEN 1 ELSE discord_active END,discord_enabled=1 WHERE channel_id=?", (channel_id,))
    refresh_monitoring(con, channel_id)
