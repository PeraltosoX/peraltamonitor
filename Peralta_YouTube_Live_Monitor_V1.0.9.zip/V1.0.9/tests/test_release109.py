"""Regressions for live metadata and explicitly authorized Telegram recipients."""
import asyncio
import unittest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import test_core as core
import test_telegram as old
from app import db, youtube, telegram as tg


class Release109Tests(unittest.TestCase):
    setUp = old.TelegramTests.setUp
    tearDown = old.TelegramTests.tearDown
    add_dest = old.TelegramTests.add_dest
    route = old.TelegramTests.route
    video = old.TelegramTests.video
    draft = old.TelegramTests.draft
    save = old.TelegramTests.save
    update = old.TelegramTests.update

    def authorize(self, pid='987654321', name='Pessoa de teste'):
        result = self.client.post('/api/telegram/people', json={'user_id':pid,'name':name,'username':'pessoa'}, headers=self.headers)
        self.assertEqual(result.status_code, 200, result.text)
        return result.json()

    def test_live_timestamps_resolve_missing_and_stale_snippet_flags(self):
        scenarios = [({}, 'none', 'upload'), ({}, 'upcoming', 'scheduled'), ({}, 'live', 'live'),
                     ({'scheduledStartTime':'2026-10-03T20:00:00Z'}, 'none', 'scheduled'),
                     ({'actualStartTime':'2026-10-03T20:00:00Z'}, None, 'live'),
                     ({'actualStartTime':'2026-10-03T20:00:00Z'}, 'upcoming', 'live'),
                     ({'scheduledStartTime':'2026-10-03T20:00:00Z'}, 'live', 'live'),
                     ({'actualEndTime':'2026-10-03T22:00:00Z'}, 'live', 'ended'),
                     ({'actualEndTime':'2026-10-03T22:00:00Z'}, 'upcoming', 'ended')]
        for details, flag, expected in scenarios:
            with self.subTest(details=details, flag=flag):
                v=self.video();v['liveStreamingDetails']=details
                if flag is None:v['snippet'].pop('liveBroadcastContent')
                else:v['snippet']['liveBroadcastContent']=flag
                self.assertEqual(youtube.classify(v)['kind'],expected)
        v=self.video();v['snippet']['title']='LIVE AO VIVO EM BREVE';v.pop('liveStreamingDetails')
        self.assertEqual(youtube.classify(v)['kind'],'upload') # Titles are not authoritative metadata.

    def test_corrected_live_respects_filters_dedupe_and_ended_no_alert(self):
        db.write('UPDATE guilds SET notify_uploads=0,notify_scheduled=1')
        db.write('UPDATE telegram_routes SET notify_uploads=0,notify_scheduled=1')
        v=self.video();v['liveStreamingDetails']={'scheduledStartTime':'2026-10-04T20:00:00Z'}
        self.assertEqual(youtube.store_videos(core.CID,[v]),(1,2))
        row=db.one('SELECT * FROM telegram_deliveries')
        self.assertIn('LIVE PROGRAMADA',tg.render({'content':'{tipo}'},youtube.classify(v))['text'])
        v['liveStreamingDetails']['actualStartTime']='2026-10-04T20:00:00Z'
        self.assertEqual(youtube.store_videos(core.CID,[v]),(0,0))
        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries')['n'],1)
        ended=self.video('ended123');ended['snippet']['liveBroadcastContent']='live';ended['liveStreamingDetails']={'actualEndTime':'2026-10-02T20:00:00Z'}
        self.assertEqual(youtube.store_videos(core.CID,[ended]),(1,0))

    def test_start_identifies_only_sender_and_does_not_authorize_stranger(self):
        msg=self.update('987654321');msg['message']['from'].update(first_name='Maria',last_name='Silva',username='maria')
        tg.process_updates([msg],tg.config())
        self.assertIsNone(db.one("SELECT * FROM telegram_destinations WHERE chat_id='987654321'"))
        with patch('app.telegram.call',AsyncMock(return_value={'message_id':123})) as send:
            asyncio.run(tg.send_greetings());asyncio.run(tg.send_greetings())
        self.assertEqual(send.await_count,1)
        payload=send.call_args.args[2]
        self.assertEqual(payload['chat_id'],'987654321')
        for text in ('Maria Silva','@maria','987654321','Aguardando autorização'):self.assertIn(text,payload['text'])
        for secret in (old.TOKEN,old.ADMIN,'peralta'):self.assertNotIn(secret,payload['text'])
        self.assertNotIn('parse_mode',payload)
        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries')['n'],0)
        tg.process_updates([msg],tg.config())
        self.assertEqual(db.one('SELECT status FROM telegram_greetings')['status'],'sent')

    def test_start_without_username_and_paused_recipient_stays_paused(self):
        person=self.authorize();self.client.patch('/api/telegram/destinations/'+str(person['id']),json={'active':False},headers=self.headers)
        msg=self.update(person['chat_id']);msg['message']['from'].pop('username');msg['message']['from']['first_name']='João'
        tg.process_updates([msg],tg.config())
        dest=db.one('SELECT * FROM telegram_destinations WHERE id=?',(person['id'],))
        self.assertTrue(dest['verified']);self.assertFalse(dest['active']);self.assertFalse(tg.eligible(tg.config(),dest))
        greeting=tg.greeting_text(db.one('SELECT * FROM telegram_greetings'),tg.config())
        self.assertIn('Não definido',greeting);self.assertIn('notificações pausadas',greeting)

    def test_person_route_can_be_configured_before_start_but_cannot_receive(self):
        person=self.authorize()
        draft=self.draft();draft['destinations'].append({'destination_id':person['id'],'content':'Só para mim: {titulo}\n{link}','active':True})
        self.assertEqual(self.save(draft).status_code,200)
        result=self.client.post('/api/telegram/tests',json={'destination_id':person['id'],'content':'x'},headers=self.headers)
        self.assertEqual(result.status_code,400)
        youtube.store_videos(core.CID,[self.video()])
        self.assertIsNone(db.one('SELECT * FROM telegram_deliveries WHERE destination_id=?',(person['id'],)))
        tg.process_updates([self.update(person['chat_id'])],tg.config())
        stamp=datetime.fromtimestamp(db.ts()+5,timezone.utc).isoformat()
        self.assertEqual(youtube.store_videos(core.CID,[self.video('next-person',stamp)]),(1,3))
        row=db.one('SELECT * FROM telegram_deliveries WHERE destination_id=?',(person['id'],))
        self.assertIn('Só para mim:',tg.delivery_context(row)[1]['text'])
        self.assertEqual(tg.config()['admin_id'],old.ADMIN)
        self.assertEqual(tg.config()['private_chat_id'],'')

    def test_username_cannot_authorize_and_forwarded_start_cannot_verify(self):
        person=self.authorize()
        msg=self.update('7654321');msg['message']['from']['username']='pessoa'
        forward=self.update(person['chat_id'],update_id=2,forward_from={'id':int(person['chat_id'])})
        tg.process_updates([msg,forward],tg.config())
        self.assertFalse(db.one('SELECT verified FROM telegram_destinations WHERE id=?',(person['id'],))['verified'])
        self.assertIsNone(db.one('SELECT * FROM telegram_greetings WHERE chat_id=?',(person['chat_id'],)))
        for value in ('@pessoa','-100123','4503599627370496','0'):
            self.assertEqual(self.client.post('/api/telegram/people',json={'user_id':value},headers=self.headers).status_code,400)

    def test_remove_person_cancels_pending_and_start_does_not_reenroll(self):
        person=self.authorize();tg.process_updates([self.update(person['chat_id'])],tg.config());self.route(person['id'])
        test=self.client.post('/api/telegram/tests',json={'destination_id':person['id'],'content':'test'},headers=self.headers).json()
        row=db.one('SELECT * FROM telegram_deliveries WHERE id=?',(test['id'],))
        draft=self.draft()
        result=self.client.delete('/api/telegram/destinations/'+str(person['id']),headers=self.headers)
        self.assertEqual(result.status_code,200)
        self.assertEqual(db.one('SELECT status FROM telegram_deliveries WHERE id=?',(test['id'],))['status'],'skipped')
        self.assertIsNone(tg.delivery_context(row));self.assertEqual(self.save(draft).status_code,409)
        tg.process_updates([self.update(person['chat_id'],update_id=2)],tg.config())
        self.assertIsNone(db.one('SELECT * FROM telegram_destinations WHERE id=?',(person['id'],)))
        tg.process_updates([self.update(old.ADMIN,update_id=3)],tg.config())
        admin=db.one('SELECT id FROM telegram_destinations WHERE chat_id=?',(old.ADMIN,))
        self.assertEqual(self.client.delete('/api/telegram/destinations/'+str(admin['id']),headers=self.headers).status_code,400)

    def test_owner_change_preserves_other_authorized_people(self):
        person=self.authorize();tg.process_updates([self.update(person['chat_id'])],tg.config())
        original=db.one('SELECT * FROM telegram_destinations WHERE id=?',(person['id'],))
        async def fake(token,method,payload=None,**kw):
            return {'id':12345678,'username':'PeraltaTestBot','is_bot':True} if method=='getMe' else {'url':''}
        with patch('app.telegram.call',fake):
            result=self.client.put('/api/telegram/config',json={'revision':0,'admin_id':'77777','enabled':True},headers=self.headers)
        self.assertEqual(result.status_code,200)
        self.assertEqual(db.one('SELECT * FROM telegram_destinations WHERE id=?',(person['id'],)),original)
        self.assertTrue(tg.eligible(tg.config(),original))

    def test_greeting_rate_limits_retry_but_uncertain_does_not_duplicate(self):
        tg.process_updates([self.update('7654321')],tg.config())
        with patch('app.telegram.call',AsyncMock(side_effect=tg.TelegramError('limite',429,20))):asyncio.run(tg.send_greetings())
        self.assertEqual(db.one('SELECT status FROM telegram_greetings')['status'],'pending')
        db.write('UPDATE telegram_greetings SET next_try=0')
        with patch('app.telegram.call',AsyncMock(side_effect=tg.TelegramError('incerto',uncertain=True))) as send:
            asyncio.run(tg.send_greetings());asyncio.run(tg.send_greetings());self.assertEqual(send.await_count,1)
        self.assertEqual(db.one('SELECT status FROM telegram_greetings')['status'],'uncertain')

    def test_activity_filters_apply_before_limit_and_paginate_without_duplicates(self):
        another=self.add_dest('-1002222')
        with db.transaction() as con:
            for n in range(105):
                con.execute("INSERT INTO telegram_deliveries(destination_id,recipient_chat_id,bot_id,status,next_try,created_at,updated_at) VALUES(?,'-1002222','12345678','sent',0,1,1)",(another,))
        self.client.post('/api/telegram/tests',json={'destination_id':self.did,'content':'test'},headers=self.headers)
        data=self.client.get(f'/api/telegram/activity?destination_id={another}&status=sent').json()
        self.assertEqual(len(data['tests']),100);self.assertTrue(data['more']['tests'])
        older=self.client.get(f"/api/telegram/activity?destination_id={another}&status=sent&before={data['tests'][-1]['id']}").json()
        self.assertEqual(len(older['tests']),5);self.assertFalse(older['more']['tests'])
        self.assertFalse({r['id'] for r in data['tests']} & {r['id'] for r in older['tests']})
        pending=self.client.get('/api/telegram/activity?status=pending').json()
        self.assertEqual(len(pending['tests']),1)
        self.assertEqual(self.client.get('/api/telegram/activity?status=paused').status_code,400)
