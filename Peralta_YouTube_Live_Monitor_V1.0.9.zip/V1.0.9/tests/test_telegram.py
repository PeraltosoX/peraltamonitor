"""Integration tests with isolated SQLite data and a fake Telegram transport only."""
import asyncio
import json
import time
import unittest
from datetime import datetime, timezone
from unittest.mock import patch, AsyncMock

import httpx
from fastapi.testclient import TestClient
import test_core as core
from app import db, security, youtube, web, api_keys, telegram as tg, telegram_web as tw
from app.telegram_store import attach, DEFAULT_MESSAGE

TOKEN = '12345678:' + 'fake_test_token_' * 3
ADMIN = '123456789'


class TelegramTests(unittest.TestCase):
    def setUp(self):
        core.CoreTests.setUp(self)
        db.write('UPDATE youtube_channels SET baseline_done=1,ids_baseline_done=1,monitor_after=1')
        db.write("UPDATE telegram_config SET encrypted_token=?,admin_id=?,admin_username='peralta',bot_id='12345678',bot_username='PeraltaTestBot',enabled=1",
                 (api_keys.encrypt(TOKEN), ADMIN))
        self.client = TestClient(web.app, base_url=core.ORIGIN)
        signed = security.sign_session()
        self.client.cookies.set('plm_session', signed, domain='peraltamonitor.peraltaultrachat.shop')
        self.headers = {'Origin': core.ORIGIN, 'X-CSRF-Token': security.csrf_token(security.read_session(signed))}
        with db.transaction() as con:
            attach(con, core.CID, 'telegram', db.ts())
        self.did = self.add_dest('-100123456789', 'channel')
        self.route(self.did, 'Grupo: {titulo}\n{link}')

    def tearDown(self):
        self.client.close()

    def add_dest(self, chat, kind='channel', verified=1):
        with db.transaction() as con:
            return con.execute('INSERT INTO telegram_destinations(chat_id,kind,name,bot_id,verified,notify_after,created_at) '
                               "VALUES(?,?,?,'12345678',?,1,?)", (chat, kind, 'Destino '+chat, verified, db.ts())).lastrowid

    def route(self, did, content=DEFAULT_MESSAGE, cutoff=1):
        db.write('INSERT INTO telegram_routes(youtube_channel_id,destination_id,content,notify_after) VALUES(?,?,?,?)',
                 (core.CID, did, content, cutoff))

    def video(self, vid='tgvideo0001', published=None):
        return core.video(vid, published=published or datetime.now(timezone.utc).isoformat())

    def draft(self):
        c=self.client.get('/api/telegram/channels/'+core.CID).json()
        return {'revision':c['revision'], 'active':bool(c['channel']['active']), 'destinations':c['destinations']}

    def save(self, draft):
        return self.client.put('/api/telegram/channels/'+core.CID,json=draft,headers=self.headers)

    def update(self, sender=ADMIN, chat=None, text='/start', update_id=1, **extra):
        return {'update_id':update_id,'message':{'chat':{'id':int(chat or sender),'type':'private'},
                'from':{'id':int(sender),'is_bot':False,'username':'peralta'},'text':text,**extra}}

    def test_one_youtube_poll_fans_out_and_keeps_platform_dedupe(self):
        requested=[]
        async def fake(method, params, credential_id=None):
            requested.append(method)
            if method=='playlistItems':return {'items':[{'contentDetails':{'videoId':'tgvideo0001','videoPublishedAt':self.video()['snippet']['publishedAt']}}]}
            if method=='videos':return {'items':[self.video()]}
            raise AssertionError(method)
        with patch('app.youtube.request',fake):
            result=asyncio.run(youtube.check_playlist(core.CID,'UUtest'))
            self.assertEqual(result['queued'],2)
            again=asyncio.run(youtube.check_playlist(core.CID,'UUtest'))
            self.assertEqual(again['queued'],0)
        self.assertEqual(requested,['playlistItems','videos','playlistItems'])
        self.assertEqual(db.one('SELECT COUNT(*) AS n FROM deliveries')['n'],1)
        self.assertEqual(db.one('SELECT COUNT(*) AS n FROM telegram_deliveries')['n'],1)
        self.assertEqual(self.client.get('/api/quota-preview?interval=300').json()['channels'],1)

    def test_register_same_channel_reuses_metadata_baseline_without_youtube_calls(self):
        before=db.one('SELECT monitor_after,last_poll FROM youtube_channels')
        with patch('app.youtube.get_channel',side_effect=AssertionError('Repeated YouTube lookup')):
            for platform in ('telegram','discord','telegram'):
                asyncio.run(youtube.register_channel(core.CID,platform=platform))
        self.assertEqual(db.one('SELECT monitor_after,last_poll FROM youtube_channels'),before)
        self.assertEqual(db.one('SELECT COUNT(*) n FROM youtube_channels')['n'],1)

    def test_telegram_only_registration_does_not_appear_in_discord(self):
        cid='UC'+'b'*22
        info={'channel_id':cid,'name':'Only Telegram','uploads_id':'UUnew','thumbnail':''}
        with patch('app.youtube.get_channel',AsyncMock(return_value=info)),patch('app.youtube.latest_video_ids',AsyncMock(return_value=[{'video_id':'known-id'}])):
            asyncio.run(youtube.register_channel(cid,'telegram'))
        row=db.one('SELECT active,removed,discord_enabled FROM youtube_channels WHERE channel_id=?',(cid,))
        self.assertEqual(row,{'active':1,'removed':0,'discord_enabled':0})
        self.assertNotIn(cid,[x['channel_id'] for x in self.client.get('/api/channel-editor').json()])
        with patch('app.youtube.get_channel',side_effect=AssertionError('No extra call')):
            asyncio.run(youtube.register_channel(cid,'discord'))
        self.assertEqual(db.one('SELECT discord_active FROM youtube_channels WHERE channel_id=?',(cid,))['discord_active'],1)

    def test_pause_and_remove_discord_keeps_telegram_working(self):
        r=self.client.patch('/api/youtube-channels/'+core.CID,json={'active':False},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(db.one('SELECT active FROM youtube_channels')['active'],1)
        self.assertEqual(youtube.store_videos(core.CID,[self.video()]),(1,1))
        r=self.client.delete('/api/youtube-channels/'+core.CID,headers=self.headers)
        self.assertEqual(r.status_code,200)
        self.assertEqual(db.one('SELECT active,removed FROM youtube_channels'),{'active':1,'removed':0})
        self.assertEqual(youtube.store_videos(core.CID,[self.video('next000001')]),(1,1))
        self.assertEqual(db.one('SELECT COUNT(*) n FROM deliveries')['n'],0)

    def test_pause_and_remove_telegram_keeps_discord_working(self):
        draft=self.draft();draft['active']=False
        self.assertEqual(self.save(draft).status_code,200)
        self.assertEqual(youtube.store_videos(core.CID,[self.video()]),(1,1))
        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries')['n'],0)
        self.assertEqual(self.client.delete('/api/telegram/channels/'+core.CID,headers=self.headers).status_code,200)
        self.assertEqual(db.one('SELECT active,removed FROM youtube_channels'),{'active':1,'removed':0})
        self.assertEqual(youtube.store_videos(core.CID,[self.video('next000002')]),(1,1))

    def test_two_destinations_have_independent_messages_and_safe_html(self):
        second=self.add_dest('-10022222222');self.route(second,'<b>{canal}</b> / {titulo}\n{link}')
        db.write("UPDATE telegram_routes SET parse_mode='HTML' WHERE destination_id=?",(second,))
        v=self.video();v['snippet']['title']='<script>alert("x")</script>'
        youtube.store_videos(core.CID,[v])
        items=db.rows('SELECT * FROM telegram_deliveries ORDER BY id')
        first=tg.delivery_context(items[0])[1];last=tg.delivery_context(items[1])[1]
        self.assertIn('Grupo: <script>',first['text'])
        self.assertNotIn('parse_mode',first)
        self.assertIn('&lt;script&gt;',last['text'])
        self.assertEqual(last['parse_mode'],'HTML')
        self.assertNotEqual(first['chat_id'],last['chat_id'])
        for content in ('<img src=x onerror=alert(1)>','<a href="javascript:alert(1)">x</a>','<b>broken'):
            self.assertEqual(self.client.post('/api/telegram/preview',json={'content':content,'parse_mode':'HTML'},headers=self.headers).status_code,400)

    def test_save_is_atomic_and_stale_edits_are_rejected(self):
        draft=self.draft();before=db.rows('SELECT * FROM telegram_routes')
        draft['destinations'][0]['content']='updated'
        draft['destinations'].append({'destination_id':999999,'content':'invalid'})
        self.assertEqual(self.save(draft).status_code,400)
        self.assertEqual(db.rows('SELECT * FROM telegram_routes'),before)
        draft=self.draft();self.assertEqual(self.save(draft).status_code,200)
        self.assertEqual(self.save(draft).status_code,409)
        self.assertEqual(db.rows('SELECT * FROM telegram_routes'),before)

    def test_new_and_resumed_destination_skip_old_publications(self):
        draft=self.draft();draft['destinations'][0]['active']=False;self.assertEqual(self.save(draft).status_code,200)
        draft=self.draft();draft['destinations'][0]['active']=True;self.assertEqual(self.save(draft).status_code,200)
        cutoff=db.one('SELECT notify_after FROM telegram_routes')['notify_after']
        old=datetime.fromtimestamp(cutoff-10,timezone.utc).isoformat()
        fresh=datetime.fromtimestamp(cutoff+10,timezone.utc).isoformat()
        youtube.store_videos(core.CID,[self.video('old00000001',old),self.video('new00000001',fresh)])
        self.assertEqual([x['video_id'] for x in db.rows('SELECT video_id FROM telegram_deliveries')],['new00000001'])

    def test_private_ignores_strangers_forwarded_messages_and_group_admins(self):
        items=[self.update('888',update_id=1),self.update(update_id=2,forward_origin={'type':'user'}),self.update(update_id=3,chat='888')]
        group=self.update(update_id=4);group['message']['chat']['type']='supergroup';items.append(group)
        tg.process_updates(items,tg.config())
        self.assertEqual(tg.config()['private_chat_id'],'')
        self.assertIsNone(db.one("SELECT * FROM telegram_destinations WHERE kind='private' AND verified=1"))
        self.assertIsNone(db.one("SELECT * FROM telegram_destinations WHERE chat_id='888'"))
        self.assertEqual(tg.config()['update_offset'],5)
        tg.process_updates([self.update(update_id=5)],tg.config())
        self.assertEqual(tg.config()['private_chat_id'],ADMIN)
        self.assertEqual(db.one("SELECT chat_id FROM telegram_destinations WHERE kind='private'")['chat_id'],ADMIN)
        tg.process_updates([self.update('999',update_id=6)],tg.config())
        self.assertEqual(tg.config()['private_chat_id'],ADMIN)

    def test_private_works_without_any_channel_or_group_destination(self):
        db.write('DELETE FROM telegram_routes');db.write('DELETE FROM telegram_destinations')
        tg.process_updates([self.update()],tg.config())
        dest=db.one('SELECT * FROM telegram_destinations')
        self.route(dest['id'])
        # Publication comes after the administrator actually starts the bot.
        stamp=datetime.fromtimestamp(time.time()+2,timezone.utc).isoformat()
        youtube.store_videos(core.CID,[self.video(published=stamp)])
        row=db.one('SELECT * FROM telegram_deliveries')
        self.assertEqual(tg.delivery_context(row)[1]['chat_id'],ADMIN)
        self.assertEqual(db.one("SELECT COUNT(*) n FROM telegram_destinations WHERE kind<>'private'")['n'],0)

    def test_owner_change_revokes_old_private_and_never_exposes_token(self):
        tg.process_updates([self.update()],tg.config());dest=db.one("SELECT * FROM telegram_destinations WHERE kind='private'")
        r=self.client.post('/api/telegram/tests',json={'destination_id':dest['id'],'content':'test'},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        item=db.one('SELECT * FROM telegram_deliveries WHERE id=?',(r.json()['id'],))
        async def fake(token, method, payload=None, **kw):
            return {'id':12345678,'username':'PeraltaTestBot','is_bot':True} if method=='getMe' else {'url':''}
        with patch('app.telegram.call',fake):
            r=self.client.put('/api/telegram/config',json={'revision':tg.config()['revision'],'admin_id':'99999','admin_username':'new_owner','enabled':True},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        self.assertNotIn(TOKEN,r.text);self.assertNotIn('encrypted_token',r.text)
        self.assertNotEqual(tg.config()['encrypted_token'],TOKEN)
        self.assertEqual(tg.token_of(tg.config()),TOKEN)
        self.assertEqual(tg.config()['private_chat_id'],'')
        self.assertEqual(db.one('SELECT status FROM telegram_deliveries')['status'],'skipped')
        self.assertIsNone(tg.delivery_context(item))
        tg.process_updates([self.update(update_id=2)],tg.config())
        self.assertEqual(tg.config()['private_chat_id'],'')
        tg.process_updates([self.update('99999',update_id=3)],tg.config())
        self.assertEqual(tg.config()['private_chat_id'],'99999')

    def test_stale_poll_cannot_bind_previous_owner_or_bot(self):
        snapshot=tg.config()
        db.write("UPDATE telegram_config SET revision=revision+1,admin_id='987654'")
        tg.process_updates([self.update()],snapshot)
        self.assertEqual(tg.config()['private_chat_id'],'')
        self.assertEqual(tg.config()['update_offset'],0)

    def test_bot_switch_revokes_destinations_and_cancels_pending(self):
        youtube.store_videos(core.CID,[self.video()]);item=db.one('SELECT * FROM telegram_deliveries')
        async def fake(token, method, payload=None, **kw):
            return {'id':44444,'username':'NewBot','is_bot':True} if method=='getMe' else {'url':''}
        with patch('app.telegram.call',fake):
            r=self.client.put('/api/telegram/config',json={'revision':0,'admin_id':ADMIN,'enabled':True,'token':'44444:'+'x'*30},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(db.one('SELECT verified FROM telegram_destinations')['verified'],0)
        self.assertEqual(db.one('SELECT status FROM telegram_deliveries')['status'],'skipped')
        self.assertIsNone(tg.delivery_context(item))

    def test_permission_checks_reject_private_and_non_admin_bots(self):
        async def fake(token, method, payload=None, **kw):
            if method=='getChat':return {'id':-10055,'type':'channel','title':'Test'}
            return {'status':'administrator','can_post_messages':False}
        with patch('app.telegram.call',fake):
            r=self.client.post('/api/telegram/destinations',json={'chat_id':'-10055'},headers=self.headers)
        self.assertEqual(r.status_code,400)
        self.assertEqual(self.client.post('/api/telegram/destinations',json={'chat_id':ADMIN},headers=self.headers).status_code,400)
        async def allowed(token, method, payload=None, **kw):
            if method=='getChat':return {'id':-10055,'type':'channel','title':'Test'}
            return {'status':'administrator','can_post_messages':True}
        with patch('app.telegram.call',allowed):
            r=self.client.post('/api/telegram/destinations',json={'chat_id':'-10055'},headers=self.headers)
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(r.json()['chat_id'],'-10055')

    def test_webhook_conflict_is_reported_without_disabling_external_service(self):
        methods=[]
        async def fake(token, method, payload=None, **kw):
            methods.append(method)
            return {'id':12345678,'username':'PeraltaTestBot','is_bot':True} if method=='getMe' else {'url':'https://secret.example/webhook'}
        with patch('app.telegram.call',fake):
            r=self.client.put('/api/telegram/config',json={'revision':0,'admin_id':ADMIN,'enabled':True},headers=self.headers)
        self.assertEqual(r.status_code,400)
        self.assertEqual(methods,['getMe','getWebhookInfo'])
        self.assertNotIn('secret.example',r.text)
        self.assertEqual(tg.config()['revision'],0)

    def test_success_rate_limit_and_uncertain_results_do_not_auto_duplicate(self):
        youtube.store_videos(core.CID,[self.video()])
        with patch('app.telegram.call',AsyncMock(side_effect=tg.TelegramError('Rate limited',429,retry_after=50))):
            asyncio.run(tg.send_pending())
        row=db.one('SELECT * FROM telegram_deliveries')
        self.assertEqual(row['status'],'pending');self.assertGreaterEqual(row['next_try'],db.ts()+48)
        db.write('UPDATE telegram_deliveries SET next_try=0')
        with patch('app.telegram.call',AsyncMock(side_effect=tg.TelegramError('Unconfirmed',uncertain=True))) as fake:
            asyncio.run(tg.send_pending());asyncio.run(tg.send_pending());self.assertEqual(fake.await_count,1)
        self.assertEqual(db.one('SELECT status FROM telegram_deliveries')['status'],'uncertain')
        self.assertEqual(self.client.post('/api/telegram/deliveries/'+str(row['id'])+'/retry',json={},headers=self.headers).status_code,400)
        self.assertEqual(self.client.post('/api/telegram/deliveries/'+str(row['id'])+'/retry',json={'confirm_uncertain':True},headers=self.headers).status_code,200)
        with patch('app.telegram.call',AsyncMock(return_value={'message_id':567})) as fake:
            asyncio.run(tg.send_pending());asyncio.run(tg.send_pending());self.assertEqual(fake.await_count,1)
        self.assertEqual(db.one('SELECT status,message_id FROM telegram_deliveries'),{'status':'sent','message_id':'567'})

    def test_transport_redacts_token_and_distinguishes_connection_from_read_timeout(self):
        class Client:
            def __init__(self,*a,**kw):pass
            async def __aenter__(self):return self
            async def __aexit__(self,*a):pass
            async def post(self,*a,**kw):raise httpx.ReadTimeout('https://api.telegram.org/bot'+TOKEN+'/sendMessage')
        with patch('app.telegram.httpx.AsyncClient',Client):
            with self.assertRaises(tg.TelegramError) as result:asyncio.run(tg.call(TOKEN,'sendMessage',{},sending=True))
        self.assertTrue(result.exception.uncertain);self.assertNotIn(TOKEN,str(result.exception))
        async def connect_error(*a,**kw):raise httpx.ConnectTimeout(TOKEN)
        with patch.object(Client,'post',connect_error),patch('app.telegram.httpx.AsyncClient',Client):
            with self.assertRaises(tg.TelegramError) as result:asyncio.run(tg.call(TOKEN,'sendMessage',{},sending=True))
        self.assertFalse(result.exception.uncertain);self.assertGreater(result.exception.retry_after,0)

    def test_history_cleaning_retains_dedupe_and_other_platform_history(self):
        youtube.store_videos(core.CID,[self.video()]);db.write("UPDATE telegram_deliveries SET status='sent'")
        self.client.post('/api/telegram/tests',json={'destination_id':self.did,'content':'test'},headers=self.headers)
        db.log('telegram','info','Telegram log');db.log('worker','info','Shared log')
        r=self.client.delete('/api/telegram/activity/deliveries',headers=self.headers)
        self.assertEqual(r.json()['cleared'],1)
        self.assertEqual(len(self.client.get('/api/telegram/activity').json()['deliveries']),0)
        self.assertEqual(len(self.client.get('/api/telegram/activity').json()['tests']),1)
        self.assertEqual(db.one('SELECT COUNT(*) n FROM deliveries')['n'],1)
        youtube.store_videos(core.CID,[self.video()])
        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries WHERE video_id IS NOT NULL')['n'],1)
        self.client.delete('/api/logs',headers=self.headers)
        self.assertIsNotNone(db.one("SELECT * FROM logs WHERE service='telegram'"))
        self.client.delete('/api/telegram/activity/logs',headers=self.headers)
        self.assertIsNone(db.one("SELECT * FROM logs WHERE service='telegram'"))

    def test_all_mutations_require_csrf_and_reads_require_login(self):
        with TestClient(web.app,base_url=core.ORIGIN) as anon:
            for path in ('config','destinations','channels','templates','activity'):
                self.assertEqual(anon.get('/api/telegram/'+path).status_code,401)
        for method,path in [('PUT','config'),('POST','destinations'),('POST','people'),('POST','channels'),('POST','tests'),('DELETE','activity/tests')]:
            self.assertEqual(self.client.request(method,'/api/telegram/'+path,json={}).status_code,403)


if __name__=='__main__':unittest.main()
