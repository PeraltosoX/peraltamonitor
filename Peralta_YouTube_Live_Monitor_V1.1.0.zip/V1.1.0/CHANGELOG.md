# V1.1.0 — 22/10/2026

- Fila contínua com prioridade pelo horário mais atrasado, sem espera por lotes completos.
- Configuração Consultas simultâneas de 1 a 10 (padrão 10), persistida no banco.
- Mínimo de Verificar a cada reduzido de 30 para 10 segundos no painel, na API, na previsão de cota e no worker; intervalo existente preservado.
- Próxima consulta e pausa após falha individuais, contadas após concluir cada canal.
- Bloqueio por canal e limite global compartilhados entre painel/monitor via flock no diretório de dados, com recuperação após encerramento/crash e proteção de processo suspenso.
- HTTPX compartilhado, reutilização de conexões, limites de requisição/verificação, tentativas limitadas e encerramento coordenado das tarefas.
- Reservas transacionais de cota antes do HTTP; chamadas em andamento já usam saldo. Agrupamento por projeto, pausa de taxa distinta da cota diária e preservação da pausa diante de sucesso atrasado.
- Migração aditiva do esquema 109 para 110; mantém banco, credenciais, configurações, pessoas autorizadas, históricos, IDs e deduplicação.
- Novos testes com 100 canais, falhas/lentidão, consultas manuais concorrentes, processos reais, cota esgotada, reinicialização e conexão HTTP local persistente.
- Documentação e guias de instalação/atualização em oito passos atualizados. Regras de classificação, filtros, destinos e envio Discord/Telegram preservadas.

---

# V1.0.9 — 03/10/2026

## Revisão documental de 11/10/2026 — permanece V1.0.9

- Acrescentados TXT de instalação nova, atualização em oito passos e funcionamento/continuidade; disponíveis também separadamente.
- Guia de atualização sem `--retry-all-errors`, com laço Bash de espera e confirmação de saúde/versão.
- Identificação da pasta de origem V1.0.5–V1.0.8 pelas etiquetas do container; bloqueio de sobrescrita de V1.0.9 já instalada.
- Referências atuais de domínio e `.env.example` atualizadas para `monitor.p7nexus.online`; usuário confirmou o acesso normal.
- Incluído backup opcional do Caddyfile junto de `.env` e banco no guia.
- Código funcional, imagem declarada, dependências, ícone e versão preservados. Nenhuma nova função nem alteração na VPS.

- Mantida a organização do menu lateral, conforme solicitado; sem grupos recolhíveis.
- “Live agendada” passa a “Live programada” em rótulos, prévias e substituição de `{tipo}`. Modelos escritos pelo usuário são preservados.
- Classificação cruza o sinalizador do YouTube com os horários programado, efetivo e de encerramento. Evita que sinais existentes de transmissão sejam ignorados e que uma live encerrada com sinalizador defasado vire novo aviso.
- Telegram: Pessoas autorizadas por ID, mantendo o administrador e permitindo teste, pausa, retomada, edição do nome e remoção de outros destinatários privados.
- `/start` somente no Telegram: nome, @usuário, ID e autorização de quem iniciou. Desconhecidos recebem suas próprias informações, sem liberação automática de avisos.
- Editor Telegram em Destinos → Mensagem → Revisar; destino destacado na edição e prévia. O editor Discord mantém as três etapas e sincroniza o destino da prévia com a edição individual.
- Estados explícitos de conexão pendente, pausa e canal sem destino pronto.
- Histórico Telegram com filtros por destinatário e situação e paginação de entregas/testes.
- Atualizações visuais suspensas na aba oculta; listas preservam elementos sem mudança e foco. Busca e envio continuam no worker.
- Migração aditiva da V1.0.8, mantendo os campos e registros anteriores. Ícone, `.env`, credenciais e dados não precisam ser substituídos.
- 71 testes automatizados aprovados, incluindo quatro versões de migração e as novas regressões. Guia mantido em oito passos separados.

---

# Histórico de versões

## V1.0.8 — 2026-09-28

- Telegram separado no menu: Bot e administrador, Canais e grupos, Meu privado, Canais e avisos, Modelos e Entregas e logs.
- Token cifrado, ID numérico do administrador e @usuário configurados pelo painel; validação da identidade do bot e das permissões de publicação.
- Privado exclusivo do ID cadastrado, vinculado após iniciar o bot, sem necessidade de grupo ou canal; outros usuários não são cadastrados. Troca de bot ou administrador revoga o vínculo anterior.
- Busca global compartilhada por Channel ID do YouTube, sem multiplicar consultas ao adicionar a segunda plataforma. Estados de pausa/remoção, mensagens e filas independentes.
- Mensagens de texto simples ou HTML, prévia de link, envio sem som, modelos copiados por destino, prévia e teste de rascunho.
- Histórico próprio de entregas/testes/logs, limpeza separada e reenvio confirmado; respostas incertas nunca são reenviadas automaticamente.
- Aba Associações removida; edição concentrada em Canais e avisos, preservando os vínculos e estilos existentes.
- Mesma identidade vermelha/azul, ícone e preferência claro/escuro. Layout adaptado para celular e tablet.
- Migração aditiva de V1.0.5/V1.0.6/V1.0.7; 60 testes automatizados e conferência visual em Chromium.
- Guia de atualização no padrão de oito passos, com backup, espera por saúde com retry-all-errors e confirmação da versão.

## V1.0.7 — 2026-09-27

- Novo layout baseado no painel do servidor ChatFlow Peralta 3.0.3: menu lateral com ícones, cabeçalho compacto e painéis arredondados, com identidade vermelha e azul.
- Fonte sem serifa em todo o painel, títulos diretos e controles agrupados por função. Ícone original mantido.
- Botão para alternar entre modo claro e escuro, disponível no painel e no login. Preferência salva no navegador e aplicada também aos editores.
- Entregas e logs organizados em três abas: Entregas recentes, Testes por destino e Logs do sistema. Cada uma tem seu botão de limpeza.
- Limpeza persistente de entregas e testes finalizados sem retirar itens pendentes/em envio nem apagar o controle contra duplicações. Contadores e configurações preservados.
- Acompanhamento de teste no editor continua funcionando mesmo quando outra aba limpa seu histórico.
- Editor com servidor/destino destacado, etapas mais claras e prévia ao lado no computador; adaptação para celular com menu recolhível.
- Migração aditiva da V1.0.6 e compatibilidade com a V1.0.5 verificadas, incluindo mensagens diferentes por destino.

## V1.0.6 — 2026-09-27

- Redesign do painel: fundo claro, cabeçalho escuro, detalhes em vermelho, navegação horizontal, lista de canais pesquisável, filtros e edição em painel lateral. Ícone e imagem originais preservados.
- Fluxo por canal: Destinos → Mensagem → Revisar, com salvamento atômico e detecção de edição concorrente da configuração.
- Mensagem e estilo independentes por servidor e canal Discord: prévia do YouTube ou embed personalizado, opções de tipos de publicação e @everyone por destino.
- Uso de modelos existentes e criação de cópias com nome do canal/servidor/destino. A personalização não altera modelos usados por outros canais.
- Prévia renderizada pelo mesmo código do bot, usando publicação já conhecida ou exemplo; sem consulta adicional à API YouTube.
- Teste do rascunho em um destino escolhido, com confirmação e todas as menções bloqueadas. Resultado acompanhado no editor e no histórico de testes.
- Pausa/retomada por destino e cancelamento apenas das pendências afetadas, preservando histórico, IDs e demais destinos.
- Entregas com nomes do canal YouTube, servidor e canal Discord, estados traduzidos, motivo de falha, filtros e confirmação para reenvio manual.
- Estimativa diária de consultas de playlist conforme intervalo e canais ativos, sem multiplicar a estimativa pelo número de destinos.
- Migração aditiva a partir da V1.0.5: mantém banco, credenciais cifradas, configurações, associações, modelos, cotas e marcos de início. Canais não editados seguem a configuração anterior.
- Correção de isolamento: um destino criado na edição de um canal não passa a receber avisos dos outros canais do mesmo servidor. Remover um destino padrão não desativa destinos individuais restantes.
- Backup com abertura da origem em modo somente leitura, conferência de integridade, proteção contra sobrescrita e permissão restrita no arquivo gerado.
- Mantidos login, OAuth exclusivo do proprietário, múltiplas APIs e troca de chave, consultas apenas de IDs novos, deduplicação, associações, editor de modelos, remoções e limpeza de logs.

## V1.0.5 — 2026-09-23

- Descoberta somente pela playlist de uploads (`playlistItems.list`). `search.list` e WebSub não são utilizados. Apenas IDs novos e elegíveis entram em lotes de `videos.list`; rodada sem ID novo não faz chamada `videos.list`.
- IDs existentes na playlist no cadastro e IDs publicados antes do início da atualização viram linha de base sem consulta de detalhes e sem avisos. IDs publicados após esse marco podem ser tratados já na primeira verificação. IDs antigos vistos posteriormente com data anterior ao início também são guardados sem `videos.list`. A consulta antiga de vídeos já conhecidos foi removida. Falha ao buscar detalhes deixa os novos IDs para nova tentativa.
- Playlist verifica até 50 IDs por página, consultando páginas adicionais apenas em uma sequência cheia sem ID conhecido, até cinco páginas por rodada. Um aviso continua único quando uma live agendada muda para ao vivo.
- Novo painel com cronômetro da próxima consulta, estado/último erro/novos IDs de cada canal, imagem da marca e favicon enviado pelo usuário.
- Um servidor Discord aceita vários canais de aviso; o destino atual é migrado. Cada entrega é identificada por vídeo, servidor e destino; há botão de teste por canal e resultados visíveis.
- Botões para apagar associação, canal YouTube e logs do painel. As remoções cancelam pendências relacionadas, preservando o histórico de envios e os IDs para evitar repetição.
- Migração não destrutiva das tabelas antigas: cria `seen_video_ids` e `guild_destinations`, adapta a unicidade de `deliveries`, preserva `.env`, banco, avisos e configuração do servidor. Faça backup antes de atualizar.

## V1.0.4 — 2026-09-23

- A busca de lives agendadas ganha intervalo próprio no painel: padrão 300 segundos, mínimo 30, sem alongamento automático para ~19 minutos.
- Retira o bloqueio global de 80 buscas automáticas diárias. A contagem local passa a ser por chave; após 100 tentativas ou erro, tenta a próxima credencial disponível em ordem. A cota oficial continua por projeto Google, compartilhada por chaves do mesmo projeto.
- Mostra o consumo local das buscas em cada chave e distingue os intervalos da playlist e das lives.
- A migração cria a tabela `search_key_usage` e preserva as demais configurações e registros. A nova estimativa por chave começa zerada, mas o Google pode esgotar a cota real antes e responder 403.

## V1.0.3 — 2026-09-23

- Prévia grande do YouTube como padrão para lives e vídeos: o bot envia o link em linha própria e o Discord cria o cartão com capa e reprodução.
- Modo de prévia configurável em **Mensagem e embed**; o embed personalizado continua disponível e usa imagem grande em vez de miniatura.
- Modelos existentes preservam texto, título e demais campos e passam ao modo YouTube. É possível voltar ao modo personalizado no painel.
- A migração acrescenta apenas o modo de prévia ao banco. Mantém a regra da V1.0.2 de avisar somente publicações criadas após a associação.
- Informa nos logs quando o canal de destino não tem permissão de inserir links com prévia.

## V1.0.2 — 2026-09-23

- Nova regra de início: ao associar um canal YouTube ao servidor Discord, publicações existentes ficam registradas sem aviso; somente as criadas depois são notificadas.
- Ignora vídeos e lives antigos que aparecerem tardiamente na API, comparando a data de publicação com o início da associação.
- Remove a recuperação retroativa da V1.0.1. Na migração, associações ativas recebem um novo marco de início e entregas antigas ainda pendentes são marcadas como ignoradas, sem apagar os registros.
- Corrige o tipo apresentado no Discord para distinguir LIVE AGENDADA, LIVE AO VIVO e NOVO VÍDEO.
- Mantém as configurações, o banco de dados, a busca controlada de agendamentos e o intervalo mínimo de 30 segundos para a playlist.

## V1.0.1 — 2026-09-23

- Recupera para o Discord as lives ainda agendadas e vídeos novos vistos na última hora quando uma associação ou servidor é ativado, e ao iniciar o worker após a atualização. Não repete entregas existentes.
- Busca lives agendadas pelo canal com `search.list` sob limite local diário de 100 chamadas, respeitando o intervalo automático por quantidade de canais; botão de verificação manual no painel.
- Corrige o tópico WebSub para `/feeds/videos.xml` e mantém o monitoramento por playlist e `videos.list`.
- Aceita 30 segundos como mínimo da recuperação da playlist; o valor inicial continua 300 segundos.
- Migração preserva o banco e os segredos de V1.0.0; acrescenta a coluna da última busca e a tabela de uso de buscas. Mantenha backup antes de atualizar.

## V1.0.0 — 2026-09-23

- Painel privado com login, proteção CSRF e interface para servidores, canais, associações, modelos e logs.
- Instalação Discord via OAuth2 iniciada no painel e vinculada ao Discord User ID autorizado.
- Servidores adicionados por convite externo permanecem sem autorização; ativação exige verificação no painel.
- Worker YouTube com WebSub e recuperação por playlist/vídeos; linha de base, persistência dos IDs e entregas por servidor.
- Cinco espaços iniciais de API keys, novas entradas ilimitadas, cifragem em repouso, medição por chave e uso sequencial com espera/failover em erro ou cota.
- Notificação única para live programada detectada, live já iniciada ou vídeo/Short novo.
- Implantação Docker Compose com porta local 8081 e dados separados do Auto Server.
