# Peralta YouTube Live Monitor — V1.1.0

Atualizado em 22/10/2026. Base: V1.0.9 anexada. A V1.1.0 implementa uma fila contínua de consultas simultâneas e permite intervalo mínimo de 10 segundos. Domínio de configuração preservado: https://monitor.p7nexus.online. Esta entrega não foi instalada na VPS.

- [Instalação nova em TXT](INSTALAR_PERALTA_V1.1.0.txt)
- [Atualização em oito passos — TXT](ATUALIZAR_PERALTA_V1.1.0.txt)
- [Funcionamento e continuidade em TXT](FUNCIONAMENTO_PERALTA_V1.1.0.txt)

A V1.0.9 corrige a classificação de lives com metadados de início, usa o nome **Live programada** e permite **várias pessoas autorizadas no privado do Telegram**. O `/start` do bot Telegram responde com nome, @usuário, ID e situação de autorização de quem o enviou. Discord e Telegram continuam separados e compartilham a busca de cada canal YouTube.

O menu mantém a mesma organização, sem grupos recolhíveis. A aba “Meu privado” passa a se chamar **Pessoas autorizadas**. O layout do ChatFlow Peralta 3.0.3 permanece em vermelho e azul, com modo claro/escuro salvo. A aba **Associações foi retirada**: configure os destinos em **Canais e avisos**, na seção de cada plataforma. Os vínculos existentes continuam funcionando.

O ícone original foi preservado. O projeto continua com `web`, `worker` e `bot`, porta local **8081**, projeto Compose `peralta_live_monitor` e banco em `/opt/peralta-live-monitor/data`. O domínio e o Caddy existentes continuam sendo usados.

**Para atualizar uma instalação existente, siga [ATUALIZAR_SEM_PERDER_DADOS.md](ATUALIZAR_SEM_PERDER_DADOS.md).** Não substitua o `.env` pela `.env.example`. A `APP_SECRET` existente precisa ser mantida para abrir as chaves cifradas.

## Consultas simultâneas — V1.1.0

- **Consultas simultâneas:** de 1 a 10, padrão 10, salvo no SQLite; inclui consultas automáticas e manuais do painel, somadas entre os processos.
- **Verificar a cada:** de 10 a 86.400 segundos. O valor anterior é preservado na atualização; uma instalação nova mantém 300s como padrão. Há atalho de 10s no painel.
- Cada canal tem `next_poll_at`, pausa de erro e horário de conclusão próprios. A próxima consulta automática pode começar depois de `conclusão + intervalo`, quando houver uma vaga.
- A fila prioriza o menor horário de próxima tentativa. Ao terminar qualquer tarefa, admite outro canal sem aguardar o restante do grupo. Mudanças feitas no painel são percebidas em até aproximadamente 1s quando a fila está ociosa.
- **Verificar agora** pode antecipar o intervalo normal, mas respeita bloqueios, limite global, pausas de erro e cota. Se já houver consulta do mesmo canal ou todas as vagas estiverem ocupadas, o painel informa isso (HTTP 409). Pausa após erro responde 429 com `Retry-After`.
- Reduzir o limite deixa as consultas já iniciadas terminarem. Nenhuma nova consulta entra enquanto o total estiver no novo limite ou acima dele.
- O mesmo canal vinculado a vários destinos continua tendo uma única busca. Classificação, filtros, IDs conhecidos e deduplicação permanecem iguais aos da V1.0.9.

### Limites, falhas e encerramento

Pool HTTPX compartilhado por processo/event loop, com 16 conexões e até 16 conexões reutilizáveis: capacidade para 10 verificações e chamadas de apoio do painel/Telegram. HTTPX: conexão 8s, leitura/escrita 20s, espera de conexão do pool 5s; limite total de 25s por tentativa YouTube e 90s por verificação de canal. No máximo três credenciais por requisição, sem repetir a mesma credencial nessa tentativa.

Falha de canal libera a vaga, registra o erro e aguarda 30, 60, 120, 240, 480 e até 900 segundos em falhas consecutivas. O intervalo configurado também precisa ter terminado. Sucesso zera essa sequência. Não há repetição imediata em laço. No encerramento, as tarefas são canceladas/aguardadas antes de fechar o pool; o web tem 25s para concluir requisições antes do cancelamento e o Compose concede 35s ao serviço.

### Proteção entre processos

Bloqueios `flock` por canal e por vaga em `data/poll-locks`, coordenados por uma trava curta de admissão, asseguram exclusão entre `web` e `worker`. O banco guarda o responsável/horário para exibir estado e próxima verificação. Bloqueios são liberados pelo kernel na morte do processo: um processo apenas suspenso conserva sua posse, evitando duplicidade por expiração de uma lease. Metadados abandonados são recuperados no início e periodicamente; um novo responsável também pode ocupar um bloqueio liberado imediatamente.

Os serviços precisam compartilhar o mesmo diretório de dados em disco local da mesma VPS Linux. Não usar cópias separadas de `data`, NFS ou executar a versão antiga junto da nova. Não apagar nem substituir arquivos de bloqueio com os serviços rodando.

### Cota compartilhada

Cada tentativa é reservada e contabilizada **antes do HTTP**, numa transação `BEGIN IMMEDIATE`. Chamadas em andamento, interrompidas e sem resposta confirmada continuam contabilizadas por cautela. Não há débito novamente quando a resposta chega. Reiniciar não devolve saldo.

Chaves com o mesmo **ID de projeto Google** compartilham o saldo e as pausas de cota/taxa. O menor limite configurado para esse grupo é aplicado. Chaves sem ID usam um único grupo conservador. Para a chave do `.env`, `YOUTUBE_API_PROJECT_ID` é opcional; preencher com o ID real permite agrupá-la com as chaves do painel do mesmo projeto. A atualização não altera o `.env` existente.

`quotaExceeded`/limite diário pausa o projeto até a virada do dia de cota em America/Los_Angeles, com margem de 60s. HTTP 429/limite de taxa usa pausa temporária e respeita `Retry-After`; não é tratado automaticamente como esgotamento diário. Uma resposta de sucesso atrasada não apaga uma pausa mais recente. Sem credencial elegível, o worker suspende novos pedidos, mantendo heartbeat e reavaliando a disponibilidade sem chamar o YouTube.

A estimativa é local: não observa outros programas usando o projeto. Chaves adicionais não aumentam a cota oficial. A 100 canais, uma página por consulta representa cerca de **288.000 chamadas/dia a 30s** ou **864.000 a 10s**, antes de considerar duração das consultas, espera, detalhes, páginas extras e tentativas. É necessário ajustar a frequência à cota realmente concedida pelo Google.

## Layout e temas

O menu lateral, o cabeçalho compacto, os painéis arredondados e a família de fonte sem serifa seguem a referência do ChatFlow Peralta. O ícone continua sendo o original deste monitor.

No canto superior, use o botão **Modo claro / Modo escuro**. No celular ele aparece com o ícone de sol ou lua. A escolha vale para todo o painel, inclusive a tela de login e os editores, e fica salva neste navegador. Na primeira abertura, o tema é escuro; limpar os dados do navegador também remove essa preferência. O tema não altera as cores dos embeds enviados ao Discord.

O painel suspende as consultas automáticas e a contagem visual quando a aba fica oculta. Ao voltar, atualiza os dados; o worker continua buscando e enviando avisos. As listas atualizam os elementos alterados sem recriar controles iguais.

Os dois editores seguem **Destinos → Mensagem → Revisar**, com o destino destacado ao lado da edição e da prévia. Canais ativos sem destino elegível mostram **Sem destino pronto**.

No celular, o botão de menu abre as mesmas áreas do painel. Em **Entregas e logs**, escolha a aba do histórico desejado. No editor de mensagens, o servidor e o canal selecionados aparecem em um bloco destacado para deixar claro qual destino está sendo configurado.

## Configurar os avisos do Discord

1. Abra **Canais e avisos** e clique em **Adicionar canal**. Informe o Channel ID `UC…`, como na versão anterior. O cadastro leva diretamente à edição.
2. Em **Destinos**, escolha o servidor e o canal Discord. Adicione quantos destinos precisar, inclusive vários no mesmo servidor.
3. Em cada destino, clique em **Editar mensagem e estilo**. Em **Servidor e canal que você está editando**, confirme o servidor/canal desejado.
4. Escolha **Usar modelo existente** ou **Personalizar para este destino**. Uma cópia recebe, por padrão, o nome do canal YouTube, do servidor e do destino; o nome também pode ser editado.
5. Defina a mensagem e o estilo: prévia nativa do YouTube ou embed personalizado com título, descrição, rodapé, imagem e cor. Cada destino tem suas próprias opções de vídeos/Shorts, lives e `@everyone`.
6. Troque de destino na prévia para conferir cada mensagem. **Enviar teste neste destino** coloca uma mensagem real na fila do bot, com todas as menções bloqueadas. Você confirma o destino antes do teste. A prévia não chama a API YouTube e o teste não salva o rascunho.
7. Abra **Revisar**, confira todos os destinos, modelos e estados e clique em **Salvar configuração**. O conjunto é salvo em uma única transação.

Exemplo: um canal YouTube pode enviar texto curto com prévia do YouTube ao servidor A, um embed personalizado ao servidor B e outro modelo ao servidor C. Destinos de um mesmo servidor também podem usar estilos diferentes.

O **Padrão deste canal** é opcional: permite reutilizar uma mensagem nos destinos que escolherem esse padrão. A configuração específica do destino tem prioridade. Se nenhum modelo do canal/destino for escolhido, continua valendo o padrão daquele servidor.

## Cópias e modelos compartilhados

- **Personalizar para este destino** preserva o modelo de origem. Se uma cópia for compartilhada posteriormente, uma nova personalização do canal cria outra cópia para não modificar os outros usos.
- A aba **Modelos** reúne todos os modelos, incluindo as cópias por canal/destino. Sua edição direta é uma edição compartilhada e pede confirmação antes de salvar.
- O editor de modelos mantém variáveis, modo YouTube/embed e reordenação de linhas por arraste; as setas também permitem reordenar por teclado ou toque.
- Ao trocar entre servidores no editor, os rascunhos são mantidos até salvar ou descartá-los. Fechar uma edição com alterações pede confirmação.

## Pausas, remoções e histórico

Cada destino pode ser pausado sem pausar os outros. Salve para aplicar a pausa. Avisos ainda pendentes desse destino são marcados como ignorados, com o motivo registrado; entregas enviadas e IDs conhecidos permanecem no banco. Um envio que já esteja em andamento pode terminar antes da pausa.

Retomar um destino começa pelas novas publicações após a retomada. Não há reenvio automático do período pausado. Remover um destino na edição afeta somente aquele canal YouTube. Remover um destino padrão na aba Discord é uma ação do servidor e cancela pendências daquele destino.

A aba **Entregas e logs** mostra o canal YouTube, servidor, canal Discord, resultado e motivo da falha. Há filtros por texto e estado. O reenvio manual continua disponível para falhas/resultados incertos, com confirmação para evitar duplicar um aviso que já tenha chegado.

### Limpar cada histórico

Cada aba tem seu próprio botão e pede confirmação antes de limpar:

| Botão | Efeito |
| --- | --- |
| Limpar entregas | Retira do histórico todas as entregas finalizadas: enviadas, com falha, incertas e ignoradas. Mantém as que estão na fila ou em envio. |
| Limpar testes | Retira do histórico todos os testes enviados ou com falha. Mantém os que estão na fila ou em envio. |
| Limpar logs | Apaga os registros da área selecionada. Os logs próprios do Telegram são limpos na seção Telegram. Novos eventos podem aparecer enquanto o monitor funciona. |

A limpeza de entregas e testes é persistente, inclusive após recarregar o painel. Ela abrange o histórico inteiro daquela categoria; filtros e limites de 100/20 itens não restringem a limpeza. Ao terminar um envio que estava pendente, seu resultado continua visível.

Limpar não apaga mensagens no Discord ou Telegram, não modifica canais, modelos ou chaves e não zera o total de avisos enviados. O banco mantém os registros de entregas necessários para impedir duplicações; somente a exibição desses registros finalizados é limpa. Os IDs conhecidos são preservados. O resultado de um teste aberto no editor continua acessível mesmo se outra aba limpar o histórico de testes.

## Telegram e busca global

Consulte [CONFIGURAR_TELEGRAM.md](CONFIGURAR_TELEGRAM.md) para configurar o bot e o administrador pelo painel, conectar canais/grupos ou usar somente o privado, personalizar mensagens e testar um destino.

O menu mostra a seção Discord acima da seção Telegram. **Busca global**, **APIs do YouTube** e **Configurações** são compartilhadas. Adicionar um YouTube já cadastrado na outra plataforma reaproveita os metadados, IDs conhecidos e a busca existente. O monitoramento permanece ativo enquanto pelo menos uma plataforma mantém esse canal ativo.

Pausar ou remover um canal do Discord afeta seus avisos no Discord; fazer isso no Telegram afeta os avisos no Telegram. Cada plataforma mantém sua própria fila e controle de envios. Pausas e reativações de destinos começam a considerar publicações novas a partir da ativação. Um envio já iniciado pode concluir antes de uma mudança.

## Compatibilidade com as versões anteriores

A migração de V1.0.5 a V1.0.9 é aditiva: acrescenta estruturas do Telegram e estados separados para as plataformas. Preserva canais, modelos, mensagens personalizadas, credenciais cifradas, intervalos, histórico, cotas e marcos de monitoramento. Na V1.0.8, a configuração Telegram existente permanece intacta; o administrador atual é autorizado automaticamente, preservando sua pausa, seus destinos e suas mensagens. Em origens anteriores à V1.0.8, Telegram começa desativado.

Canais antigos continuam usando os vínculos e destinos padrão existentes. O editor em **Discord → Canais e avisos** mostra essas escolhas. Salvar ali transforma apenas aquele canal em uma lista própria de destinos. A retirada da aba Associações não apaga os registros nem exige cadastrar novamente seus canais.

Se um servidor está pausado, seus destinos individuais também aguardam ativação em **Discord → Servidores**. Os editores detectam alterações concorrentes e pedem para reabrir a edição antes de sobrescrever escolhas mais recentes.

## Classificação das lives

Antes, um vídeo com `liveBroadcastContent=none` podia ser tratado como upload mesmo contendo `scheduledStartTime` ou `actualStartTime`. A V1.0.9 verifica os horários em `liveStreamingDetails` além do sinalizador: fim → encerrada; início efetivo → ao vivo; início programado → programada. Lives encerradas continuam sem gerar aviso novo. O texto de `{tipo}` para a categoria programada passa a ser **LIVE PROGRAMADA**, incluindo prévias e testes.

A correção aproveita a resposta de `videos.list` que já era consultada. Não aumenta a frequência nem reconsulta IDs antigos. Avisos já enviados não são reescritos ou reenviados; textos digitados manualmente pelo usuário em modelos permanecem intactos. Se o YouTube não fornecer nenhum sinal de transmissão, o título sozinho não é usado para adivinhar a categoria. Um caso específico ainda divergente precisa do link/ID e dos dados retornados para investigação.

Referência dos campos: [Videos — YouTube Data API](https://developers.google.com/youtube/v3/docs/videos#liveStreamingDetails).

## Monitoramento e consumo

- O worker continua independente da página aberta no navegador.
- `playlistItems.list` descobre IDs, até 50 por página, no intervalo global escolhido (padrão 300 segundos; mínimo 10). Páginas adicionais são consultadas apenas quando necessárias, até cinco por rodada.
- Apenas IDs desconhecidos e elegíveis vão para `videos.list`, em lotes de até 50. Sem ID novo, não há consulta a `videos.list`. Falhas deixam o ID disponível para nova tentativa.
- IDs antigos e histórico permanecem conhecidos. Uma publicação produz um aviso por destino. A mudança posterior de programada para ao vivo não gera outro aviso nem consulta recorrente de IDs antigos.
- Shorts continuam incluídos em vídeos; a API pública usada não fornece um indicador confiável de Shorts separado.
- `search.list` e WebSub continuam desativados. Uma live programada é encontrada quando seu ID aparece na playlist pública consultada; o instante da descoberta depende do YouTube.
- A troca para a próxima chave ativa em caso de falha/limite continua funcionando, com a mesma configuração.

Em **Configurações**, a estimativa mostra `canais ativos × 86.400 ÷ intervalo`, arredondada para cima, considerando uma página por verificação. Cada chamada de playlist e de detalhes custa uma unidade. Páginas adicionais, lotes de IDs novos, cadastros, testes de chaves e novas tentativas somam consumo. A duração da própria consulta e a espera por vaga somam-se ao intervalo individual. Consultar em paralelo não junta canais em uma chamada nem reduz o custo por requisição.

A estimativa não soma cotas de chaves: chaves do mesmo projeto Google compartilham a cota. A contagem local não substitui a medição oficial do Google Cloud. Referências: [playlistItems.list](https://developers.google.com/youtube/v3/docs/playlistItems/list), [videos.list](https://developers.google.com/youtube/v3/docs/videos/list) e [custos da API](https://developers.google.com/youtube/v3/determine_quota_cost).

## Estrutura e configuração

```text
/opt/peralta-live-monitor/
  .env
  data/
    monitor.sqlite3
    backup/
  releases/
    V1.0.5/
    V1.0.6/
    V1.0.7/
    V1.0.8/
    V1.0.9/
    V1.1.0/
```

Para uma instalação nova, use a `.env.example` como referência. Em uma atualização, mantenha o `.env` existente com seu domínio, credenciais Discord, login do painel e `APP_SECRET`. A API YouTube pode continuar cadastrada no painel ou na variável `YOUTUBE_API_KEY`, conforme a instalação atual.

A instalação do bot continua exigindo seu Discord User ID autorizado. No Developer Portal: Public Bot desligado, Require OAuth2 Code Grant ligado, instalação em servidor habilitada e redirect correspondente ao domínio configurado, por exemplo `https://monitor.p7nexus.online/auth/discord/callback`. O bot precisa visualizar e enviar no destino; Embed Links habilita as prévias e Mention Everyone permite as menções quando escolhidas.

O Caddy existente continua apontando o domínio para `127.0.0.1:8081`. Não é preciso alterar serviços que usem outras portas, como o Auto Server.

## Validação

Execute os testes com Python 3.12 e as dependências de `requirements.txt`:

```bash
python -m unittest discover -s tests -v
```

A validação inclui a suíte anterior e os novos cenários de 100 canais, exclusão entre processos reais, SIGSTOP/SIGKILL, cota em andamento, reinício, redução de concorrência e reutilização de conexão HTTP real local. Veja os resultados e o comando reproduzível em [VALIDACAO.md](VALIDACAO.md).

As notificações dos testes são simuladas. CPU/RAM, latência real do YouTube, estabilidade com 100 canais, gasto oficial no Google Cloud e entrega aos seus destinos precisam ser medidos na VPS.
