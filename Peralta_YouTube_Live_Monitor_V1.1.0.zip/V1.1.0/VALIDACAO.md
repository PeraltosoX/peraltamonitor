# Validação da V1.1.0 — 22/10/2026

**Resultado: 86 testes automatizados aprovados**, executados em 60,460 segundos no ambiente local. A base V1.0.9 também foi executada antes das alterações: seus 71 testes passaram. O código entregue parte desse ZIP e mantém as regras anteriores de classificação, filtros e entrega.

## Ambiente e reprodução

Linux, Python 3.12.14, SQLite 3.53.1, FastAPI 0.159.1, Uvicorn 0.54.0, HTTPX 0.28.1, discord.py 2.7.1 e cryptography 49.0.0. As faixas de dependências do projeto foram mantidas; uma construção futura pode resolver outras versões dentro dessas faixas.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Execute no diretório `V1.1.0/`, com Python 3.12 e Linux. Os testes criam bancos temporários, usam credenciais fictícias, HTTP simulado e um servidor HTTP local para testar keep-alive. Não enviam notificações reais nem consultam Google/Discord/Telegram externos. O ambiente de teste apresentou um aviso de depreciação do adaptador HTTPX do Starlette; não houve falhas de teste.

## Cenários novos executados

| Cenário | Evidência obtida |
| --- | --- |
| 100 canais, limite 1 | Pico observado de 1 verificação; todos os 100 processados |
| 100 canais, limite 3 | Pico observado de 3; novo canal começa antes de terminar o canal lento |
| 100 canais, limite 10 | Pico observado de 10; sem barreira de lote |
| Prioridade | Primeiras admissões seguem os horários mais atrasados |
| Falhas no conjunto de 100 | Quatro respostas HTTP 404 e um timeout injetado; cinco falhas registradas, 95 canais com sucesso |
| Consulta manual durante o conjunto de 100 | Mesmo canal ocupado é recusado sem iniciar outra busca |
| Múltiplos destinos | 95 publicações elegíveis geram 190 entradas Discord e 95 Telegram |
| Deduplicação e reinício | Reconsultas das mesmas publicações e nova abertura/migração do banco não aumentam essas entregas |
| Intervalo individual | `next_poll_at = fim + intervalo`; canal ainda no intervalo não entra, outro canal disponível entra |
| Pausas por falha | Verificados 30/60/120s, persistência após reinício e bloqueio também da consulta manual durante a pausa |
| Timeout total real | Corrotina bloqueada é cancelada pelo timeout da verificação, grava falha e libera a vaga |
| Timeout de requisição | HTTP simulado sem conclusão é interrompido e a tentativa permanece contabilizada |
| Painel × monitor em processos distintos | Processo filho possui canal/vaga; endpoint autenticado do painel recusa duplicação e excesso do limite global |
| Processo suspenso | SIGSTOP não permite roubar o bloqueio de um processo ainda vivo |
| Processo encerrado à força | SIGKILL libera o bloqueio; recuperação do estado permite nova consulta |
| Reduzir simultaneidade | Redução para 1 aguarda as verificações existentes; nova admissão só ocorre abaixo do novo limite |
| Encerramento | Cancelamento da fila libera as dez vagas; inclui cancelamento antes da primeira instrução de uma tarefa |
| Cota com 100 tentativas simultâneas | Saldo 7: somente 7 chegam ao transporte HTTP, 93 são impedidas antes do envio |
| Cota entre processos e chaves do mesmo projeto | Dois processos disputam saldo 7; soma de reservas permanece exatamente 7 |
| Pausa de cota e sucesso tardio | Resposta de sucesso atrasada não apaga a pausa do projeto; teste manual de chave também não a ignora |
| Virada do dia e reinício | Reserva/pausa persistem após reabrir o banco; novo dia simulado permite novo saldo |
| HTTP 429 | Respeita Retry-After de 180s e distingue limite de taxa do limite diário |
| Worker sem saldo | Não inicia chamadas; retoma após voltar a existir saldo elegível |
| HTTPX reutilizável | Cinco GETs em servidor local usam uma conexão TCP, encerrada ao fechar o pool |
| Painel | Valida limite 1–10, rejeita valores fracionários/inválidos, aceita intervalo 10s e rejeita 9s; salva e recarrega |
| Migração | Fixtures V1.0.5/1.0.6/1.0.7/1.0.8/1.0.9, executadas duas vezes, preservam campos anteriores, credenciais cifradas e histórico |

Os testes antigos continuam cobrindo lives com flags ausentes/defasadas, filtros, publicações antigas, múltiplos destinatários, autorização, HTML/menções, pausas e estados incertos de envio.

O teste de 100 canais usa eventos controlados para manter uma consulta lenta até que outra vaga seja reaproveitada. Seu timeout é injetado para tornar a sequência determinística; há outro teste que exerce o cancelamento real por prazo. Os tempos locais das três passagens (9,465s; 5,653s; 4,799s) **não são um benchmark comparativo nem previsão da VPS**: o primeiro passe consulta detalhes novos e os demais também verificam deduplicação de IDs já conhecidos. O objetivo é comprovar concorrência, progresso e correção.

## Verificações do pacote

- Sintaxe dos módulos Python e JavaScript conferida.
- 18 blocos Bash dos guias de atualização/instalação conferidos com `bash -n`.
- Guia de atualização mantém oito passos, origem V1.0.9 aceita, destino V1.1.0 e saúde exigindo `1.1.0` antes de iniciar worker/bot.
- Migração aditiva 109 → 110: intervalo existente preservado; consultas simultâneas inicializadas em 10; sem zerar a linha de base, IDs conhecidos ou entregas.
- ZIP com raiz `V1.1.0/`; ícones e regras de classificação/envio preservados. Não inclui banco real, `.env` real, caches ou dependências instaladas do teste.
- Os TXT externos são cópias dos mesmos arquivos incluídos no ZIP.

Não foi executado build Docker neste ambiente, instalação/atualização na VPS, publicação no GitHub nem novo teste visual completo do painel em navegador. O novo formulário foi conferido pelo HTML/JavaScript e pelos testes HTTP de configuração; o layout anterior foi mantido.

## Medições que faltam na VPS

1. **CPU e memória:** comparar 1, 3 e 10 consultas com os mesmos canais, durante pelo menos 15–30 minutos por configuração. Observar web/worker/bot e crescimento de RAM ao longo das horas.
2. **Latência e atraso:** medir duração média/p95/p99 de consulta, tempo em fila e intervalo real entre conclusões. Registrar quantos canais continuam atrasados com 100 ativos. O campo `poll_duration` guarda a última duração por canal; percentis históricos precisam de amostragem ao longo do tempo.
3. **Rede/conexões:** avaliar latência do YouTube a partir da VPS, conexões abertas, erros DNS/TLS, HTTP 429/5xx e estabilidade do pool sob carga prolongada.
4. **SQLite/disco:** medir tempo de espera de escrita, ocorrência de `database is locked`, tamanho do WAL e espaço livre. Usar disco local e o mesmo volume nos serviços.
5. **Cota oficial:** comparar a reserva local com o Google Cloud no mesmo dia de cota; considerar outros programas do projeto. Reservas sem resposta são conservadoras e podem exceder o consumo oficial.
6. **Avisos reais:** conferir chegada ao Discord/Telegram, permissões, tempo entre descoberta e recebimento, limites das plataformas e ausência de duplicação em reinício controlado. Não provocar SIGKILL durante envios reais apenas para repetir o teste local.
7. **Operação prolongada:** acompanhar 24 horas, incluindo virada da cota, pausas, reinício e fila de entregas. O teste local não certifica capacidade sustentada de uma VPS específica.

Comandos de observação, na VPS e depois da atualização:

```bash
cd /opt/peralta-live-monitor/releases/V1.1.0
docker compose stats --no-stream
docker compose ps -a
docker compose logs --tail=100 web worker bot
```

Consulta de estado e durações, sem exibir chaves ou tokens:

```bash
cd /opt/peralta-live-monitor/releases/V1.1.0
docker compose exec -T web python - <<'PY'
from app import db, polling, api_keys
import time
rows = db.rows('SELECT channel_id,last_poll,next_poll_at,poll_retry_at,poll_started_at,poll_duration,poll_failures FROM youtube_channels WHERE active=1 AND removed=0')
now = time.time()
waiting = [r for r in rows if not r['poll_started_at'] and polling.next_due(r) <= now]
durations = [r['poll_duration'] for r in rows if r['poll_duration'] is not None]
print('Ativos:', len(rows), 'Limite:', polling.concurrency(), 'Intervalo:', polling.interval())
print('Em consulta:', sum(bool(r['poll_started_at']) for r in rows), 'Aguardando vaga/pausa da API:', len(waiting))
print('Maior atraso atual (s):', round(max((now-polling.next_due(r) for r in waiting), default=0), 2))
print('Últimas durações: média/max (s):', round(sum(durations)/len(durations), 3) if durations else 0, round(max(durations, default=0), 3))
print('Tentativas estimadas no dia:', db.one('SELECT calls FROM api_usage WHERE day=?', (api_keys.quota_day(),)))
print('Canais com falhas consecutivas:', sum(r['poll_failures'] > 0 for r in rows))
PY
```

Esses valores são uma fotografia do estado, não medição histórica de p95/p99. Configuração e estado vistos pelo painel podem mudar enquanto o comando roda.

## Referências técnicas consultadas

- YouTube, custos e virada da cota: https://developers.google.com/youtube/data/determine_quota_cost
- YouTube, tipos de erro: https://developers.google.com/youtube/data/reference/rest/v3/errors
- HTTPX, cliente assíncrono compartilhado: https://www.python-httpx.org/async/
- HTTPX, timeouts: https://www.python-httpx.org/advanced/timeouts/
- HTTPX, limites do pool: https://www.python-httpx.org/advanced/resource-limits/
