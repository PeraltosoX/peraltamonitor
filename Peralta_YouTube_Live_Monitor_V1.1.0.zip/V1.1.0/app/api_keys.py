"""Encrypted credentials and transactional quota reservations shared by all services."""
import base64
import hashlib
from contextlib import closing
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo

from cryptography.fernet import Fernet, InvalidToken

from . import db
from .config import APP_SECRET, YOUTUBE_API_KEY, YOUTUBE_API_PROJECT_ID

PACIFIC = ZoneInfo("America/Los_Angeles")


def quota_day():
    return datetime.now(PACIFIC).strftime("%Y-%m-%d")


def next_reset():
    now = datetime.now(PACIFIC)
    tomorrow = now.date() + timedelta(days=1)
    return int(datetime(tomorrow.year, tomorrow.month, tomorrow.day, tzinfo=PACIFIC).timestamp()) + 60


def cipher():
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(APP_SECRET.encode()).digest()))


def encrypt(key):
    return cipher().encrypt(key.encode()).decode()


def decrypt(value):
    try:
        return cipher().decrypt(value.encode()).decode()
    except InvalidToken as exc:
        raise RuntimeError("Chave API não pode ser descriptografada; confira APP_SECRET") from exc


def scope(project_id):
    project_id = (project_id or "").strip().lower()
    return "project:" + project_id if project_id else "unidentified"


def migrate_usage(con):
    if con.execute("SELECT 1 FROM settings WHERE key='quota_scopes_initialized'").fetchone():
        return
    totals = {}
    for row in con.execute("SELECT u.*,c.project_id FROM api_key_usage u LEFT JOIN api_credentials c ON c.id=u.credential_id"):
        project = YOUTUBE_API_PROJECT_ID if row["credential_id"] == 0 else row["project_id"]
        key = (row["day"], scope(project))
        totals[key] = totals.get(key, 0) + row["calls"]
    con.executemany("INSERT OR IGNORE INTO api_project_usage(day,scope,calls,updated_at) VALUES(?,?,?,?)",
                    [(day, group, calls, db.ts()) for (day, group), calls in totals.items()])
    con.execute("INSERT INTO settings(key,value) VALUES('quota_scopes_initialized','1')")


def _records(con):
    records = [dict(r) for r in con.execute("SELECT * FROM api_credentials WHERE encrypted_key IS NOT NULL "
                                           "ORDER BY primary_flag DESC,priority,id")]
    if YOUTUBE_API_KEY and not YOUTUBE_API_KEY.startswith("COLE_AQUI_"):
        settings = dict(con.execute("SELECT key,value FROM settings WHERE key IN ('env_key_retry_after','env_key_last_error')").fetchall())
        env = {"id": 0, "name": "Chave inicial (.env)", "project_id": YOUTUBE_API_PROJECT_ID,
               "encrypted_key": None, "last4": YOUTUBE_API_KEY[-4:], "active": 1,
               "primary_flag": int(not any(r["primary_flag"] and r["active"] for r in records)),
               "quota_limit": 10000, "priority": 0, "retry_after": int(settings.get("env_key_retry_after", 0)),
               "last_used": None, "last_error": settings.get("env_key_last_error", "")}
        records.append(env) if not env["primary_flag"] else records.insert(0, env)
    return records


def _budgets(con, records):
    day = quota_day()
    used = {r["scope"]: r["calls"] for r in con.execute("SELECT scope,calls FROM api_project_usage WHERE day=?", (day,))}
    per_key = {r["credential_id"]: r["calls"] for r in con.execute("SELECT credential_id,calls FROM api_key_usage WHERE day=?", (day,))}
    pauses = {r["scope"]: r["retry_after"] for r in con.execute("SELECT scope,retry_after FROM api_project_state")}
    limits, current_totals = {}, {}
    for row in records:
        group = scope(row["project_id"])
        # Unknown projects share one conservative budget. Multiple keys never
        # multiply the quota of a project. The smallest configured limit wins.
        limits[group] = min(limits.get(group, row["quota_limit"]), row["quota_limit"])
        current_totals[group] = current_totals.get(group, 0) + per_key.get(row["id"], 0)
    for group, calls in current_totals.items():
        # Also handles keys newly assigned to an existing project. Old reserved
        # usage stays recorded even if a credential is later removed or edited.
        used[group] = max(used.get(group, 0), calls)
    return used, limits, pauses, per_key


def _eligible(row, budgets):
    used, limits, pauses, _ = budgets
    group = scope(row["project_id"])
    return (row["retry_after"] <= db.ts() and pauses.get(group, 0) <= db.ts()
            and used.get(group, 0) < limits[group])


def candidates():
    """Advisory availability only. reserve() rechecks atomically before dispatch."""
    with closing(db.connect()) as con:
        records = _records(con)
        budgets = _budgets(con, records)
        return [(r["id"], YOUTUBE_API_KEY if r["id"] == 0 else decrypt(r["encrypted_key"]))
                for r in records if r["active"] and _eligible(r, budgets)]


def reserve(*, exclude=(), credential_id=None):
    """Charge before sending, under BEGIN IMMEDIATE; in-flight calls use budget.

    No refunds: network failures/cancellation/crashes can have reached Google.
    A manual credential test may use an inactive key, but cannot bypass a pause
    or exhausted quota. Each credential is attempted at most once per request.
    """
    with db.transaction() as con:
        records = _records(con)
        budgets = _budgets(con, records)
        for row in records:
            if row["id"] in exclude:
                continue
            if credential_id is not None:
                if row["id"] != credential_id:
                    continue
            elif not row["active"]:
                continue
            if not _eligible(row, budgets):
                continue
            key = YOUTUBE_API_KEY if row["id"] == 0 else decrypt(row["encrypted_key"])
            day, now, group = quota_day(), db.ts(), scope(row["project_id"])
            floor = budgets[0].get(group, 0)
            con.execute("INSERT INTO api_project_usage(day,scope,calls,updated_at) VALUES(?,?,?,?) "
                        "ON CONFLICT(day,scope) DO UPDATE SET calls=MAX(calls,?)+1,updated_at=excluded.updated_at",
                        (day, group, floor + 1, now, floor))
            con.execute("INSERT INTO api_key_usage(day,credential_id,calls,updated_at) VALUES(?,?,1,?) "
                        "ON CONFLICT(day,credential_id) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at",
                        (day, row["id"], now))
            con.execute("INSERT INTO api_usage(day,calls,updated_at) VALUES(?,1,?) "
                        "ON CONFLICT(day) DO UPDATE SET calls=calls+1,updated_at=excluded.updated_at", (day, now))
            return row["id"], key, group
    return None


def mark_result(credential_id, error="", retry_after=0, *, shared=False, quota_scope=None):
    with db.transaction() as con:
        now = db.ts()
        if credential_id == 0:
            old = con.execute("SELECT value FROM settings WHERE key='env_key_retry_after'").fetchone()
            old_retry = int(old[0]) if old else 0
            if error or old_retry <= now:
                con.executemany("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                                [("env_key_retry_after", str(max(old_retry, retry_after) if error else 0)),
                                 ("env_key_last_error", error[:120])])
            group = scope(YOUTUBE_API_PROJECT_ID)
        else:
            row = con.execute("SELECT project_id FROM api_credentials WHERE id=?", (credential_id,)).fetchone()
            group = scope(row[0] if row else None)
            if error:
                con.execute("UPDATE api_credentials SET last_used=?,last_error=?,retry_after=MAX(retry_after,?) WHERE id=?",
                            (now, error[:120], retry_after, credential_id))
            else:
                # A late successful response must not erase a newer failure/pause.
                con.execute("UPDATE api_credentials SET last_used=?,last_error=CASE WHEN retry_after<=? THEN '' ELSE last_error END,"
                            "retry_after=CASE WHEN retry_after<=? THEN 0 ELSE retry_after END WHERE id=?",
                            (now, now, now, credential_id))
        if shared and error:
            con.execute("INSERT INTO api_project_state(scope,retry_after,last_error) VALUES(?,?,?) "
                        "ON CONFLICT(scope) DO UPDATE SET retry_after=MAX(retry_after,excluded.retry_after),last_error=excluded.last_error",
                        (quota_scope or group, retry_after, error[:120]))


def response_pause(response):
    reason = ""
    try:
        errors = response.json().get("error", {}).get("errors", [])
        reason = errors[0].get("reason", "") if errors else ""
    except (ValueError, TypeError, AttributeError, IndexError):
        pass
    if reason in ("quotaExceeded", "dailyLimitExceeded", "dailyLimitExceededUnreg"):
        return next_reset(), True, reason
    delay = 3600 if response.status_code in (400, 401, 403) else 300
    shared = response.status_code == 429 or reason in ("rateLimitExceeded", "userRateLimitExceeded")
    if shared:
        delay = 60
    header = getattr(response, "headers", {}).get("retry-after", "")
    try:
        delay = max(delay, int(header))
    except (ValueError, TypeError):
        try:
            delay = max(delay, int(parsedate_to_datetime(header).timestamp() - db.ts()))
        except (ValueError, TypeError, OverflowError):
            pass
    return db.ts() + delay, shared, reason


def public_list():
    records = db.rows("SELECT c.id,c.name,c.project_id,c.last4,c.active,c.primary_flag,c.priority,"
                      "c.retry_after,c.quota_limit,c.last_used,c.last_error,"
                      "c.encrypted_key IS NOT NULL AS configured,COALESCE(u.calls,0) AS calls "
                      "FROM api_credentials c LEFT JOIN api_key_usage u "
                      "ON u.credential_id=c.id AND u.day=? ORDER BY c.priority,c.id", (quota_day(),))
    with closing(db.connect()) as con:
        configured = _records(con)
        used, limits, pauses, per_key = _budgets(con, configured)
    env = next((r for r in configured if r["id"] == 0), None)
    if env:
        records.insert(0, {**env, "configured": 1, "calls": per_key.get(0, 0)})
    for row in records:
        group = scope(row["project_id"])
        row.pop("encrypted_key", None)
        row["masked"] = "••••" + row.pop("last4") if row["configured"] else "Não configurada"
        row["project_calls"] = used.get(group, 0)
        row["project_limit"] = limits.get(group, row["quota_limit"])
        row["remaining"] = max(0, row["project_limit"] - row["project_calls"])
        row["retry_after"] = max(row["retry_after"], pauses.get(group, 0))
    selected = candidates()
    current = selected[0][0] if selected else None
    for row in records:
        row["current"] = row["id"] == current
    return records
