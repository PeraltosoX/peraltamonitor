"""One HTTPX pool per service/event loop; never store credentials on the client."""
from contextlib import asynccontextmanager
import asyncio

import httpx

_clients = {}
REQUEST_TIMEOUT = 25


@asynccontextmanager
async def lifespan():
    loop = asyncio.get_running_loop()
    if loop in _clients:
        yield _clients[loop]
        return
    # Ten YouTube checks plus room for Telegram polling/sending and panel actions.
    # The global check limit is enforced separately, across processes.
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(20, connect=8, pool=5),
        limits=httpx.Limits(max_connections=16, max_keepalive_connections=16,
                           keepalive_expiry=60),
        follow_redirects=False,
    ) as client:
        _clients[loop] = client
        try:
            yield client
        finally:
            _clients.pop(loop, None)


@asynccontextmanager
async def borrow():
    client = _clients.get(asyncio.get_running_loop())
    if client is not None:
        yield client
    else:
        # Standalone scripts/tests have no service lifespan. Always close their pool.
        async with lifespan() as client:
            yield client
