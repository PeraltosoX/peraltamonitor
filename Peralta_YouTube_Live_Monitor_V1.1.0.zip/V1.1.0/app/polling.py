"""Continuous channel scheduling and Linux cross-process check ownership.

All services must share the same local DATA_DIR (the Compose bind mount).
Kernel flock ownership, not an expiring lease, prevents a suspended process from
being mistaken for a dead process. SIGKILL releases ownership automatically.
Never delete/replace the lock files while any service is running.
"""
import asyncio
import fcntl
import hashlib
import time
import uuid
from contextlib import ExitStack
from dataclasses import dataclass

from . import db

CHECK_TIMEOUT = 90
MAX_CONCURRENT = 10


class CheckBusy(Exception):
    pass


class CheckDeferred(Exception):
    def __init__(self, retry_at):
        self.retry_at = retry_at
        super().__init__("Canal aguardando o intervalo ou a pausa após uma falha")


def interval():
    try:
        return max(10, min(86400, int(db.setting("playlist_interval", "300"))))
    except (ValueError, TypeError):
        return 300


def concurrency():
    try:
        return max(1, min(MAX_CONCURRENT, int(db.setting("concurrent_checks", "10"))))
    except (ValueError, TypeError):
        return 10


def next_due(channel):
    normal = channel["next_poll_at"]
    if normal is None:
        normal = channel["last_poll"] + interval() if channel["last_poll"] else 0
    return max(normal, channel["poll_retry_at"])


def _lock(name):
    directory = db.DATA_DIR / "poll-locks"
    directory.mkdir(parents=True, exist_ok=True)
    handle = (directory / (name + ".lock")).open("a+b")
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        handle.close()
        return None
    except BaseException:
        handle.close()
        raise
    return handle


def _channel_lock(cid):
    return _lock("channel-" + hashlib.sha256(cid.encode()).hexdigest())


@dataclass
class Claim:
    channel: dict
    owner: str
    locks: ExitStack

    def close(self):
        self.locks.close()


def abandon(owned):
    # Also covers cancellation between create_task() and its first instruction.
    try:
        db.write("UPDATE youtube_channels SET poll_owner=NULL,poll_started_at=NULL "
                 "WHERE channel_id=? AND poll_owner=?", (owned.channel["channel_id"], owned.owner))
    finally:
        owned.close()


def claim(channel_id, *, manual=False):
    """Atomically claim a channel and one global slot. Never wait on file locks."""
    with ExitStack() as stack:
        guard = _lock("admission")
        if guard is None:
            raise CheckBusy("Outra verificação está entrando na fila; tente novamente")
        with guard:
            channel_lock = _channel_lock(channel_id)
            if channel_lock is None:
                raise CheckBusy("Este canal já está sendo verificado")
            stack.enter_context(channel_lock)
            # Probe every slot so lowering 10 -> 1 drains existing work before
            # admitting another check, including checks owned by the web process.
            with ExitStack() as probes:
                free = []
                for n in range(MAX_CONCURRENT):
                    handle = _lock(f"slot-{n}")
                    if handle is not None:
                        probes.enter_context(handle)
                        free.append(handle)
                if MAX_CONCURRENT - len(free) >= concurrency():
                    raise CheckBusy("Todas as vagas de consulta estão ocupadas; tente novamente")
                # Duplicate the selected fd; flock remains held until both close.
                import os
                stack.enter_context(os.fdopen(os.dup(free[0].fileno()), "a+b"))
            with db.transaction() as con:
                row = con.execute("SELECT * FROM youtube_channels WHERE channel_id=? "
                                  "AND active=1 AND removed=0", (channel_id,)).fetchone()
                if not row:
                    raise CheckBusy("Canal não encontrado ou pausado")
                channel = dict(row)
                now = time.time()
                due = channel["poll_retry_at"] if manual else next_due(channel)
                if due > now:
                    raise CheckDeferred(due)
                owner = uuid.uuid4().hex
                con.execute("UPDATE youtube_channels SET poll_owner=?,poll_started_at=? WHERE channel_id=?",
                            (owner, now, channel_id))
            return Claim(channel, owner, stack.pop_all())


def recover_abandoned():
    """Clear metadata only after proving that no process holds the channel lock."""
    for row in db.rows("SELECT channel_id,poll_owner FROM youtube_channels WHERE poll_owner IS NOT NULL"):
        handle = _channel_lock(row["channel_id"])
        if handle is None:
            continue
        with handle:
            changed = db.write("UPDATE youtube_channels SET poll_owner=NULL,poll_started_at=NULL,"
                               "last_error='Verificação interrompida; retomada na fila' "
                               "WHERE channel_id=? AND poll_owner=?", (row["channel_id"], row["poll_owner"]))
            if changed:
                db.log("worker", "warning", f"{row['channel_id']}: verificação interrompida recuperada")


async def execute(owned):
    """Only a claimed check can call the playlist implementation."""
    from . import youtube
    cid = owned.channel["channel_id"]
    started = time.monotonic()
    error = ""
    cancelled = False
    try:
        async with asyncio.timeout(CHECK_TIMEOUT):
            return await youtube._check_playlist(cid, owned.channel["uploads_id"])
    except asyncio.CancelledError:
        error, cancelled = "Verificação interrompida no encerramento", True
        raise
    except Exception as exc:
        error = (f"Tempo limite de {CHECK_TIMEOUT:g}s por canal" if isinstance(exc, TimeoutError)
                 else str(exc) if isinstance(exc, youtube.YouTubeError) else type(exc).__name__)
        # Do not expose HTTP URLs, API keys or response bodies.
        raise youtube.YouTubeError(error) from None
    finally:
        try:
            finished = time.time()
            failures = owned.channel["poll_failures"] + 1 if error else 0
            delay = min(900, 30 * 2 ** min(max(0, failures - 1), 5)) if error else 0
            if cancelled:
                delay = 5
            db.write("UPDATE youtube_channels SET last_poll=?,next_poll_at=?,poll_retry_at=?,"
                     "poll_failures=?,poll_owner=NULL,poll_started_at=NULL,poll_duration=?,last_error=? "
                     "WHERE channel_id=? AND poll_owner=?",
                     (finished, finished + interval(), finished + delay if error else 0,
                      failures, time.monotonic() - started, error[:250], cid, owned.owner))
            if error:
                db.log("worker", "warning" if cancelled else "error", f"{cid}: {error}")
        finally:
            owned.close()


def due_channels():
    # next_poll_at is initialized on migration and updated on completion/settings.
    return db.rows("SELECT * FROM youtube_channels WHERE active=1 AND removed=0 "
                   "AND MAX(COALESCE(next_poll_at,0),poll_retry_at)<=? "
                   "ORDER BY MAX(COALESCE(next_poll_at,0),poll_retry_at),channel_id", (time.time(),))


def update_settings(con, seconds, simultaneous, zone):
    old_interval = int(con.execute("SELECT value FROM settings WHERE key='playlist_interval'").fetchone()[0])
    con.executemany("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    [("playlist_interval", str(seconds)), ("concurrent_checks", str(simultaneous)), ("timezone", zone)])
    if old_interval != seconds:
        # Keep the per-channel completion anchor and preserve independent backoff.
        con.execute("UPDATE youtube_channels SET next_poll_at=CASE WHEN last_poll IS NULL THEN 0 ELSE last_poll+? END",
                    (seconds,))
