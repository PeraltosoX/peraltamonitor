import asyncio
import signal
import time

from . import db, youtube, api_keys, polling, http_client
from .config import require

WAKE_INTERVAL = 1.0


async def poll_channel(owned):
    cid = owned.channel["channel_id"]
    try:
        result = await polling.execute(owned)
        if result["baseline"] or result["new"]:
            db.log("worker", "info", f"{cid}: {result['new']} vídeo(s) novo(s), {result['queued']} entrega(s)")
    except youtube.YouTubeError:
        pass  # execute() records the failure and persists the per-channel backoff.


async def monitor_loop():
    last_prune = last_recovery = last_heartbeat = last_api_warning = 0
    running = {}
    try:
        while True:
            for task in list(running):
                if task.done():
                    owned = running.pop(task)
                    try:
                        task.result()
                    finally:
                        polling.abandon(owned)
            now = time.monotonic()
            if now - last_heartbeat >= 5:
                db.heartbeat("worker", f"Monitorando; {len(running)} consulta(s) neste processo; limite {polling.concurrency()}")
                last_heartbeat = now
            if now - last_recovery >= 60:
                polling.recover_abandoned()
                last_recovery = now
            if now - last_prune >= 86400:
                db.prune()
                last_prune = now
            try:
                available = bool(api_keys.candidates())
                warning = "Nenhuma chave API disponível; aguardando cota ou correção"
            except RuntimeError as exc:
                available, warning = False, str(exc)
            if not available and now - last_api_warning > 300:
                db.log("worker", "warning", warning)
                last_api_warning = now
            if available:
                local_ids = {owned.channel["channel_id"] for owned in running.values()}
                for channel in polling.due_channels():
                    if len(running) >= polling.concurrency():
                        break
                    if channel["channel_id"] in local_ids:
                        continue
                    try:
                        owned = polling.claim(channel["channel_id"])
                    except (polling.CheckBusy, polling.CheckDeferred):
                        continue
                    task = asyncio.create_task(poll_channel(owned), name=f"poll:{channel['channel_id']}")
                    running[task] = owned
            if running:
                # Refill on FIRST_COMPLETED; no barrier waiting for a whole batch.
                await asyncio.wait(running, timeout=WAKE_INTERVAL, return_when=asyncio.FIRST_COMPLETED)
            else:
                await asyncio.sleep(WAKE_INTERVAL)
    finally:
        for task in running:
            task.cancel()
        await asyncio.gather(*running, return_exceptions=True)
        for owned in running.values():
            polling.abandon(owned)


async def main():
    require("APP_DOMAIN", "APP_SECRET")
    db.init_db()
    from . import telegram
    loop, current = asyncio.get_running_loop(), asyncio.current_task()
    loop.add_signal_handler(signal.SIGTERM, current.cancel)
    try:
        async with http_client.lifespan():
            async with asyncio.TaskGroup() as group:
                group.create_task(monitor_loop())
                group.create_task(telegram.run())
    except asyncio.CancelledError:
        pass
    finally:
        loop.remove_signal_handler(signal.SIGTERM)


if __name__ == "__main__":
    asyncio.run(main())
