"""V1.1.0: simulated I/O, real SQLite and real cross-process Linux locks.
Run with: python -m unittest discover -s tests -v
No requests reach Google, Discord or Telegram in these tests.
"""
import asyncio
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx
import test_core as core
from app import api_keys, db, http_client, polling, security, web, worker, youtube
from fastapi.testclient import TestClient


class ConcurrencyTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.folder = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix='peralta-parallel-')))
        self.stack.enter_context(patch.object(db, 'DATA_DIR', self.folder))
        self.stack.enter_context(patch.object(db, 'DB_PATH', self.folder / 'monitor.sqlite3'))
        self.stack.enter_context(patch.object(api_keys, 'YOUTUBE_API_KEY', ''))
        db.init_db()
        db.write("UPDATE settings SET value='10' WHERE key='playlist_interval'")
        db.write("UPDATE api_credentials SET encrypted_key=?,active=1,project_id='simulated',quota_limit=10000 WHERE id=1",
                 (api_keys.encrypt('simulated-key'),))

    def channels(self, n=1):
        with db.transaction() as con:
            for i in range(n):
                con.execute("INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at,baseline_done,"
                            "ids_baseline_done,next_poll_at) VALUES(?,?,?,0,1,1,?)",
                            (f'c{i:03}', f'Canal {i}', f'u{i:03}', time.time()-1000+i))

    def targets(self, n):
        with db.transaction() as con:
            con.execute("INSERT INTO guilds(guild_id,name,active,present,owner_verified,last_seen) VALUES('g','Discord',1,1,1,0)")
            for dest in ('d1', 'd2'):
                con.execute("INSERT INTO guild_destinations VALUES('g',?,0)", (dest,))
            con.execute("UPDATE telegram_config SET enabled=1,bot_id='123',encrypted_token=? WHERE id=1", (api_keys.encrypt('tg-test'),))
            con.execute("INSERT INTO telegram_destinations(id,chat_id,kind,name,bot_id,active,verified,notify_after,created_at) "
                        "VALUES(1,'-100123','channel','Telegram','123',1,1,0,0)")
            for i in range(n):
                cid = f'c{i:03}'
                con.execute("INSERT INTO subscriptions(guild_id,channel_id,notify_after) VALUES('g',?,0)", (cid,))
                con.execute("INSERT INTO telegram_channels VALUES(?,1,0,0)", (cid,))
                con.execute("INSERT INTO telegram_routes(youtube_channel_id,destination_id,content,notify_after) VALUES(?,1,'{link}',0)", (cid,))

    def client_patch(self, handler):
        factory = httpx.AsyncClient
        return patch('app.http_client.httpx.AsyncClient',
                     lambda **kw: factory(**{**kw, 'transport': httpx.MockTransport(handler), 'trust_env': False}))

    def subprocess(self, code):
        env = {**os.environ, 'DATA_DIR': str(self.folder), 'YOUTUBE_API_KEY': '',
               'PYTHONPATH': os.pathsep.join(sys.path)}
        proc = subprocess.Popen([sys.executable, '-u', '-c', code], env=env,
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        def cleanup():
            if proc.poll() is None:
                proc.kill()
            proc.communicate(timeout=5)
        self.addCleanup(cleanup)
        return proc

    def test_100_channels_limit_refill_priority_failures_and_dedupe(self):
        self.channels(100)
        self.targets(100)
        db.write("UPDATE settings SET value='86400' WHERE key='playlist_interval'")
        measurements = []
        for limit in (1, 3, 10):
            with self.subTest(limit=limit):
                db.write("UPDATE settings SET value=? WHERE key='concurrent_checks'", (str(limit),))
                db.write("UPDATE youtube_channels SET next_poll_at=CAST(SUBSTR(channel_id,2) AS INTEGER),"
                         "poll_retry_at=0,poll_failures=0,last_poll=NULL")
                starts, ends, peak, active = {}, {}, 0, set()
                refilled = first_started = manual_checked = None
                async def fake_check(cid, uploads):
                    nonlocal peak
                    self.assertNotIn(cid, active)
                    active.add(cid); peak = max(peak, len(active)); starts[cid] = time.monotonic()
                    if cid == f'c{limit:03}': refilled.set()
                    try:
                        if cid == 'c000':
                            first_started.set()
                            await manual_checked.wait()
                        if cid == 'c097':
                            raise TimeoutError()
                        return await original(cid, uploads)
                    finally:
                        active.remove(cid); ends[cid] = time.monotonic()
                async def handle(req):
                    params = req.url.params
                    if req.url.path.endswith('/playlistItems'):
                        i = int(params['playlistId'][1:])
                        if i == 0 and limit > 1:
                            await refilled.wait()
                        await asyncio.sleep(.004)
                        if i in (20, 40, 60, 80):
                            return httpx.Response(404, json={'error': {'errors': [{'reason': 'playlistNotFound'}]}})
                        return httpx.Response(200, json={'items': [{'contentDetails': {'videoId': f'v{i:03}'}}]})
                    i = int(params['id'][1:])
                    return httpx.Response(200, json={'items': [{'id': f'v{i:03}',
                        'snippet': {'channelId': f'c{i:03}', 'title': 'Novo vídeo',
                                    'publishedAt': datetime.now(timezone.utc).isoformat(), 'liveBroadcastContent': 'none'},
                        'status': {'privacyStatus': 'public'}}]})
                original = youtube._check_playlist
                async def scenario():
                    nonlocal refilled, first_started, manual_checked
                    refilled, first_started, manual_checked = asyncio.Event(), asyncio.Event(), asyncio.Event()
                    async with http_client.lifespan() as client:
                        task = asyncio.create_task(worker.monitor_loop())
                        started = time.monotonic()
                        try:
                            async with asyncio.timeout(60):
                                await first_started.wait()
                                with self.assertRaises(polling.CheckBusy):
                                    await youtube.check_playlist('c000', 'u000')
                                manual_checked.set()
                                while db.one('SELECT COUNT(*) n FROM youtube_channels WHERE last_poll IS NOT NULL')['n'] < 100:
                                    if task.done(): task.result()
                                    await asyncio.sleep(.01)
                        finally:
                            task.cancel()
                            await asyncio.gather(task, return_exceptions=True)
                        elapsed = time.monotonic() - started
                        self.assertEqual(peak, limit)
                        self.assertEqual(list(starts)[:limit], [f'c{i:03}' for i in range(limit)])
                        if limit > 1:
                            self.assertLess(starts[f'c{limit:03}'], ends['c000'])
                        self.assertEqual(len(starts), 100)
                        self.assertEqual(db.one('SELECT COUNT(*) n FROM youtube_channels WHERE poll_failures=1')['n'], 5)
                        self.assertEqual(db.one('SELECT COUNT(*) n FROM deliveries')['n'], 190)
                        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries')['n'], 95)
                        # Another manual check and a database reopen never requeue a known video.
                        db.init_db()
                        await youtube.check_playlist('c000', 'u000')
                        self.assertEqual(db.one('SELECT COUNT(*) n FROM deliveries')['n'], 190)
                        self.assertEqual(db.one('SELECT COUNT(*) n FROM telegram_deliveries')['n'], 95)
                    self.assertTrue(client.is_closed)
                    measurements.append({'channels': 100, 'limit': limit, 'peak': peak,
                                         'seconds': round(elapsed, 3), 'failed_or_timed_out': 5,
                                         'discord_deliveries': 190, 'telegram_deliveries': 95})
                with self.client_patch(handle), patch.object(youtube, '_check_playlist', fake_check):
                    asyncio.run(scenario())
        print('SIMULATION ' + json.dumps(measurements), flush=True)

    def test_individual_interval_from_completion_and_persistent_backoff(self):
        self.channels(2)
        async def result(*args):
            await asyncio.sleep(.03)
            return {'new': 0, 'queued': 0, 'found': 0, 'baseline': False}
        before = time.time()
        with patch.object(youtube, '_check_playlist', result):
            asyncio.run(youtube.check_playlist('c000', 'u000'))
        row = db.one("SELECT * FROM youtube_channels WHERE channel_id='c000'")
        self.assertGreater(row['last_poll'], before + .02)
        self.assertAlmostEqual(row['next_poll_at'] - row['last_poll'], 10)
        with self.assertRaises(polling.CheckDeferred): polling.claim('c000')
        owned = polling.claim('c001'); polling.abandon(owned)
        with patch.object(youtube, '_check_playlist', AsyncMock(side_effect=youtube.YouTubeError('simulated'))):
            for expected in (30, 60, 120):
                db.write("UPDATE youtube_channels SET poll_retry_at=0 WHERE channel_id='c000'")
                with self.assertRaises(youtube.YouTubeError): asyncio.run(youtube.check_playlist('c000', 'u000'))
                row = db.one("SELECT * FROM youtube_channels WHERE channel_id='c000'")
                self.assertAlmostEqual(row['poll_retry_at'] - row['last_poll'], expected)
                with self.assertRaises(polling.CheckDeferred): polling.claim('c000', manual=True)
        db.init_db()
        self.assertEqual(db.one("SELECT * FROM youtube_channels WHERE channel_id='c000'"), row)
        self.assertIsNone(row['poll_owner'])

    def test_manual_automatic_exclusion_process_pause_kill_and_recovery(self):
        self.channels(2)
        db.write("UPDATE settings SET value='1' WHERE key='concurrent_checks'")
        child = self.subprocess("from app import polling\nc=polling.claim('c000')\nprint('ready',flush=True)\ninput()\npolling.abandon(c)")
        self.assertEqual(child.stdout.readline().strip(), 'ready')
        token = security.sign_session(); session = security.read_session(token)
        with TestClient(web.app, base_url=core.ORIGIN) as client:
            client.cookies.set('plm_session', token, domain='peraltamonitor.peraltaultrachat.shop')
            headers = {'Origin': core.ORIGIN, 'X-CSRF-Token': security.csrf_token(session)}
            for cid in ('c000', 'c001'):
                response = client.post(f'/api/youtube-channels/{cid}/check', headers=headers)
                self.assertEqual(response.status_code, 409, response.text)
            os.kill(child.pid, signal.SIGSTOP)
            polling.recover_abandoned()
            self.assertIsNotNone(db.one("SELECT poll_owner FROM youtube_channels WHERE channel_id='c000'")['poll_owner'])
            with self.assertRaises(polling.CheckBusy): polling.claim('c000', manual=True)
            child.kill(); child.wait(timeout=5)
            polling.recover_abandoned()
            self.assertIsNone(db.one("SELECT poll_owner FROM youtube_channels WHERE channel_id='c000'")['poll_owner'])
            with patch.object(youtube, '_check_playlist', AsyncMock(return_value={'new': 0, 'queued': 0, 'found': 0, 'baseline': False})):
                self.assertEqual(client.post('/api/youtube-channels/c000/check', headers=headers).status_code, 200)

    def test_lowering_concurrency_drains_existing_slots(self):
        self.channels(4)
        claims = [polling.claim(f'c{i:03}') for i in range(3)]
        try:
            db.write("UPDATE settings SET value='1' WHERE key='concurrent_checks'")
            for claim in claims[:2]:
                polling.abandon(claim)
                with self.assertRaises(polling.CheckBusy): polling.claim('c003')
            polling.abandon(claims[2])
            new = polling.claim('c003'); polling.abandon(new)
        finally:
            for owned in claims: polling.abandon(owned)

    def test_cancellation_before_task_start_releases_admitted_claim(self):
        self.channels()
        async def scenario():
            owned = polling.claim('c000')
            task = asyncio.create_task(worker.poll_channel(owned))
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            polling.abandon(owned)
            another = polling.claim('c000'); polling.abandon(another)
        asyncio.run(scenario())

    def test_channel_total_timeout_releases_slot_and_records_failure(self):
        self.channels(2)
        db.write("UPDATE settings SET value='1' WHERE key='concurrent_checks'")
        async def stalled(*args):
            await asyncio.Event().wait()
        with patch.object(youtube, '_check_playlist', stalled), patch.object(polling, 'CHECK_TIMEOUT', .05):
            with self.assertRaises(youtube.YouTubeError):
                asyncio.run(youtube.check_playlist('c000', 'u000'))
        row = db.one("SELECT * FROM youtube_channels WHERE channel_id='c000'")
        self.assertIsNone(row['poll_owner'])
        self.assertIn('Tempo limite', row['last_error'])
        self.assertEqual(row['poll_failures'], 1)
        owned = polling.claim('c001'); polling.abandon(owned)

    def test_shutdown_cancels_checks_and_releases_all_slots(self):
        self.channels(12)
        async def forever(*args): await asyncio.Event().wait()
        async def scenario():
            task = asyncio.create_task(worker.monitor_loop())
            async with asyncio.timeout(3):
                while db.one('SELECT COUNT(*) n FROM youtube_channels WHERE poll_owner IS NOT NULL')['n'] < 10:
                    await asyncio.sleep(.01)
            task.cancel(); await asyncio.gather(task, return_exceptions=True)
            self.assertEqual(db.one('SELECT COUNT(*) n FROM youtube_channels WHERE poll_owner IS NOT NULL')['n'], 0)
            owned = polling.claim('c011'); polling.abandon(owned)
        with patch.object(youtube, '_check_playlist', forever): asyncio.run(scenario())

    def test_inflight_requests_never_overspend_quota(self):
        db.write('UPDATE api_credentials SET quota_limit=7 WHERE id=1')
        sent = []
        async def handle(req):
            sent.append(req)
            await asyncio.sleep(.03)
            return httpx.Response(200, json={'items': []})
        async def scenario():
            async with http_client.lifespan():
                outcomes = await asyncio.gather(*(youtube.request('videos', {'part': 'id', 'id': str(i)}) for i in range(100)), return_exceptions=True)
            self.assertEqual(sum(isinstance(r, dict) for r in outcomes), 7)
            self.assertEqual(sum(isinstance(r, youtube.YouTubeError) for r in outcomes), 93)
        with self.client_patch(handle): asyncio.run(scenario())
        self.assertEqual(len(sent), 7)
        self.assertEqual(db.one('SELECT calls FROM api_usage')['calls'], 7)
        db.init_db()
        self.assertIsNone(api_keys.reserve())

    def test_quota_reservation_across_real_processes_and_same_project_keys(self):
        db.write('UPDATE api_credentials SET quota_limit=7 WHERE id=1')
        db.write("UPDATE api_credentials SET encrypted_key=?,active=1,project_id='simulated',quota_limit=7 WHERE id=2", (api_keys.encrypt('other-key'),))
        script = "from app import api_keys\ninput()\nprint(sum(api_keys.reserve() is not None for _ in range(50)),flush=True)"
        children = [self.subprocess(script) for _ in range(2)]
        for child in children:
            child.stdin.write('\n'); child.stdin.flush()
        totals = []
        for child in children:
            out, err = child.communicate(timeout=15)
            self.assertEqual(child.returncode, 0, err); totals.append(int(out.strip()))
        self.assertEqual(sum(totals), 7)
        self.assertEqual(db.one('SELECT calls FROM api_usage')['calls'], 7)
        self.assertEqual(api_keys.public_list()[0]['remaining'], 0)

    def test_late_success_does_not_erase_project_quota_pause_and_reset(self):
        db.write("UPDATE api_credentials SET encrypted_key=?,active=1,project_id='simulated' WHERE id=2", (api_keys.encrypt('other-key'),))
        counter = 0
        async def handle(req):
            nonlocal counter
            counter += 1; i = counter
            await asyncio.sleep(.005 if i == 1 else .04)
            return httpx.Response(403, json={'error': {'errors': [{'reason': 'quotaExceeded'}]}}) if i == 1 else httpx.Response(200, json={'items': []})
        async def scenario():
            async with http_client.lifespan():
                await asyncio.gather(*(youtube.request('videos', {}) for _ in range(2)), return_exceptions=True)
        with self.client_patch(handle): asyncio.run(scenario())
        self.assertEqual(counter, 2)
        db.init_db()
        self.assertIsNone(api_keys.reserve())
        self.assertIsNone(api_keys.reserve(credential_id=2))
        reset = api_keys.next_reset()
        with patch.object(db, 'ts', return_value=reset+1), patch.object(api_keys, 'quota_day', return_value='2099-01-01'):
            self.assertIsNotNone(api_keys.reserve())
        self.assertEqual(db.one("SELECT calls FROM api_usage WHERE day='2099-01-01'")['calls'], 1)

    def test_rate_limit_retry_after_and_request_total_timeout(self):
        response = httpx.Response(429, headers={'Retry-After': '180'}, json={'error': {'errors': [{'reason': 'rateLimitExceeded'}]}})
        until, shared, _ = api_keys.response_pause(response)
        self.assertTrue(shared); self.assertGreaterEqual(until, db.ts()+179)
        self.assertLess(until, db.ts()+181)
        async def slow(req):
            await asyncio.sleep(1)
            return httpx.Response(200, json={'items': []})
        with self.client_patch(slow), patch.object(http_client, 'REQUEST_TIMEOUT', .02):
            with self.assertRaises(youtube.YouTubeError): asyncio.run(youtube.request('videos', {}))
        self.assertEqual(db.one('SELECT calls FROM api_usage')['calls'], 1)
        self.assertIsNone(api_keys.reserve())

    def test_worker_suspends_without_budget_and_resumes_when_available(self):
        self.channels(2)
        db.write('UPDATE api_credentials SET quota_limit=1 WHERE id=1')
        api_keys.reserve()
        async def scenario():
            fake = AsyncMock(return_value={'new': 0, 'queued': 0, 'found': 0, 'baseline': False})
            with patch.object(youtube, '_check_playlist', fake), patch.object(worker, 'WAKE_INTERVAL', .02):
                task = asyncio.create_task(worker.monitor_loop())
                try:
                    await asyncio.sleep(.08); self.assertEqual(fake.await_count, 0)
                    db.write('UPDATE api_credentials SET quota_limit=100 WHERE id=1')
                    async with asyncio.timeout(3):
                        while fake.await_count < 2: await asyncio.sleep(.01)
                finally:
                    task.cancel(); await asyncio.gather(task, return_exceptions=True)
                self.assertEqual(fake.await_count, 2)
        asyncio.run(scenario())

    def test_settings_minimum_ten_validation_and_restart(self):
        self.channels()
        token = security.sign_session(); session = security.read_session(token)
        with TestClient(web.app, base_url=core.ORIGIN) as client:
            client.cookies.set('plm_session', token, domain='peraltamonitor.peraltaultrachat.shop')
            headers = {'Origin': core.ORIGIN, 'X-CSRF-Token': security.csrf_token(session)}
            self.assertEqual(client.get('/api/settings').json()['concurrent_checks'], 10)
            for limit in (0, 11, 1.5, True, None):
                r = client.patch('/api/settings', json={'concurrent_checks': limit}, headers=headers)
                self.assertEqual(r.status_code, 400, r.text)
            for interval in (9, 86401, 10.5, True):
                self.assertEqual(client.patch('/api/settings', json={'playlist_interval': interval}, headers=headers).status_code, 400)
            self.assertEqual(client.patch('/api/settings', json={'playlist_interval': 10, 'concurrent_checks': 3}, headers=headers).status_code, 200)
            db.init_db()
            cfg = client.get('/api/settings').json()
            self.assertEqual((cfg['playlist_interval'], cfg['concurrent_checks']), (10, 3))
            self.assertEqual(client.get('/api/quota-preview?interval=10').status_code, 200)
            self.assertEqual(client.get('/api/quota-preview?interval=9').status_code, 400)

    def test_real_http_keepalive_and_client_close(self):
        async def scenario():
            connections = 0
            closed = asyncio.Event()
            async def serve(reader, writer):
                nonlocal connections
                connections += 1
                try:
                    while True:
                        await reader.readuntil(b'\r\n\r\n')
                        writer.write(b'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n{}')
                        await writer.drain()
                except asyncio.IncompleteReadError:
                    pass
                finally:
                    writer.close(); await writer.wait_closed(); closed.set()
            server = await asyncio.start_server(serve, '127.0.0.1', 0)
            try:
                port = server.sockets[0].getsockname()[1]
                async with http_client.lifespan() as client:
                    for _ in range(5):
                        async with http_client.borrow() as borrowed:
                            self.assertIs(client, borrowed)
                            r = await borrowed.get(f'http://127.0.0.1:{port}/', timeout=2)
                            self.assertEqual(r.status_code, 200)
                    self.assertEqual(connections, 1)
                self.assertTrue(client.is_closed)
                await asyncio.wait_for(closed.wait(), 2)
            finally:
                server.close(); await server.wait_closed()
        with patch.dict(os.environ, {'NO_PROXY': '127.0.0.1', 'no_proxy': '127.0.0.1'}): asyncio.run(scenario())
