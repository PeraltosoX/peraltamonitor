# Atualizar para a V1.1.1 — oito passos

PERALTA YOUTUBE LIVE MONITOR — COMANDO DE ATUALIZAÇÃO V1.1.1
Atualizado em 22/10/2026 (America/Sao_Paulo).

USO DESTE ARQUIVO
Este guia atualiza V1.1.0 para V1.1.1, mantendo os OITO PASSOS SEPARADOS.
Também aceita as origens V1.0.5, V1.0.6, V1.0.7, V1.0.8, V1.0.9 e V1.1.0 no caminho padrão.
A V1.1.1 corrige o carregamento de arquivos antigos do painel e mostra a fila
simultânea com seus estados. Mantém consultas de 1 a 10 e intervalo mínimo de
10 segundos. O intervalo e as demais configurações salvas serão preservados.
Partindo da V1.1.0, o esquema do banco continua em 110, sem nova migração.

Execute no terminal SSH da VPS, como root, usando Bash. Execute um bloco por vez
e espere terminar. Copie somente o conteúdo de cada bloco de código. Se um passo falhar, confira o erro antes de seguir.

Não substitua /opt/peralta-live-monitor/.env pela .env.example. Preserve APP_SECRET,
credenciais, pasta data e os registros de monitoramento. APP_SECRET é necessária
para abrir as chaves API e o token Telegram já cifrados. O ZIP contém código e
documentação, não contém seu banco nem suas credenciais reais.

O domínio atual é monitor.p7nexus.online. Seu acesso foi confirmado pelo usuário
em 11/10/2026. A atualização do aplicativo não exige mudar o DNS do Windows.
Repositório de referência: PeraltosoX/peraltamonitor, branch main.

1. BAIXAR O PACOTE DO GITHUB

O download não para o monitor. Antes, publique o ZIP entregue na raiz da branch main do repositório indicado. Se o repositório for privado, use download autenticado ou copie o ZIP por SFTP para o mesmo caminho em /tmp.

```bash
(
set -Eeuo pipefail
test "$(id -u)" -eq 0 || { echo "Execute na VPS como root."; exit 1; }
for PLM_CMD in docker curl unzip; do
  command -v "$PLM_CMD" >/dev/null || { echo "Falta o comando: $PLM_CMD"; exit 1; }
done
docker compose version
docker info >/dev/null
curl -fL --retry 3 \
  -o /tmp/Peralta_YouTube_Live_Monitor_V1.1.1.zip \
  https://raw.githubusercontent.com/PeraltosoX/peraltamonitor/main/Peralta_YouTube_Live_Monitor_V1.1.1.zip
)
```

2. IDENTIFICAR A VERSÃO ANTERIOR, CONFERIR E EXTRAIR O ZIP

A origem é identificada pelas etiquetas do container web, inclusive se ele estiver parado. São aceitas V1.0.5, V1.0.6, V1.0.7, V1.0.8, V1.0.9 e V1.1.0 no caminho padrão. O bloco impede atualizar por cima de uma V1.1.1 já instalada.

```bash
(
set -Eeuo pipefail
mapfile -t PLM_WEB_IDS < <(docker ps -aq \
  --filter label=com.docker.compose.project=peralta_live_monitor \
  --filter label=com.docker.compose.service=web)
if [ "${#PLM_WEB_IDS[@]}" -ne 1 ]; then
  echo "ERRO: não encontrei um único container web do Peralta Live Monitor."
  exit 1
fi
PLM_OLD_DIR="$(docker inspect \
  --format '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' \
  "${PLM_WEB_IDS[0]}")"
case "$PLM_OLD_DIR" in
  /opt/peralta-live-monitor/releases/V1.0.[5-9]|/opt/peralta-live-monitor/releases/V1.1.0) ;;
  /opt/peralta-live-monitor/releases/V1.1.1)
    echo "A instalação já está na V1.1.1. Este guia não precisa ser executado."
    exit 1
    ;;
  *)
    echo "ERRO: origem fora das versões e caminhos cobertos por este guia: $PLM_OLD_DIR"
    exit 1
    ;;
esac
test -s "$PLM_OLD_DIR/compose.yaml"
test -s /opt/peralta-live-monitor/.env
test -s /opt/peralta-live-monitor/data/monitor.sqlite3
if test -e /opt/peralta-live-monitor/releases/V1.1.1; then
  echo "A pasta V1.1.1 já existe. Não vou sobrescrevê-la."
  echo "Se o passo 2 já terminou antes, continue do passo 3; se não, confira o conteúdo."
  exit 1
fi
unzip -tq /tmp/Peralta_YouTube_Live_Monitor_V1.1.1.zip
unzip -q /tmp/Peralta_YouTube_Live_Monitor_V1.1.1.zip \
  -d /opt/peralta-live-monitor/releases
test -s /opt/peralta-live-monitor/releases/V1.1.1/compose.yaml
test -s /opt/peralta-live-monitor/releases/V1.1.1/app/__init__.py
echo "Pacote extraído. A instalação anterior permanece em: $PLM_OLD_DIR"
)
```

3. CONSTRUIR A IMAGEM NOVA

Aguarde a construção terminar. Os serviços antigos continuam funcionando nesta etapa. A mesma imagem será utilizada pelo web, worker e bot.

```bash
(
set -Eeuo pipefail
cd /opt/peralta-live-monitor/releases/V1.1.1
docker compose config -q
docker compose build web
)
```

4. PARAR OS SERVIÇOS E FAZER O BACKUP

O monitoramento fica parado a partir desta etapa. Só avance quando aparecer Backup concluído. O banco é copiado pela API de backup do SQLite e sua integridade é conferida. O Caddy continua atendendo os demais sites.

```bash
(
set -Eeuo pipefail
umask 077
mapfile -t PLM_WEB_IDS < <(docker ps -aq \
  --filter label=com.docker.compose.project=peralta_live_monitor \
  --filter label=com.docker.compose.service=web)
if [ "${#PLM_WEB_IDS[@]}" -ne 1 ]; then
  echo "ERRO: não encontrei um único container web do Peralta Live Monitor."
  exit 1
fi
PLM_OLD_DIR="$(docker inspect \
  --format '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' \
  "${PLM_WEB_IDS[0]}")"
case "$PLM_OLD_DIR" in
  /opt/peralta-live-monitor/releases/V1.0.[5-9]|/opt/peralta-live-monitor/releases/V1.1.0) ;;
  /opt/peralta-live-monitor/releases/V1.1.1)
    echo "A instalação já está na V1.1.1. Este guia não precisa ser executado."
    exit 1
    ;;
  *)
    echo "ERRO: origem fora das versões e caminhos cobertos por este guia: $PLM_OLD_DIR"
    exit 1
    ;;
esac
test -s "$PLM_OLD_DIR/compose.yaml"
test -s /opt/peralta-live-monitor/.env
test -s /opt/peralta-live-monitor/data/monitor.sqlite3
test -s /opt/peralta-live-monitor/releases/V1.1.1/compose.yaml
PLM_BACKUP_NAME="antes-V1.1.1-$(date +%Y%m%d-%H%M%S)"
PLM_BACKUP_DIR="/opt/peralta-live-monitor/data/backup/$PLM_BACKUP_NAME"
mkdir -p /opt/peralta-live-monitor/data/backup
mkdir -m 700 "$PLM_BACKUP_DIR"
cp -p /opt/peralta-live-monitor/.env "$PLM_BACKUP_DIR/config.env"
chmod 600 "$PLM_BACKUP_DIR/config.env"
if test -f /etc/caddy/Caddyfile; then
  cp -p /etc/caddy/Caddyfile "$PLM_BACKUP_DIR/Caddyfile"
  chmod 600 "$PLM_BACKUP_DIR/Caddyfile"
fi
cd "$PLM_OLD_DIR"
docker compose stop -t 60 worker bot web
cd /opt/peralta-live-monitor/releases/V1.1.1
docker compose run --rm --no-deps -T web python -m scripts.backup \
  "/data/backup/$PLM_BACKUP_NAME/monitor.sqlite3"
echo "Backup concluído: $PLM_BACKUP_DIR"
)
```

5. INICIAR O PAINEL

Inicie somente o web para concluir a migração do banco e verificar a aplicação antes de retomar os envios.

```bash
(
set -Eeuo pipefail
cd /opt/peralta-live-monitor/releases/V1.1.1
docker compose up -d --no-build --no-deps web
)
```

6. AGUARDAR O PAINEL E CONFIRMAR A VERSÃO

A espera é feita com um laço de Bash, compatível com o curl antigo da VPS. Dura cerca de três minutos, podendo ultrapassar alguns segundos devido à última tentativa. Só avance quando aparecer Painel V1.1.1 pronto.

```bash
(
set -Eeuo pipefail
cd /opt/peralta-live-monitor/releases/V1.1.1
trap 'docker compose ps -a; docker compose logs --tail=60 web' ERR

PLM_READY=0
PLM_DEADLINE=$((SECONDS + 180))
echo "Aguardando o painel ficar pronto..."
while [ "$SECONDS" -lt "$PLM_DEADLINE" ]; do
  if curl --noproxy '*' --connect-timeout 2 --max-time 5 \
      -fsS -o /dev/null http://127.0.0.1:8081/health 2>/dev/null; then
    PLM_READY=1
    break
  fi
  sleep 2
done

if [ "$PLM_READY" -ne 1 ]; then
  echo "ERRO: o painel não ficou pronto no prazo. Confira os logs abaixo."
  docker compose ps -a
  docker compose logs --tail=60 web
  exit 1
fi

docker compose exec -T web python - <<'PY'
import json
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:8081/health', timeout=10) as response:
    result = json.load(response)
if result.get('status') != 'ok' or result.get('version') != '1.1.1':
    raise SystemExit('ERRO: estado ou versão inesperados: ' + repr(result))
print('Painel V1.1.1 pronto. Pode iniciar o worker e o bot.')
PY
)
```

7. INICIAR WORKER E BOT

Este passo retoma a busca YouTube, o Telegram e o bot Discord. O Telegram funciona dentro do worker; não existe um quarto serviço.

```bash
(
set -Eeuo pipefail
cd /opt/peralta-live-monitor/releases/V1.1.1
docker compose up -d --no-build worker bot
)
```

8. CONFERIR SERVIÇOS, VERSÃO E LOGS

Abra https://monitor.p7nexus.online, pressione Ctrl+F5 uma vez e confirme V1.1.1.
O painel passa a usar a versão do aplicativo nas URLs de JavaScript/CSS e a
revalidar arquivos em cache. Confira a previsão com 10 e 20 segundos: para sete
canais ativos, ela mostra 60.480 e 30.240 unidades de playlist/dia, respectivamente.
Esse valor é uma previsão; o contador de chamadas de hoje é independente.
Em Visão geral, o cartão Consultas simultâneas mostra consultas em andamento /
limite configurado, e a lista distingue Verificando, Na fila e espera por intervalo
ou pausa. Os dados chegam a cada 10 segundos: buscas curtas podem terminar entre
duas atualizações. Ver 0 / 10 enquanto os canais aguardam o intervalo é normal.
Confira também os canais e as configurações de Discord e Telegram. Em Configurações, confira Consultas simultâneas = 10. Para usar o novo mínimo, escolha Verificar a cada = 10 e salve; a atualização não reduz seu intervalo automaticamente. O /health verifica o web e o banco; a conexão dos bots e as permissões reais devem ser conferidas no painel e nos logs.

```bash
(
set -Eeuo pipefail
cd /opt/peralta-live-monitor/releases/V1.1.1
docker compose ps -a
curl --noproxy '*' -fsS --connect-timeout 2 --max-time 10 \
  http://127.0.0.1:8081/health
docker compose logs --tail=30 web worker bot
)
```

SE A EXECUÇÃO FOR INTERROMPIDA
- Antes do passo 4, a instalação anterior ainda deve estar rodando.
- Depois do backup, continue pelo passo que faltou. Não apague a pasta extraída.
- Se o passo 6 falhar, confira os logs do web e corrija o motivo antes do passo 7.
- Se a V1.1.1 já gravou dados ou enviou avisos, não restaure automaticamente uma
  cópia antiga do banco: isso perde alterações posteriores e pode repetir avisos.
- Preserve o banco atual e interrompa os três serviços antes de uma restauração
  planejada. O Caddyfile de backup pode conter outros sites; não o sobrescreva
  integralmente sem comparar a configuração existente.
- Não use docker compose down -v nem apague data para tentar corrigir atualização.

PARA UMA FUTURA VERSÃO
Mantenha esta sequência: baixar, extrair, construir, parar/backup, web, saúde,
worker/bot e conferência. O próximo pacote deverá trazer os oito passos já
adaptados à versão de destino e à compatibilidade real da migração. Não basta
trocar somente o nome do ZIP se as regras da futura migração forem diferentes.

CUIDADOS ESPECÍFICOS DA V1.1.1
- Pare os três serviços antigos antes da migração. Não rode o worker 1.0.9 ao
  mesmo tempo que o novo: a versão antiga não conhece os bloqueios de consulta.
- Os três serviços devem continuar usando o mesmo /opt/peralta-live-monitor/data,
  em disco local desta VPS Linux. O Compose entregue mantém essa montagem.
- data/poll-locks é criada automaticamente. Não apague os arquivos de bloqueio
  com o programa rodando. O sistema libera bloqueios de processos encerrados.
- Não altere APP_SECRET, .env, tokens ou banco para habilitar a concorrência.
- Migração aditiva: IDs conhecidos, entregas, modelos, pessoas autorizadas e
  cotas existentes são preservados. Não zera o histórico nem a linha de base.
- Se reduzir Consultas simultâneas durante uso, as consultas em andamento
  terminam e a fila passa a respeitar o limite menor, sem cancelar resultados.
- O ID do projeto Google identifica o saldo compartilhado entre chaves. Chaves
  sem ID compartilham um saldo conservador. Não some cotas por quantidade de chaves.
- Para conferir latência, CPU, memória e cota reais, siga VALIDACAO.md. Não foram
  usados seu banco real, tokens reais ou acesso à VPS durante esta entrega.

Os comandos foram revisados e verificados localmente; não foram executados na VPS
nesta entrega. O ZIP não foi publicado automaticamente no GitHub.

Referência de comportamento do Compose:
https://docs.docker.com/reference/cli/docker/compose/up/
