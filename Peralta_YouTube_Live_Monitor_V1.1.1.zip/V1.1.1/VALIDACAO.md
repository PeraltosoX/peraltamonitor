# Validação da V1.1.1 — 22/10/2026

Resultado final: **89 testes Python aprovados em 12,460s e 4 testes JavaScript aprovados** (93 no total). Execução local, sem acesso à VPS e sem usar banco ou credenciais de produção.

## Diagnóstico e correção

O ZIP V1.1.0 já validava intervalo mínimo de 10s no JavaScript e na API, mas index.html ainda solicitava os arquivos com `?v=109`, e a resposta permitia cache privado sem exigir revalidação. A imagem com a mensagem de mínimo 30s é compatível com JavaScript antigo em cache. Não foi inspecionado o cache do navegador do usuário, portanto essa origem é uma inferência apoiada pela divergência entre a tela e o ZIP.

A V1.1.1 gera as URLs com VERSION automaticamente, impede armazenamento do HTML e exige revalidação dos arquivos estáticos. A visão geral agora recebe os horários e estados do agendador e apresenta quantidade em andamento / limite, fila, intervalo e pausa por erro.

O motor do worker continua igual ao da V1.1.0. Foi conferida igualdade dos arquivos worker.py, polling.py, db.py, api_keys.py, http_client.py, youtube.py, routing.py, bot.py, telegram.py e telegram_store.py. Não há nova migração de banco a partir da V1.1.0 (esquema 110).

## Concorrência com 100 canais simulados

| Limite | Pico observado | Canais processados | Falhas controladas | Tempo local |
| --- | --- | --- | --- | --- |
| 1 | 1 | 100 | 5 | 2,919s |
| 3 | 3 | 100 | 5 | 1,420s |
| 10 | 10 | 100 | 5 | 1,054s |

Nos casos paralelos, o próximo canal começou antes de terminar o canal lento. Confirmados prioridade pelo atraso, reutilização de vaga, quatro respostas HTTP 404 e um timeout injetado, além de verificação manual concorrente recusada para o mesmo canal. Noventa e cinco canais bem-sucedidos geraram 190 entradas de entrega Discord e 95 Telegram. Reconsultar e reabrir o banco não duplicou essas entradas.

Esses tempos não são um benchmark nem previsão para a VPS: os passes posteriores também exercitam IDs já conhecidos. As notificações foram simuladas; o teste mede correção da fila, e não a velocidade dos serviços reais.

Também passaram os testes anteriores de timeout real por canal/requisição, pausa após falhas, recuperação de processo SIGKILL, processo suspenso SIGSTOP, redução do limite, cancelamento/encerramento, recuperação após reinício e conexão HTTP reutilizável. Na disputa de cota, saldo 7 permitiu só 7 de 100 tentativas; dois processos com chaves do mesmo projeto também não ultrapassaram o saldo. Mantidos testes de classificação, filtros, deduplicação, autorização e migrações V1.0.5–V1.0.9.

## Regressões do painel

- HTML sem armazenamento; todos os seis arquivos JS/CSS recebem a versão real na URL e cabeçalho para revalidar cache. Requisição condicional retorna 304 somente para arquivo inalterado; versão futura simulada muda automaticamente os endereços.
- API de previsão e salvamento: 10s, 20s e 30s aceitos; 9s rejeitado. Para sete canais, resultados 60.480, 30.240 e 20.160 por dia. Contador de hoje simulado em 8.936 permaneceu igual após as alterações.
- API do dashboard: duas consultas abertas, incluindo uma manual, são informadas; limite e horários de pausa são preservados. O estado é liberado ao encerrar.
- JavaScript entregue executado no Node com DOM mínimo e HTTP simulado: previsões a 10/20/30s, validação de valores inválidos sem apagar o contador, duas consultas simultâneas, um canal na fila, intervalo de outro canal, pausa por erro, canal pausado e worker sem sinal.

A quantidade em andamento é uma amostra renovada a cada 10 segundos. Consultas rápidas podem acabar entre amostras. Zero consultas em andamento durante o intervalo é normal e não comprova execução sequencial.

## Reprodução

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
node --test tests/test_panel_ui.js
```

Executar na pasta V1.1.1 com Linux e Python 3.12. O teste JavaScript usa node:test (validado com Node 24); Node é necessário apenas para esse teste, não para rodar o aplicativo. Os testes criam bancos temporários e usam dados fictícios. Houve aviso de depreciação do adaptador HTTPX do Starlette, sem falha final.

## Pacote e limites da validação

- Sintaxe Python/JavaScript válida; 18 blocos Bash dos guias conferidos com bash -n.
- Guia mantém oito passos, aceita origem V1.1.0 e bases V1.0.5–V1.0.9, destino V1.1.1 e exige versão 1.1.1 no /health antes de iniciar worker/bot.
- Banco, .env, APP_SECRET e configurações são preservados pelo procedimento. O ZIP não inclui banco real, credenciais, dependências instaladas ou caches.
- Ícones, motor da fila e regras de envio mantidos. TXT externos iguais aos do ZIP.

Não executados: build Docker, instalação na VPS, publicação no GitHub, inspeção do navegador do usuário ou teste visual completo em navegador. O teste JavaScript verifica comportamento e conteúdo com DOM simulado; não mede layout real.

## Verificações pendentes na VPS

1. Após instalar, usar Ctrl+F5 e confirmar V1.1.1, previsão a 10/20s e estados da fila no navegador real.
2. Medir CPU/RAM, conexões, latência média/p95/p99, duração das consultas e atraso da fila com 100 canais reais, comparando limites 1/3/10.
3. Comparar a contagem local com o consumo oficial do projeto Google e acompanhar pausas/virada de cota.
4. Conferir latência e chegada real dos avisos no Discord/Telegram, permissões e ausência de duplicação após reinício controlado.
5. Acompanhar SQLite/WAL, erros de rede e estabilidade por pelo menos 24h. Não houve certificação de capacidade sustentada da VPS.
