"""Panel cache/version regression and the 10-second quota preview (no network)."""
import re
import unittest
from unittest.mock import patch

import test_core as core
from app import VERSION, api_keys, db, polling, security, web
from fastapi.testclient import TestClient


class PanelTests(unittest.TestCase):
    def setUp(self):
        core.CoreTests.setUp(self)
        self.client = TestClient(web.app, base_url=core.ORIGIN)
        self.addCleanup(self.client.close)
        token = security.sign_session()
        self.client.cookies.set('plm_session', token, domain='peraltamonitor.peraltaultrachat.shop')
        self.headers = {'Origin': core.ORIGIN,
                        'X-CSRF-Token': security.csrf_token(security.read_session(token))}

    def test_panel_references_running_release_and_revalidates_cached_scripts(self):
        page = self.client.get('/')
        self.assertEqual(page.status_code, 200)
        self.assertEqual(page.headers['cache-control'], 'no-store')
        self.assertNotIn('__APP_VERSION__', page.text)
        assets = re.findall(r'(?:src|href)="(/static/[^" ]+\.(?:js|css)\?v=[^" ]+)"', page.text)
        self.assertEqual(len(assets), 6)
        for url in assets:
            with self.subTest(url=url):
                self.assertTrue(url.endswith('?v=' + VERSION))
                response = self.client.get(url)
                self.assertEqual(response.status_code, 200)
                self.assertIn('no-cache', response.headers['cache-control'])
        script = self.client.get('/static/app.js?v=' + VERSION)
        unchanged = self.client.get('/static/app.js?v=' + VERSION,
                                    headers={'If-None-Match': script.headers['etag']})
        self.assertEqual(unchanged.status_code, 304)
        self.assertIn('no-cache', unchanged.headers['cache-control'])
        # A later release automatically changes URLs without editing index.html.
        with patch.object(web, 'VERSION', '9.9.9'):
            newer = self.client.get('/')
        self.assertIn('/static/app.js?v=9.9.9', newer.text)
        self.assertNotEqual(page.text, newer.text)

    def test_10_20_30_second_preview_preserves_today_usage_and_saved_interval(self):
        for n in range(6):
            db.write('INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at) VALUES(?,?,?,0)',
                     (f'preview{n}', f'Canal {n}', f'uploads{n}'))
        db.write('INSERT INTO api_usage(day,calls,updated_at) VALUES(?,8936,0)', (api_keys.quota_day(),))
        for interval, expected in ((10, 60480), (20, 30240), (30, 20160)):
            with self.subTest(interval=interval):
                response = self.client.get(f'/api/quota-preview?interval={interval}')
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.json()['playlist_units_per_day'], expected)
                self.assertEqual(response.json()['channels'], 7)
                saved = self.client.patch('/api/settings', headers=self.headers,
                                          json={'playlist_interval': interval, 'concurrent_checks': 10})
                self.assertEqual(saved.status_code, 200, saved.text)
                settings = self.client.get('/api/settings').json()
                self.assertEqual(settings['playlist_interval'], interval)
                self.assertEqual(settings['quota_estimate'], 8936)
        self.assertEqual(self.client.get('/api/quota-preview?interval=9').status_code, 400)

    def test_dashboard_reports_concurrent_claims_and_per_channel_pause(self):
        db.write("UPDATE settings SET value='3' WHERE key='concurrent_checks'")
        db.write('UPDATE youtube_channels SET next_poll_at=0,poll_retry_at=0')
        db.write("INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at,next_poll_at) "
                 "VALUES('second','Segundo','uploads2',0,0)")
        db.write("INSERT INTO youtube_channels(channel_id,name,uploads_id,created_at,next_poll_at,poll_retry_at) "
                 "VALUES('retry','Pausa','uploads3',0,20,60)")
        first = polling.claim(core.CID, manual=True)
        second = polling.claim('second')
        try:
            data = self.client.get('/api/dashboard').json()
            self.assertEqual(data['concurrent_checks'], 3)
            channels = {c['channel_id']: c for c in data['channels']}
            self.assertEqual(sum(c['poll_started_at'] is not None for c in channels.values()), 2)
            self.assertEqual(channels['retry']['next_poll_at'], 20)
            self.assertEqual(channels['retry']['poll_retry_at'], 60)
            self.assertNotIn('poll_owner', channels[core.CID])
        finally:
            polling.abandon(first)
            polling.abandon(second)
        after = self.client.get('/api/dashboard').json()
        self.assertFalse(any(c['poll_started_at'] is not None for c in after['channels']))
