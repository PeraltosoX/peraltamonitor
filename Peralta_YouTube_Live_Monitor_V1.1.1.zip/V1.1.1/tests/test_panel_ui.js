// Runs the shipped app.js in Node with a minimal DOM and simulated HTTP.
// Tests the displayed content; does not replace a browser layout check.
const assert = require('node:assert/strict');
const {test} = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function panel() {
  const nodes = new Map();
  function node(selector) {
    if (!nodes.has(selector)) nodes.set(selector, {
      value:'', textContent:'', innerHTML:'',
      classList:{toggle(){},add(){},remove(){},contains(){return false;}},
      addEventListener(){},setAttribute(){},querySelectorAll(){return [];},
      elements:new Proxy({}, {get:(target,key)=>node(`${selector}:${key}`)})
    });
    return nodes.get(selector);
  }
  const requests = [];
  const context = vm.createContext({
    document:{hidden:false,querySelector:node,querySelectorAll:()=>[],body:node('body'),addEventListener(){}},
    window:{matchMedia:()=>({matches:false,addEventListener(){}}),addEventListener(){}},
    setInterval(){},setTimeout(){},clearTimeout(){},
    fetch:async url=>{
      requests.push(url);
      const interval=Number(new URL(url,'http://local').searchParams.get('interval'));
      const totals={10:60480,20:30240,30:20160};
      return {ok:true,json:async()=>({channels:7,interval,playlist_units_per_day:totals[interval],note:'Simulado'})};
    }
  });
  const run=code=>vm.runInContext(code,context);
  run(fs.readFileSync(path.join(__dirname,'../app/static/app.js'),'utf8'));
  // DOM diffing is unrelated to these regressions; capture the final markup.
  run('patchHTML=(target,markup)=>{target.innerHTML=markup;};');
  return {node,requests,run};
}

test('10s and 20s show a forecast and retain today usage, like 30s', async()=>{
  const p=panel();
  p.run('renderSettings({playlist_interval:30,concurrent_checks:10,timezone:"America/Sao_Paulo",google_key_configured:true,quota_estimate:8936})');
  const summary=p.node('#settings-summary').innerHTML;
  for(const [seconds,number] of [[10,'60.480'],[20,'30.240'],[30,'20.160']]) {
    p.node('#settings-form:playlist_interval').value=String(seconds);
    await p.run('updateQuotaPreview()');
    assert.equal(p.requests.at(-1),`/api/quota-preview?interval=${seconds}`);
    assert.match(p.node('#quota-preview').innerHTML,new RegExp(number.replace('.', '\\.')));
    assert.equal(p.node('#settings-summary').innerHTML,summary);
  }
  assert.match(summary,/8936/);
});

test('invalid interval is explained without removing today usage', async()=>{
  const p=panel();
  p.run('renderSettings({playlist_interval:10,concurrent_checks:10,timezone:"America/Sao_Paulo",quota_estimate:8936})');
  for(const invalid of ['9','','10.5','86401']) {
    p.node('#settings-form:playlist_interval').value=invalid;
    await p.run('updateQuotaPreview()');
    assert.match(p.node('#quota-preview').textContent,/entre 10 e 86.400/);
    assert.match(p.node('#settings-summary').innerHTML,/8936/);
  }
  assert.equal(p.requests.length,0);
});

test('dashboard shows simultaneous checks, ready queue, completion interval and backoff',()=>{
  const p=panel();
  p.run(`state.dashboardFetchedAt=Date.now(); state.dashboard={
    server_time:1000,interval:10,concurrent_checks:10,heartbeats:[{service:'worker',at:1000}],
    channels:[
      {channel_id:'a',name:'A',active:1,poll_started_at:998,last_poll:980,next_poll_at:990},
      {channel_id:'b',name:'B',active:1,poll_started_at:999,last_poll:980,next_poll_at:990},
      {channel_id:'c',name:'C',active:1,poll_started_at:null,last_poll:995,next_poll_at:1005},
      {channel_id:'d',name:'D',active:1,poll_started_at:null,last_poll:980,next_poll_at:990},
      {channel_id:'e',name:'E',active:1,poll_started_at:null,last_poll:980,next_poll_at:990,poll_retry_at:1060,last_error:'Falha'},
      {channel_id:'f',name:'F',active:0,poll_started_at:null,last_poll:980,next_poll_at:990}
    ]}; renderCountdown();`);
  assert.equal(p.node('#next-check').textContent,'2 / 10');
  assert.equal(p.node('#next-progress').value,2);
  assert.match(p.node('#next-check-detail').textContent,/1 na fila · 2 aguardando/);
  const rows=p.node('#channel-schedule').innerHTML;
  assert.equal((rows.match(/Verificando…/g)||[]).length,2);
  assert.match(rows,/00:05/);
  assert.match(rows,/Nova tentativa em 01:00/);
  assert.match(rows,/Pausado/);
  assert.doesNotMatch(p.node('#next-check-detail').textContent,/Próximo canal:/);
});

test('idle, paused channels and absent worker do not imply a running check',()=>{
  const p=panel();
  p.run(`state.dashboardFetchedAt=Date.now();state.dashboard={server_time:1000,interval:10,concurrent_checks:3,
    heartbeats:[{service:'worker',at:1000}],channels:[{channel_id:'a',name:'A',active:1,last_poll:995,next_poll_at:1005,poll_started_at:null}]};renderCountdown();`);
  assert.equal(p.node('#next-check').textContent,'0 / 3');
  assert.match(p.node('#next-check-detail').textContent,/Próxima liberação em 00:05/);
  p.run('state.dashboard.channels[0].active=0;renderCountdown();');
  assert.match(p.node('#channel-schedule').innerHTML,/Pausado/);
  p.run('state.dashboard.heartbeats=[];renderCountdown();');
  assert.equal(p.node('#next-check').textContent,'Sem sinal');
});
